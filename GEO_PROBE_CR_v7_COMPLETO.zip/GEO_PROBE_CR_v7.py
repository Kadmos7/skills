#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GEO-PROBE CR — v7.3 CANÓNICA (auditada)
Red Nacional de Precursores Sísmicos · Costa Rica
Inventor: Jason Manuel Sarmiento Salazar · OTPR CR / PCT WIPO
Divulgación técnica: 12 de septiembre de 2026

Línea v3 → v7.2 consolidada: borehole 600 m, sin reactor, cable primario +
ULF de respaldo, decisión bayesiana multi-fase. Esta versión audita y corrige
la v7.2 sin cambiar las decisiones de diseño del inventor (I = 6.3 A,
núcleo Ø0.14 m, beneficio sin VSL, CAPEX/OPEX).

USO
    python GEO_PROBE_CR_v7_3.py                      # informe + JSON
    python GEO_PROBE_CR_v7_3.py --out resultados.json
    python GEO_PROBE_CR_v7_3.py --lineal             # KPI principal sin tope de saturación
    python GEO_PROBE_CR_v7_3.py --set i_a=5.1 --set fraccion_eventos_horizonte=0.4
    python GEO_PROBE_CR_v7_3.py --selftest           # pruebas
    python GEO_PROBE_CR_v7_3.py --quiet              # solo JSON

TRAZABILIDAD   [V] fórmula estándar / derivado · [H] hipótesis sin fuente.
               El registro completo está en SUPUESTOS y se exporta al JSON.

CAMBIOS RESPECTO A v7.2 (auditoría)
  Errores corregidos
   1. El CLI ignoraba el modo "saturado" que el docstring anunciaba como KPI
      principal (--saturacion era store_true, default False): el encabezado
      decía "modo: lineal". Ahora el default es saturado; --lineal lo anula.
   2. Pérdidas por saturación con signo invertido ("−-0.1 dB", "−-1.2 dB"):
      la pérdida se acota a ≥ 0 y se informa la utilización de B_sat.
   3. Hallazgos con texto obsoleto o contradictorio: F1 aconsejaba "I≈7 A"
      (mayor que I_sat ≈ 6.4 A), F7 hablaba de un modelo que ya no existía,
      F5 pedía rotular partidas ya rotuladas, "I=6 A" por formato :.0f.
      Los hallazgos ahora se generan con severidad y texto calculados.
   4. Pruebas de regresión debilitadas hasta ser casi tautológicas
      (p. ej. nbit ≥ 1). Se restauran cifras fijas v6.3/v6.4 mediante
      PARAMS_V6 y se agregan valores de referencia v7.3.
   5. Código muerto en la sensibilidad de gasto público (`if False else
      None`, reconstrucción de Params inútil). Reemplazado por replace().
   6. valorar() ocultaba el desglose cuando se pasaba beneficio externo.
  Verificaciones nuevas
   7. Margen de saturación: con I = 6.3 A el núcleo opera al 98 % de B_sat;
      se informa el escenario con margen (util_bsat_objetivo).
   8. Geometría: bobina de una capa, holgura radial bobina–sonda, masa.
   9. μ_eff de diseño vs μ teórico (margen de fábrica 1.5 dB).
  10. Beneficios: fracción del catálogo que ocurre en el horizonte (φ),
      caso prudente, φ de equilibrio y gasto público acotado.
  11. --set clave=valor para sensibilidades sin editar el código.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import tempfile
import warnings
from dataclasses import asdict, dataclass, fields, replace
from enum import IntEnum
from math import ceil, comb
from pathlib import Path

import numpy as np

warnings.filterwarnings("ignore")

VERSION = "7.3 CANÓNICA"
SCHEMA = "7.3"
SEED = 2026
ANCHO = 74
MU0 = 4.0e-7 * math.pi
INVENTOR = "Jason Manuel Sarmiento Salazar"
FECHA_DIVULGACION = "2026-09-12"
HOLGURA_MIN_MM = 5.0        # [H] holgura radial mínima bobina–sonda para forro y aislante


# ══════════════════════════════════════════════════════════════════════════
#  1. PARÁMETROS
# ══════════════════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class Params:
    # — Sitio y perforación —
    depth_m: float = 600.0
    n_nodos: int = 5
    d_hole_mm: float = 200.0
    d_sonde_mm: float = 168.0
    l_sonde_m: float = 6.0
    rop_m_dia: float = 45.0
    dias_compl: float = 6.0
    n_equipos: int = 2
    espesor_pared_sonde_mm: float = 6.0   # [H] carcasa Ti/PTFE

    # — Enlace ULF (diseño v7.2) —
    f_ulf: float = 2.0
    t_bit: float = 30.0
    mu_r: float = 2000.0
    l_core: float = 4.0
    d_core: float = 0.14
    mu_eff_design: float = 200.0
    rho_fer: float = 4800.0
    rho_cu: float = 1.68e-8
    n_turns: int = 1000
    i_a: float = 6.3
    a_cond_mm2: float = 10.0
    r_bobina_m: float = 0.075             # radio efectivo del devanado
    duty: float = 0.17
    rej_db: float = 30.0
    b_sat_ferrita_t: float = 0.40         # [H] MnZn a temperatura de pozo; verificar
    util_bsat_objetivo: float = 0.80      # [H] utilización máxima recomendada de B_sat
    area_efectiva: bool = True            # False reproduce el modelo v6.x (m = μ·N·I·π·r²)

    # — Térmico —
    t_surf: float = 25.0
    grad_termico: float = 30.0
    derate_pct_per_c: float = 0.004
    mu_min: float = 80.0

    # — Economía —
    contingencia_pct: float = 0.18
    r_disc: float = 0.06
    inflacion: float = 0.035
    years: int = 30
    gasto_publico_por_evento_usd: float = 25_000_000.0   # [H]
    fraccion_eventos_horizonte: float = 1.0              # [H] φ: parte del catálogo que ocurre en 30 a

    def __post_init__(self) -> None:
        positivos = ("depth_m", "rop_m_dia", "f_ulf", "t_bit", "l_core", "d_core",
                     "mu_eff_design", "i_a", "a_cond_mm2", "r_bobina_m", "years",
                     "n_nodos", "n_equipos", "b_sat_ferrita_t", "n_turns", "mu_r")
        for nombre in positivos:
            if getattr(self, nombre) <= 0:
                raise ValueError(f"Parámetro '{nombre}' debe ser > 0")
        for nombre in ("duty", "util_bsat_objetivo", "fraccion_eventos_horizonte"):
            if not 0 < getattr(self, nombre) <= 1:
                raise ValueError(f"{nombre} debe estar en (0, 1]")
        if self.gasto_publico_por_evento_usd < 0:
            raise ValueError("gasto_publico_por_evento_usd debe ser ≥ 0")
        if self.r_bobina_m < self.d_core / 2:
            raise ValueError("La bobina no puede ser menor que el núcleo")
        if self.d_sonde_mm >= self.d_hole_mm:
            raise ValueError("La sonda debe caber en el pozo")


P0 = Params()
PARAMS_V6 = replace(P0, i_a=20.0, d_core=0.10, r_bobina_m=0.055, area_efectiva=False)

SIGMA_REF = 1.2e-4                     # [H] basalto húmedo CR, S/m
PC1_RUIDO = {
    "Tranquilo (noche, Kp≤2)": 20.0,
    "Típico diurno": 60.0,
    "Activo (Kp 4–5)": 300.0,
    "Tormenta CME (Kp≥7)": 3000.0,
}
KP_BANDAS = ((0, 2, "Tranquilo", 20.0), (3, 4, "Moderado", 60.0),
             (5, 6, "Activo", 300.0), (7, 9, "Tormenta", 3000.0))
LITOLOGIAS = (("Basalto seco", 5e-5), ("Basalto húmedo CR", 1.2e-4),
              ("Andesita", 3e-4), ("Sedimento", 1e-3),
              ("Falla fluidos", 5e-3), ("Arcilla ácida", 2e-2))
SNR_OBJETIVO_DB = 20.0
MAX_BITS = 64
T_MAX_ULF_S = 15 * 60
REJ_ESTRES_DB = 10.0
GRAD_ESTRES = 55.0

PESO_CABLE = 1.00                      # [H] política de confianza por canal
PESO_ULF_OK = 0.70
PESO_ULF_DEGRADADO = 0.40
PESO_ULF_RECHAZO_DEGRADADO = 0.35

SHEAR_K, SHEAR_M0 = 1.937, 7.581       # [H] calibración no documentada
MW_EVENTOS_MAYORES = (6.5, 7.0, 7.5, 7.8)

EFICACIA_REDUCCION = 0.7               # [H]
FACTOR_PRECURSOR = {"documentado": 1.15, "posible": 1.02, "ninguno": 0.82}

# [H] Latencia y FA son supuestos de diseño, NO resultados calculados.
T_CABLE_S, T_ULF_S, FA_ANUAL = 5.70, 7.30, 0.05

MODOS_FALLA = (("Modo 1", 0.30, 0.95), ("Modo 2", 0.45, 0.85),
               ("Modo 3", 0.35, 0.92), ("Modo 4", 0.12, 0.98),
               ("Modo 5", 0.20, 0.99))   # [H] rótulos pendientes
P_REGIMEN_CORRELACIONADO = 0.08        # [H]
P_UP_CORRELACIONADO = 0.55             # [H]

CAPEX_BASE = {                         # USD
    "Perforación 5×600m": 550_000,
    "Entubado/cementado": 180_000,
    "DAS (5)": 750_000,
    "SQUID superficie (5)": 350_000,
    "Rb-87 pozo (10)": 200_000,
    "Cable armado (5) PRIMARIO": 60_000,
    "Bobina ULF (5) RESPALDO": 85_000,
    "Radón (5)": 60_000,
    "Presión poros (10)": 60_000,
    "Sondes Ti/PTFE (5)": 140_000,
    "Telecom ICE+LEO": 75_000,
    "Cómputo OVSICORI": 150_000,
    "Gateway CB CNE": 180_000,
    "Ingeniería/comisionado": 200_000,
}
# [H] Los montos vienen del código v6.x sin rótulo; los nombres se asignaron
# en v7.1 y son PROVISIONALES: confirmar contra el presupuesto real.
OPEX_ANUAL = {
    "Personal técnico OVSICORI/RSN [prov.]": 125_000,
    "Helio / criogenia SQUID [prov.]": 18_000,
    "Energía y respaldo sitios [prov.]": 18_000,
    "Mantenimiento pozos y sensores [prov.]": 182_000,
    "Telecom / enlaces [prov.]": 10_000,
    "Seguros y permisos [prov.]": 25_000,
    "Capacitación y ejercicios CNE [prov.]": 20_000,
}
VIDA_UTIL = {"DAS (5)": 10.0, "SQUID superficie (5)": 10.0,       # [H] años
             "Rb-87 pozo (10)": 7.5, "Sondes Ti/PTFE (5)": 15.0,
             "Telecom ICE+LEO": 10.0}
VIDA_UTIL_TI_AMPLIADO = {"Cómputo OVSICORI": 7.0, "Gateway CB CNE": 7.0}   # [H] contraste

PHI_PRUDENTE = 0.40                    # [H] caso prudente ilustrativo: 2 de 5 eventos
GASTO_PUBLICO_PRUDENTE = 0.0


@dataclass(frozen=True)
class Escenario:
    nombre: str
    anio: int | None
    mw: float
    precursor: str
    dano_usd: float
    tipo: str          # "histórico" | "proyección" | "escenario"


ESCENARIOS = (
    Escenario("Limón", 1991, 7.6, "posible", 92e6, "histórico"),
    Escenario("Cinchona", 2009, 6.2, "ninguno", 100e6, "histórico"),
    Escenario("Nicoya", 2012, 7.6, "documentado", 45e6, "histórico"),
    Escenario("GAM", None, 6.5, "posible", 150e6, "escenario"),
    Escenario("Osa", 2035, 7.8, "documentado", 300e6, "proyección"),
)


# ══════════════════════════════════════════════════════════════════════════
#  2. FÍSICA DEL ENLACE ULF
# ══════════════════════════════════════════════════════════════════════════
def skin_depth_m(sigma: float, f_hz: float) -> float:
    """[V] Profundidad pelicular δ = √(2/(ωμ0σ))."""
    return math.sqrt(2.0 / (2.0 * math.pi * f_hz * MU0 * sigma))


def mu_eff_teorica(l_m: float, d_m: float, mu_r: float) -> tuple[float, float]:
    """[V] Permeabilidad efectiva de varilla (factor desmagnetizante de elipsoide)."""
    ld = l_m / d_m
    nd = (math.log(2 * ld) - 1) / ld ** 2
    return mu_r / (1 + nd * (mu_r - 1)), nd


def areas_m2(p: Params) -> tuple[float, float]:
    return math.pi * (p.d_core / 2) ** 2, math.pi * p.r_bobina_m ** 2


def magnetizacion_sat(p: Params) -> float:
    """[V] Ms = B_sat/μ0 (A/m)."""
    return p.b_sat_ferrita_t / MU0


def momento_lineal(mu_eff: float, p: Params) -> float:
    """[V] Momento dipolar lineal (A·m²).
    area_efectiva=True : m = N·I·[A_bobina + (μ_eff−1)·A_núcleo]
    area_efectiva=False: m = μ_eff·N·I·π·r²   (modelo v6.x, solo regresión)"""
    a_core, a_coil = areas_m2(p)
    if p.area_efectiva:
        return p.n_turns * p.i_a * (a_coil + (mu_eff - 1) * a_core)
    return mu_eff * p.n_turns * p.i_a * a_coil


def momento_saturado(p: Params) -> float:
    """[V] Tope físico: devanado en aire + núcleo magnetizado a B_sat."""
    a_core, a_coil = areas_m2(p)
    return p.n_turns * p.i_a * a_coil + magnetizacion_sat(p) * a_core * p.l_core


def momento_operativo(mu_eff: float, p: Params, sat: bool) -> float:
    m = momento_lineal(mu_eff, p)
    return min(m, momento_saturado(p)) if sat else m


def utilizacion_bsat(mu_eff: float, p: Params) -> float:
    """[V] M_lineal / Ms en el núcleo; > 1 significa que satura."""
    h0 = p.n_turns * p.i_a / p.l_core
    return (mu_eff - 1) * h0 / magnetizacion_sat(p)


def corriente_saturacion_a(mu_eff: float, p: Params) -> float:
    """[V] Corriente a la que M_lineal alcanza Ms."""
    return magnetizacion_sat(p) * p.l_core / ((mu_eff - 1) * p.n_turns)


def campo_pT(m: float, p: Params, d: float | None = None,
             sigma: float = SIGMA_REF) -> float:
    """[V] Campo axial de dipolo con atenuación pelicular, en pT."""
    d = p.depth_m if d is None else d
    return (MU0 * m / (2 * math.pi * d ** 3)
            * math.exp(-d / skin_depth_m(sigma, p.f_ulf)) * 1e12)


def snr_db(m: float, pc1_pT: float, p: Params, rej_db: float | None = None,
           d: float | None = None, sigma: float = SIGMA_REF) -> tuple[float, float]:
    """(SNR crudo, SNR procesado) en dB. [H] rechazo Pc1 y ganancia f·T."""
    rej = p.rej_db if rej_db is None else rej_db
    b = campo_pT(m, p, d, sigma)
    eff = pc1_pT / 10 ** (rej / 20)
    raw = 20 * math.log10(b / eff)
    return raw, raw + 10 * math.log10(p.f_ulf * p.t_bit)


def bits_requeridos(snr_proc: float, objetivo: float = SNR_OBJETIVO_DB,
                    max_bits: int = MAX_BITS) -> tuple[int, bool]:
    """Repeticiones de bit para alcanzar el SNR objetivo (forma cerrada)."""
    if snr_proc >= objetivo:
        return 1, True
    n = ceil(10 ** ((objetivo - snr_proc) / 10))
    return (n, True) if n <= max_bits else (max_bits, False)


def temperatura_fondo(grad_c_km: float, p: Params) -> float:
    return p.t_surf + grad_c_km * p.depth_m / 1000.0


def mu_termico(t_c: float, p: Params) -> float:
    """[H] Deriva lineal de μ con la temperatura."""
    return max(p.mu_min, p.mu_eff_design * (1 - p.derate_pct_per_c * max(0.0, t_c - 25.0)))


def potencia_media_w(p: Params) -> float:
    lw = p.n_turns * 2 * math.pi * p.r_bobina_m
    rc = p.rho_cu * lw / (p.a_cond_mm2 * 1e-6)
    return p.i_a ** 2 * rc * p.duty


def p_shear(mw: float) -> float:
    """[H] Probabilidad de cizalla del cable de pozo por magnitud."""
    return 1.0 / (1.0 + math.exp(-SHEAR_K * (mw - SHEAR_M0)))


# ══════════════════════════════════════════════════════════════════════════
#  3. ÁRBOL DE DECISIÓN (sin estado)
# ══════════════════════════════════════════════════════════════════════════
class Fase(IntEnum):
    ARCHIVADO = 0
    AMARILLA = 1
    NARANJA = 2
    PREALERTA = 3
    ROJA = 4


CODIGO_3BIT = {Fase.ARCHIVADO: "001", Fase.AMARILLA: "001", Fase.NARANJA: "010",
               Fase.PREALERTA: "010", Fase.ROJA: "111"}


@dataclass(frozen=True)
class Evento:
    energia: float
    umbral: float
    sensores: int
    nodos_adj: int
    p_bayes: float


@dataclass(frozen=True)
class ConfigArbol:
    p_fase3: float = 0.85
    lat_bayes_s: float = 1.8
    peso_minimo_roja: float = 0.50
    p_override: float = 0.95
    nodos_override: int = 3


@dataclass(frozen=True)
class Decision:
    fase: Fase
    codigo: str
    texto: str
    degradada: bool = False


def evaluar_evento(e: Evento, peso_canal: float = PESO_CABLE,
                   cfg: ConfigArbol = ConfigArbol()) -> Decision:
    """Cascada ARCHIVADO→ROJA. Una ROJA sostenida solo por un canal débil
    (peso < peso_minimo_roja) baja a PREALERTA, salvo consenso fuerte
    (P > p_override y nodos_adj ≥ nodos_override)."""
    if not 0.0 <= e.p_bayes <= 1.0:
        raise ValueError("p_bayes fuera de [0, 1]")
    if not 0.0 <= peso_canal <= 1.0:
        raise ValueError("peso_canal fuera de [0, 1]")

    def dec(f: Fase, txt: str, deg: bool = False) -> Decision:
        return Decision(f, CODIGO_3BIT[f], txt, deg)

    if e.energia <= e.umbral:
        return dec(Fase.ARCHIVADO, "Archivado — ruido local")
    if e.sensores < 3:
        return dec(Fase.AMARILLA, "Amarilla interna — 1-2 sensores")
    if e.nodos_adj < 2:
        return dec(Fase.NARANJA, "Naranja — informe OVSICORI/RSN")
    if e.p_bayes <= cfg.p_fase3:
        return dec(Fase.PREALERTA, f"Pre-alerta — P={e.p_bayes:.2f}")
    override = e.p_bayes > cfg.p_override and e.nodos_adj >= cfg.nodos_override
    if peso_canal < cfg.peso_minimo_roja and not override:
        return dec(Fase.PREALERTA,
                   f"ROJA→pre-alerta: peso_canal={peso_canal:.2f}<"
                   f"{cfg.peso_minimo_roja:.2f} sin consenso fuerte", True)
    return dec(Fase.ROJA,
               f"ROJA — Cell Broadcast (latencia bayesiana {cfg.lat_bayes_s} s)")


CASOS_ARBOL = (
    ("Radón aislado Arenal", 0.0, Evento(1.8, 1.5, 1, 0, 0.12), PESO_CABLE, Fase.AMARILLA),
    ("Anomalía GAM", 5.5, Evento(3.2, 1.5, 3, 1, 0.55), PESO_CABLE, Fase.NARANJA),
    ("Enjambre Osa", 6.2, Evento(5.1, 1.5, 5, 2, 0.78), PESO_CABLE, Fase.PREALERTA),
    ("Dilatancia GAM", 6.5, Evento(7.3, 1.5, 6, 3, 0.92), PESO_CABLE, Fase.ROJA),
    ("Megathrust Osa", 7.5, Evento(9.8, 1.5, 8, 4, 0.97), PESO_CABLE, Fase.ROJA),
)
_E_FUERTE = Evento(9.8, 1.5, 8, 4, 0.97)
_E_DEBIL = Evento(7.3, 1.5, 6, 2, 0.90)
CASOS_GATE = (
    ("Megathrust Osa, cable primario", _E_FUERTE, PESO_CABLE, Fase.ROJA),
    ("Megathrust Osa, solo ULF degradado, consenso fuerte", _E_FUERTE,
     PESO_ULF_DEGRADADO, Fase.ROJA),
    ("Evento menor, solo ULF degradado, sin consenso fuerte", _E_DEBIL,
     PESO_ULF_DEGRADADO, Fase.PREALERTA),
)


# ══════════════════════════════════════════════════════════════════════════
#  4. DETECCIÓN, DAÑOS Y RED
# ══════════════════════════════════════════════════════════════════════════
def prob_deteccion(mw: float, precursor: str) -> float:
    """[H] Pd heurística por magnitud y calidad del precursor."""
    base = (0.55 if mw < 6 else 0.60 if mw < 6.5 else 0.72 if mw < 7
            else 0.85 if mw < 7.5 else 0.92)
    return min(0.95, base * FACTOR_PRECURSOR[precursor])


def aviso_horas(mw: float) -> int:
    """[H] Horas de aviso por magnitud."""
    return 6 if mw < 6 else 18 if mw < 6.5 else 36 if mw < 7 else 60 if mw < 7.5 else 96


def fraccion_reducible(h: float) -> float:
    """[H] Fracción de daño evitable según horas de aviso."""
    return 0.20 if h <= 6 else 0.45 if h <= 24 else 0.70 if h <= 48 else 0.80


def deteccion_analitica(escenarios=ESCENARIOS) -> list[dict]:
    filas = []
    for s in escenarios:
        pd = prob_deteccion(s.mw, s.precursor)
        h = aviso_horas(s.mw)
        ahorro_si = s.dano_usd * fraccion_reducible(h) * EFICACIA_REDUCCION
        filas.append(dict(nombre=s.nombre, anio=s.anio, tipo=s.tipo, mw=s.mw,
                          precursor=s.precursor, pd=pd, aviso_h=h,
                          dano_musd=s.dano_usd / 1e6,
                          ahorro_si_detecta_musd=ahorro_si / 1e6,
                          ahorro_esperado_musd=pd * ahorro_si / 1e6))
    return filas


def deteccion_mc(rng: np.random.Generator, n: int, escenarios=ESCENARIOS) -> dict:
    pd = np.array([prob_deteccion(s.mw, s.precursor) for s in escenarios])
    ah = np.array([s.dano_usd * fraccion_reducible(aviso_horas(s.mw))
                   * EFICACIA_REDUCCION for s in escenarios]) / 1e6
    det = rng.random((n, len(escenarios))) < pd
    ahorro = (det * ah).sum(axis=1)
    fn = (~det).sum(axis=1)
    return dict(n=n, ahorro_medio_musd=float(ahorro.mean()),
                ahorro_se_musd=float(ahorro.std(ddof=1) / math.sqrt(n)),
                ahorro_p5_musd=float(np.percentile(ahorro, 5)),
                ahorro_p95_musd=float(np.percentile(ahorro, 95)),
                fn_medio=float(fn.mean()), n_eventos=len(escenarios))


def disponibilidad_nodo(modos=MODOS_FALLA) -> float:
    p_up = 1.0
    for _, p_ev, efic in modos:
        p_up *= 1 - p_ev * (1 - efic)
    return p_up


def p_min_k_analitica(n: int, k: int, q: float) -> float:
    return sum(comb(n, j) * q ** j * (1 - q) ** (n - j) for j in range(k, n + 1))


def red_analitica(p: Params, p_up: float, k: int = 3) -> float:
    return ((1 - P_REGIMEN_CORRELACIONADO) * p_min_k_analitica(p.n_nodos, k, p_up)
            + P_REGIMEN_CORRELACIONADO * p_min_k_analitica(p.n_nodos, k, P_UP_CORRELACIONADO))


def red_mc(rng: np.random.Generator, n: int, p: Params, p_up: float, k: int = 3) -> dict:
    q = np.where(rng.random(n) < P_REGIMEN_CORRELACIONADO, P_UP_CORRELACIONADO, p_up)
    activos = rng.binomial(p.n_nodos, q)
    frac = float((activos >= k).mean())
    return dict(n=n, p_min_k=frac, se=math.sqrt(frac * (1 - frac) / n))


# ══════════════════════════════════════════════════════════════════════════
#  5. ECONOMÍA
# ══════════════════════════════════════════════════════════════════════════
def ciclos_reemplazo(vida_anos: float, horizonte: int = 30) -> int:
    """[V] Compras de reposición dentro del horizonte (ceil, no int)."""
    if vida_anos <= 0:
        raise ValueError("vida_anos debe ser > 0")
    return max(0, ceil(horizonte / vida_anos) - 1)


def calendario_reemplazos(vidas: dict[str, float], horizonte: int) -> list[tuple[float, str, float]]:
    cal = []
    for partida, vida in vidas.items():
        for k in range(1, ciclos_reemplazo(vida, horizonte) + 1):
            cal.append((k * vida, partida, float(CAPEX_BASE[partida])))
    return sorted(cal)


def factor_anualidad(r: float, n: int) -> float:
    return sum(1 / (1 + r) ** t for t in range(1, n + 1))


def beneficio_catalogo(p: Params, phi: float | None = None,
                       gasto: float | None = None) -> dict:
    """Beneficio material esperado en el horizonte, sin VSL.

    privado = Σ_eventos Pd·daño·fracción_reducible·eficacia
    público = gasto_por_evento · Σ_eventos Pd
    ambos × φ (parte del catálogo que ocurre en el horizonte).
    El catálogo mezcla sismos ya ocurridos con un escenario y una proyección:
    φ=1 equivale a suponer los cinco dentro de los próximos 30 años [H].
    """
    phi = p.fraccion_eventos_horizonte if phi is None else phi
    gasto = p.gasto_publico_por_evento_usd if gasto is None else gasto
    filas = deteccion_analitica()
    priv = sum(f["ahorro_esperado_musd"] for f in filas) * 1e6 * phi
    pub = gasto * sum(f["pd"] for f in filas) * phi
    return dict(phi=phi, gasto=gasto, privado=priv, publico=pub, total=priv + pub,
                promedio_dano_privado=sum(f["dano_musd"] for f in filas) / len(filas) * 1e6,
                detalle=filas)


def valorar(p: Params, capex_t: float, opex1: float, calendario: list,
            *, beneficio_30: float, r: float | None = None,
            opex_factor: float = 1.0) -> dict:
    r = p.r_disc if r is None else r
    n = p.years
    reemplazos = sum(m for _, _, m in calendario)
    opex_t = [opex1 * opex_factor * (1 + p.inflacion) ** (t - 1) for t in range(1, n + 1)]
    opex_30 = sum(opex_t)
    total_30 = capex_t + opex_30 + reemplazos
    benef_a = beneficio_30 / n
    af = factor_anualidad(r, n)
    pvb = benef_a * af
    # Convención sellada: reemplazos prorrateados en partes iguales
    pvc = capex_t + sum((opex_t[t - 1] + reemplazos / n) / (1 + r) ** t
                        for t in range(1, n + 1))
    # Contraste: cada reposición en su año real
    pvc_cal = (capex_t + sum(o / (1 + r) ** t for t, o in enumerate(opex_t, 1))
               + sum(m / (1 + r) ** a for a, _, m in calendario))
    return dict(opex_30=opex_30, reemplazos=reemplazos, total_30=total_30,
                benef_total_30=beneficio_30, benef_anual=benef_a,
                bc_simple=beneficio_30 / total_30, pvb=pvb, pvc=pvc,
                van=pvb - pvc, bc_desc=pvb / pvc,
                pvc_cal=pvc_cal, van_cal=pvb - pvc_cal, bc_desc_cal=pvb / pvc_cal,
                factor_equilibrio=pvc / pvb)       # fracción del beneficio modelado que cubre el costo


# ══════════════════════════════════════════════════════════════════════════
#  6. CÁLCULO DE ENLACE
# ══════════════════════════════════════════════════════════════════════════
def calcular_enlace(p: Params, sat: bool) -> dict:
    mu_th, nd = mu_eff_teorica(p.l_core, p.d_core, p.mu_r)
    m_ref = momento_operativo(p.mu_eff_design, p, sat)
    b_ref = campo_pT(m_ref, p)
    snr_pc1 = {c: snr_db(m_ref, v, p)[1] for c, v in PC1_RUIDO.items()}
    snr_tip = snr_pc1["Típico diurno"]

    kp = []
    for k0, k1, nombre, pc1 in KP_BANDAS:
        proc = snr_db(m_ref, pc1, p)[1]
        nbit, ok = bits_requeridos(proc)
        kp.append(dict(kp=f"{k0}–{k1}", nombre=nombre, pc1_pT=pc1, snr_dB=proc,
                       bits=nbit, t_tx_s=nbit * p.t_bit, alcanzado=ok,
                       snr_eff_dB=proc + 10 * math.log10(nbit)))
    tormenta = kp[-1]
    t_storm = tormenta["t_tx_s"]
    peso_storm = PESO_ULF_OK if t_storm <= T_MAX_ULF_S else PESO_ULF_DEGRADADO

    snr_estres = snr_db(m_ref, 60.0, p, rej_db=REJ_ESTRES_DB)[1]
    t_an = temperatura_fondo(GRAD_ESTRES, p)
    mu_an = mu_termico(t_an, p)
    snr_an = snr_db(momento_operativo(mu_an, p, sat), 60.0, p)[1]

    t_pozo = temperatura_fondo(p.grad_termico, p)
    mu_T = mu_termico(t_pozo, p)
    snr_T = snr_db(momento_operativo(mu_T, p, sat), 60.0, p)[1]

    lito = [dict(nombre=n, sigma=s, snr_dB=snr_db(m_ref, 60.0, p, sigma=s)[1])
            for n, s in LITOLOGIAS]

    termico = []
    for g in range(20, 61, 5):
        tf = temperatura_fondo(g, p)
        mf = mu_termico(tf, p)
        termico.append(dict(grad=g, t_fondo=tf, mu_T=mf,
                            snr_dB=snr_db(momento_operativo(mf, p, sat), 60.0, p)[1]))

    majors = [p_shear(m) for m in MW_EVENTOS_MAYORES]
    return dict(
        modo="con_saturacion" if sat else "lineal",
        i_a=p.i_a, mu_teorica=mu_th, nd=nd, m_ref=m_ref, b_ref_pT=b_ref,
        margen_fabrica_dB=20 * math.log10(mu_th / p.mu_eff_design),
        potencia_media_W=potencia_media_w(p),
        snr_por_pc1=snr_pc1, snr_tipico_dB=snr_tip, kp=kp,
        tormenta=dict(nbit=tormenta["bits"], t_tx_s=t_storm,
                      majority_ok=3 * t_storm <= T_MAX_ULF_S, peso_canal=peso_storm),
        estres=dict(rej_db=REJ_ESTRES_DB, snr_dB=snr_estres,
                    peso_canal=PESO_ULF_RECHAZO_DEGRADADO,
                    grad=GRAD_ESTRES, t_fondo=t_an, mu_T=mu_an, snr_geo_dB=snr_an),
        t_pozo=t_pozo, mu_T=mu_T, snr_Tpozo_dB=snr_T,
        litologias=lito, snr_peor_lito_dB=min(x["snr_dB"] for x in lito),
        termico=termico,
        shear=dict(por_mw={m: p_shear(m) for m in (6.0, 6.5, 7.0, 7.5, 7.8, 8.0)},
                   p_ulf_necesario=float(np.mean(majors))),
    )


def verificaciones(p: Params) -> dict:
    """Comprobaciones de diseño: saturación, margen, geometría y μ_eff."""
    mu_th, _ = mu_eff_teorica(p.l_core, p.d_core, p.mu_r)
    a_core, a_coil = areas_m2(p)
    m_lin = momento_lineal(p.mu_eff_design, p)
    m_sat = momento_saturado(p)
    util = utilizacion_bsat(p.mu_eff_design, p)
    i_sat = corriente_saturacion_a(p.mu_eff_design, p)
    i_margen = min(p.i_a, p.util_bsat_objetivo * i_sat)
    b_nucleo = MU0 * p.mu_eff_design * p.n_turns * p.i_a / p.l_core

    barrido = {}
    for b in (0.35, 0.40, 0.45, 0.55):
        pb = replace(p, b_sat_ferrita_t=b)
        ratio = momento_lineal(p.mu_eff_design, pb) / momento_saturado(pb)
        barrido[f"{b:.2f}"] = dict(
            utilizacion=utilizacion_bsat(p.mu_eff_design, pb),
            perdida_dB=20 * math.log10(max(1.0, ratio)),
            snr_tipico_dB=snr_db(momento_operativo(p.mu_eff_design, pb, True), 60.0, pb)[1])

    d_hilo_mm = math.sqrt(4 * p.a_cond_mm2 / math.pi)
    vueltas_capa = int(p.l_core * 1000 / d_hilo_mm)
    d_ext_bob = 2 * p.r_bobina_m * 1000 + d_hilo_mm
    d_int_sonda = p.d_sonde_mm - 2 * p.espesor_pared_sonde_mm
    holgura = (d_int_sonda - d_ext_bob) / 2
    hueco_nucleo = (2 * p.r_bobina_m * 1000 - d_hilo_mm - p.d_core * 1000) / 2
    masa_fer = p.rho_fer * a_core * p.l_core
    masa_cu = 8960.0 * p.n_turns * 2 * math.pi * p.r_bobina_m * p.a_cond_mm2 * 1e-6

    m_area = p.n_turns * p.i_a * (a_coil + (p.mu_eff_design - 1) * a_core)
    m_sin_area = p.mu_eff_design * p.n_turns * p.i_a * a_coil

    # Escenario con margen de saturación
    en_margen = calcular_enlace(replace(p, i_a=i_margen), True)
    return dict(
        saturacion=dict(
            b_nucleo_T=b_nucleo, b_sat_T=p.b_sat_ferrita_t, utilizacion=util,
            objetivo=p.util_bsat_objetivo, excede=util > 1.0,
            sin_margen=util > p.util_bsat_objetivo,
            m_lineal=m_lin, m_saturado=m_sat,
            perdida_dB=20 * math.log10(max(1.0, m_lin / m_sat)),
            corriente_saturacion_A=i_sat, i_con_margen_A=i_margen,
            barrido_bsat=barrido),
        con_margen=dict(
            i_a=i_margen, snr_tipico_dB=en_margen["snr_tipico_dB"],
            snr_estres_dB=en_margen["estres"]["snr_dB"],
            tormenta_bits=en_margen["tormenta"]["nbit"],
            tormenta_alcanzado=en_margen["kp"][-1]["alcanzado"],
            tormenta_t_s=en_margen["tormenta"]["t_tx_s"],
            potencia_W=en_margen["potencia_media_W"]),
        geometria=dict(
            d_hilo_mm=d_hilo_mm, vueltas_por_capa=vueltas_capa,
            una_capa_ok=vueltas_capa >= p.n_turns,
            d_ext_bobina_mm=d_ext_bob, d_int_sonda_mm=d_int_sonda,
            holgura_radial_mm=holgura, holgura_min_mm=HOLGURA_MIN_MM,
            ajuste_ok=holgura >= HOLGURA_MIN_MM,
            hueco_nucleo_bobina_mm=hueco_nucleo,
            masa_ferrita_kg=masa_fer, masa_cobre_kg=masa_cu,
            nucleo_cabe_en_sonda=p.l_core <= p.l_sonde_m),
        mu=dict(teorica=mu_th, diseno=p.mu_eff_design,
                margen_dB=20 * math.log10(mu_th / p.mu_eff_design),
                ok=mu_th >= p.mu_eff_design),
        area_nucleo=dict(m_con_area=m_area, m_sin_area=m_sin_area,
                         correccion_dB=20 * math.log10(m_area / m_sin_area)),
    )


# ══════════════════════════════════════════════════════════════════════════
#  7. SIMULACIÓN COMPLETA (sin imprimir)
# ══════════════════════════════════════════════════════════════════════════
def simular(p: Params = P0, seed: int = SEED, saturacion: bool = True,
            n_mc: int = 100_000) -> dict:
    ss = np.random.SeedSequence(seed)
    rng_det, rng_red = (np.random.default_rng(s) for s in ss.spawn(2))

    dias_pozo = p.depth_m / p.rop_m_dia
    dias_nodo = dias_pozo + p.dias_compl
    meses_red = dias_nodo * p.n_nodos / p.n_equipos / 30

    enlace_lin = calcular_enlace(p, False)
    enlace_sat = calcular_enlace(p, True)
    principal = enlace_sat if saturacion else enlace_lin
    ver = verificaciones(p)

    # Costos
    sub = sum(CAPEX_BASE.values())
    cont = int(round(sub * p.contingencia_pct))
    capex_t = sub + cont
    opex1 = sum(OPEX_ANUAL.values())
    cal = calendario_reemplazos(VIDA_UTIL, p.years)
    cal_amp = calendario_reemplazos({**VIDA_UTIL, **VIDA_UTIL_TI_AMPLIADO}, p.years)

    ben = beneficio_catalogo(p)
    val = valorar(p, capex_t, opex1, cal, beneficio_30=ben["total"])
    val_amp = valorar(p, capex_t, opex1, cal_amp, beneficio_30=ben["total"])
    ben_pr = beneficio_catalogo(p, phi=PHI_PRUDENTE, gasto=GASTO_PUBLICO_PRUDENTE)
    val_pr = valorar(p, capex_t, opex1, cal, beneficio_30=ben_pr["total"])
    ben_priv1 = beneficio_catalogo(p, phi=1.0, gasto=0.0)
    val_priv1 = valorar(p, capex_t, opex1, cal, beneficio_30=ben_priv1["total"])
    phi_eq_total = val["factor_equilibrio"] * p.fraccion_eventos_horizonte
    phi_eq_priv = val_priv1["factor_equilibrio"]

    sens_r = {f"{r:.2f}": dict(van=(v := valorar(p, capex_t, opex1, cal,
                                                 beneficio_30=ben["total"], r=r))["van"],
                               bc_desc=v["bc_desc"])
              for r in (0.03, 0.06, 0.08, 0.12)}
    sens_opex = {f"opex{int(f * 100)}": valorar(p, capex_t, opex1, cal,
                                                beneficio_30=ben["total"], opex_factor=f)["bc_desc"]
                 for f in (0.8, 1.0, 1.2, 1.4)}
    sens_phi = {}
    for phi in (0.2, 0.4, 0.6, 0.8, 1.0):
        fila = {}
        for etiqueta, g in (("con_gasto_publico", p.gasto_publico_por_evento_usd),
                            ("solo_privado", 0.0)):
            b_ = beneficio_catalogo(p, phi=phi, gasto=g)
            fila[etiqueta] = valorar(p, capex_t, opex1, cal, beneficio_30=b_["total"])["bc_desc"]
        sens_phi[f"{phi:.1f}"] = fila
    sens_gasto = {f"{int(g / 1e6)}M": valorar(
        p, capex_t, opex1, cal,
        beneficio_30=beneficio_catalogo(p, gasto=g)["total"])["bc_desc"]
        for g in (0.0, 10e6, 25e6, 50e6)}

    # Detección y red
    det_an = deteccion_analitica()
    det_mc = deteccion_mc(rng_det, n_mc)
    det_an_total = sum(f["ahorro_esperado_musd"] for f in det_an)
    p_up = disponibilidad_nodo()
    p3_an = red_analitica(p, p_up)
    p3_mc = red_mc(rng_red, n_mc, p, p_up)

    arbol = [dict(nombre=n, mw=mw, peso=peso, esperado=int(exp),
                  **_dec_dict(evaluar_evento(ev, peso)))
             for n, mw, ev, peso, exp in CASOS_ARBOL]
    gate = [dict(etiqueta=et, peso=peso, esperado=int(exp),
                 **_dec_dict(evaluar_evento(ev, peso)))
            for et, ev, peso, exp in CASOS_GATE]

    res = dict(
        schema=SCHEMA, version=VERSION, inventor=INVENTOR,
        fecha_divulgacion=FECHA_DIVULGACION, semilla=seed,
        modo_principal=principal["modo"],
        parametros=asdict(p),
        despliegue=dict(dias_pozo=dias_pozo, dias_nodo=dias_nodo, meses_red=meses_red,
                        n_equipos=p.n_equipos, masa_ferrita_kg=ver["geometria"]["masa_ferrita_kg"]),
        potencia_media_W=principal["potencia_media_W"],
        enlace_principal=principal, enlace_lineal=enlace_lin, enlace_saturado=enlace_sat,
        arbol=arbol, gate_canal=gate,
        deteccion=dict(por_escenario=det_an, ahorro_esperado_musd=det_an_total, mc=det_mc),
        costos=dict(capex_subtotal=sub, contingencia=cont, capex=capex_t,
                    capex_partidas=dict(CAPEX_BASE), opex_partidas=dict(OPEX_ANUAL),
                    vida_util=dict(VIDA_UTIL), opex_anual=opex1, **val,
                    beneficio_privado_30=ben["privado"], beneficio_publico_30=ben["publico"],
                    promedio_dano_privado=ben["promedio_dano_privado"],
                    calendario=[dict(anio=a, partida=n, usd=m) for a, n, m in cal],
                    cobertura_reemplazos=dict(
                        partidas_con_reposicion=len(VIDA_UTIL), partidas_capex=len(CAPEX_BASE),
                        escenario_ti_ampliado=dict(
                            reemplazos=val_amp["reemplazos"], van=val_amp["van"],
                            bc_desc=val_amp["bc_desc"])),
                    caso_prudente=dict(phi=PHI_PRUDENTE, gasto=GASTO_PUBLICO_PRUDENTE,
                                       beneficio_30=ben_pr["total"], van=val_pr["van"],
                                       bc_desc=val_pr["bc_desc"]),
                    equilibrio=dict(phi_total=phi_eq_total, phi_solo_privado=phi_eq_priv,
                                    factor_beneficio=val["factor_equilibrio"])),
        sensibilidad=dict(tasa_descuento=sens_r, opex_bc_desc=sens_opex,
                          phi_bc_desc=sens_phi, gasto_publico_bc_desc=sens_gasto),
        red=dict(disp_nodo=p_up, p_min3_analitica=p3_an, p_min3_mc=p3_mc),
        latencia=dict(cable_s=T_CABLE_S, ulf_s=T_ULF_S, fa_anual=FA_ANUAL,
                      nota="Supuestos de diseño [H], no calculados por este modelo"),
        verificaciones=ver,
    )
    res["hallazgos"] = construir_hallazgos(p, res)
    res["supuestos"] = SUPUESTOS
    return res


def _dec_dict(d: Decision) -> dict:
    return dict(fase=int(d.fase), fase_nombre=d.fase.name, codigo=d.codigo,
                texto=d.texto, degradada=d.degradada)


SUPUESTOS = [
    dict(id="H01", tag="H", tema="Rechazo de ruido Pc1 = 30 dB (referencia remota)",
         impacto="A 10 dB el SNR típico cae por debajo del umbral de 20 dB"),
    dict(id="H02", tag="H", tema="Ganancia de integración 10·log10(f·T) usa la frecuencia de portadora como ancho de banda de ruido",
         impacto="Aporta 17.8 dB del SNR procesado"),
    dict(id="H03", tag="H", tema="μ_eff de diseño = 200 (teórico 236 con Ø0.14 m); núcleo de 4 m ensamblado por segmentos",
         impacto="Margen de fábrica de 1.5 dB; juntas reducen μ_eff"),
    dict(id="H04", tag="H", tema="B_sat de la ferrita = 0.40 T a temperatura de pozo (verificar con hoja de datos)",
         impacto="Con I = 6.3 A el núcleo opera al 98 % de B_sat"),
    dict(id="H05", tag="H", tema="Pd, horas de aviso, fracción reducible y eficacia 0.7 no están validadas con datos",
         impacto="Determina el beneficio por daños evitados"),
    dict(id="H06", tag="H", tema="Daños de cada escenario sísmico (USD)", impacto="Beneficio privado"),
    dict(id="H07", tag="H", tema="Gasto público evitado = USD 25 M por evento detectado, independiente de la magnitud y sin reducción",
         impacto="≈ 25 % del beneficio base; posible doble conteo con los daños"),
    dict(id="H08", tag="H", tema="Catálogo de 5 sismos (3 ya ocurridos) tratado como portafolio de 30 años (φ = 100 %)",
         impacto="El B/C escala linealmente con φ"),
    dict(id="H09", tag="H", tema="OPEX anual USD 398 k; montos del código v6.x, rótulos provisionales asignados en v7.1",
         impacto="≈ 75 % del costo a 30 años"),
    dict(id="H10", tag="H", tema="Vidas útiles: Rb-87 7.5 a, sondas 15 a, DAS/SQUID/telecom 10 a",
         impacto="Fondo de reemplazos (5 de 14 partidas)"),
    dict(id="H11", tag="H", tema="Tasa de descuento 6 %, inflación 3.5 %", impacto="Confirmar tasa social oficial con MIDEPLAN"),
    dict(id="H12", tag="H", tema="Modos de falla de nodo y régimen correlacionado 8 % / 0.55", impacto="Disponibilidad de red"),
    dict(id="H13", tag="H", tema="P(cizalla): k=1.937, M0=7.581; calibración no documentada", impacto="P(ULF necesario)"),
    dict(id="H14", tag="H", tema="Latencias 5.7/7.3 s y falsas alarmas 0.05/año son constantes, no cálculos", impacto="KPIs de servicio"),
    dict(id="H15", tag="H", tema="Pesos de canal 1.00 / 0.70 / 0.40 / 0.35 (política de decisión)", impacto="Compuerta ROJA→pre-alerta"),
    dict(id="H16", tag="H", tema="σ basalto húmedo 1.2e-4 S/m", impacto="Atenuación ≤ 2.1 dB en todo el rango"),
    dict(id="H17", tag="H", tema="Pared de sonda 6 mm y holgura radial mínima 5 mm", impacto="Ajuste de la bobina en la sonda"),
    dict(id="H18", tag="H", tema="Utilización máxima recomendada de B_sat = 80 %", impacto="Corriente con margen ≈ 5.1 A"),
    dict(id="V01", tag="V", tema="Profundidad pelicular, campo de dipolo, μ_eff de varilla, momento con área de núcleo, ceil() en reposiciones, valor presente",
         impacto="Fórmulas estándar"),
]


def construir_hallazgos(p: Params, r: dict) -> list[dict]:
    v = r["verificaciones"]
    sa, mg, ge, mu = v["saturacion"], v["con_margen"], v["geometria"], v["mu"]
    c = r["costos"]
    e = r["enlace_principal"]
    pr, eq = c["caso_prudente"], c["equilibrio"]
    h: list[dict] = []

    # F1 — saturación / margen
    sev = "ALTO" if sa["excede"] else ("MEDIO" if sa["sin_margen"] else "BAJO")
    b35 = sa["barrido_bsat"]["0.35"]
    h.append(dict(
        id="F1", severidad=sev,
        titulo=(f"Núcleo operando al {sa['utilizacion'] * 100:.0f} % de B_sat "
                f"(objetivo ≤ {sa['objetivo'] * 100:.0f} %)"),
        detalle=(f"I = {p.i_a:.1f} A frente a I_sat = {sa['corriente_saturacion_A']:.1f} A "
                 f"(B_sat = {sa['b_sat_T']:.2f} T supuesto, H04). Si la ferrita satura a 0.35 T "
                 f"se pierden {b35['perdida_dB']:.1f} dB. Con margen (I = {mg['i_a']:.1f} A): "
                 f"SNR típico {e['snr_tipico_dB']:.1f}→{mg['snr_tipico_dB']:.1f} dB, "
                 f"estrés {e['estres']['snr_dB']:.1f}→{mg['snr_estres_dB']:.1f} dB, "
                 f"potencia {e['potencia_media_W']:.1f}→{mg['potencia_W']:.1f} W; en tormenta "
                 + (f"{mg['tormenta_bits']} repeticiones." if mg["tormenta_alcanzado"]
                    else f"el objetivo de 20 dB no se alcanza ni con {MAX_BITS} repeticiones.")),
        accion="Confirmar B_sat con el fabricante; si es < 0.40 T, reducir I a la corriente con margen."))

    # F2 — enlace bajo estrés
    est, tor = e["estres"], e["tormenta"]
    sev = "MEDIO" if (est["snr_dB"] < SNR_OBJETIVO_DB or tor["t_tx_s"] > T_MAX_ULF_S) else "BAJO"
    falta = max(0.0, SNR_OBJETIVO_DB - est["snr_dB"])
    h.append(dict(
        id="F2", severidad=sev, titulo="El enlace ULF no cierra con rechazo degradado ni en tormenta",
        detalle=(f"Con rechazo de {est['rej_db']:.0f} dB el SNR diurno es {est['snr_dB']:.1f} dB "
                 f"(faltan {falta:.1f} dB para {SNR_OBJETIVO_DB:.0f}). En tormenta (Kp ≥ 7) se "
                 f"requieren {tor['nbit']} repeticiones = {tor['t_tx_s']:.0f} s, por encima de "
                 f"T_max = {T_MAX_ULF_S} s: el canal queda con peso {tor['peso_canal']:.2f} y no "
                 f"autoriza la ROJA por sí solo salvo consenso fuerte."),
        accion="Documentar que en tormenta el ULF solo respalda; mejorar rechazo o momento si se exige cobertura."))

    # F3 — geometría y μ
    problemas = []
    if not ge["ajuste_ok"]:
        problemas.append(f"holgura radial bobina–sonda {ge['holgura_radial_mm']:.1f} mm "
                         f"(< {ge['holgura_min_mm']:.0f} mm; Ø exterior bobina {ge['d_ext_bobina_mm']:.1f} mm, "
                         f"interior útil {ge['d_int_sonda_mm']:.0f} mm con pared de {p.espesor_pared_sonde_mm:.0f} mm [H])")
    if not ge["una_capa_ok"]:
        problemas.append(f"una capa admite {ge['vueltas_por_capa']} vueltas < {p.n_turns}")
    if mu["margen_dB"] < 3.0:
        problemas.append(f"μ_eff de diseño {mu['diseno']:.0f} vs teórico {mu['teorica']:.0f} "
                         f"(margen {mu['margen_dB']:.1f} dB)")
    h.append(dict(
        id="F3", severidad="MEDIO" if problemas else "BAJO",
        titulo="Geometría de la sonda y margen de μ_eff",
        detalle=("; ".join(problemas) if problemas else "Sin observaciones geométricas")
        + f". Masa: ferrita {ge['masa_ferrita_kg']:.0f} kg, cobre {ge['masa_cobre_kg']:.0f} kg. "
          "Un núcleo de 4 m se arma con segmentos y las juntas reducen μ_eff.",
        accion="Validar en diseño mecánico y banco de pruebas con núcleo a escala."))

    # F4 — beneficios
    h.append(dict(
        id="F4", severidad="ALTO",
        titulo="El B/C descansa en el catálogo completo y en un gasto público sin base",
        detalle=(f"Se suman 5 sismos (3 ya ocurridos) como si todos ocurrieran en {p.years} años "
                 f"(φ = {p.fraccion_eventos_horizonte * 100:.0f} %) y se añaden "
                 f"USD {p.gasto_publico_por_evento_usd / 1e6:.0f} M por evento detectado sin "
                 f"reducción ni relación con la magnitud (posible doble conteo con los daños). "
                 f"B/C base {c['bc_desc']:.1f}:1; caso prudente (φ = {pr['phi'] * 100:.0f} %, sin gasto "
                 f"público) {pr['bc_desc']:.1f}:1; equilibrio con φ = {eq['phi_solo_privado'] * 100:.0f} % "
                 f"(solo daños privados)."),
        accion="Sustituir el catálogo por tasas de recurrencia por zona y fundamentar el gasto público con la CNE."))

    # F5 — detección
    h.append(dict(
        id="F5", severidad="ALTO", titulo="La eficacia de detección no está validada",
        detalle="Pd, horas de aviso y fracción reducible (H05) son heurísticas. Ningún método de "
                "precursores tiene hoy eficacia demostrada de predicción a corto plazo.",
        accion="Presentar como hipótesis a validar con red piloto y métricas de aceptación."))

    # F6 — reemplazos
    ta = c["cobertura_reemplazos"]["escenario_ti_ampliado"]
    h.append(dict(
        id="F6", severidad="MEDIO", titulo="Fondo de reemplazos parcial",
        detalle=(f"Repone {c['cobertura_reemplazos']['partidas_con_reposicion']} de "
                 f"{c['cobertura_reemplazos']['partidas_capex']} partidas. Con refresco de cómputo y "
                 f"gateway cada 7 años (H): reemplazos USD {ta['reemplazos']:,.0f}, B/C {ta['bc_desc']:.1f}:1."),
        accion="Confirmar si el OPEX ya incluye el refresco de TI."))

    # F7 — OPEX
    h.append(dict(
        id="F7", severidad="MEDIO", titulo="Rótulos del OPEX provisionales",
        detalle=(f"USD {c['opex_anual']:,.0f}/año en 7 partidas cuyos montos vienen del código v6.x "
                 "sin nombre; los rótulos se asignaron en v7.1 sin respaldo documental."),
        accion="Confirmar cada partida contra el presupuesto real antes de entregarlo a Hacienda/MIDEPLAN."))

    # F8 — constantes presentadas como resultados
    h.append(dict(
        id="F8", severidad="MEDIO", titulo="Latencia y falsas alarmas son constantes",
        detalle="5.7 s / 7.3 s y 0.05 FA/año se presentaban como resultados; son supuestos (H14).",
        accion="Sustituir por presupuesto de latencia medido y tasa de FA de la red piloto."))
    return h


# ══════════════════════════════════════════════════════════════════════════
#  8. SALIDA
# ══════════════════════════════════════════════════════════════════════════
def guardar_json(res: dict, ruta: Path) -> Path:
    """Escritura atómica; los errores se propagan."""
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=ruta.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2, ensure_ascii=False, default=_json_default)
        os.replace(tmp, ruta)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return ruta


def _json_default(o):
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, IntEnum):
        return int(o)
    raise TypeError(f"No serializable: {type(o)}")


def _est(snr: float) -> str:
    return "✓" if snr >= 20 else ("⚠" if snr >= 10 else "⛔")


def imprimir(res: dict, p: Params) -> None:
    L, R = "═" * ANCHO, "─" * ANCHO
    e = res["enlace_principal"]
    lin, sat = res["enlace_lineal"], res["enlace_saturado"]
    c, d, v = res["costos"], res["despliegue"], res["verificaciones"]
    sa, mg, ge, mu = v["saturacion"], v["con_margen"], v["geometria"], v["mu"]
    print(L)
    print(f" GEO-PROBE CR — v{VERSION}")
    print(f" {INVENTOR} · semilla {res['semilla']} · KPI principal: {e['modo']}")
    print(L)

    print(f"\n[A] DESPLIEGUE — PERFORACIÓN CONVENCIONAL\n")
    print(f"  Pozo Ø{p.d_hole_mm:.0f} mm × {p.depth_m:.0f} m · Sonde Ø{p.d_sonde_mm:.0f} mm × {p.l_sonde_m} m")
    print(f"  ROP {p.rop_m_dia:.0f} m/día · {d['dias_nodo']:.1f} d/nodo · {p.n_nodos} nodos con "
          f"{p.n_equipos} equipos: {d['meses_red']:.1f} meses · Reactor ELIMINADO")

    print(f"\n{R}\n[B] ENLACE ULF — μ diseño={p.mu_eff_design:.0f} · I={p.i_a:.1f} A · núcleo Ø{p.d_core * 1000:.0f} mm\n")
    print(f"  μ_th={e['mu_teorica']:.0f} · Nd={e['nd']:.5f} · masa ferrita={ge['masa_ferrita_kg']:.0f} kg · "
          f"m={e['m_ref']:.3e} A·m² · B={e['b_ref_pT']:.1f} pT")
    print(f"  Margen de fábrica: {e['margen_fabrica_dB']:.1f} dB · Potencia media: {e['potencia_media_W']:.1f} W")

    print(f"\n  [B1] SNR vs Pc1 (rechazo {p.rej_db:.0f} dB)")
    for cond, pc1 in PC1_RUIDO.items():
        s_ = e["snr_por_pc1"][cond]
        print(f"    {cond:<26} {pc1:>6.0f} pT  SNR={s_:5.1f} dB {_est(s_)}")

    print(f"\n  [B2] Protocolo Kp adaptativo")
    for k in e["kp"]:
        print(f"    Kp {k['kp']:<4} {k['nombre']:<10} bits={k['bits']:>2}  "
              f"T_tx={k['t_tx_s']:>5.0f}s  SNReff={k['snr_eff_dB']:5.1f} dB")

    t = e["tormenta"]
    print(f"\n  [B3] Correcciones de canal · T_max ULF={T_MAX_ULF_S / 60:.0f} min")
    print(f"    Tormenta: nbit={t['nbit']} T_tx={t['t_tx_s']:.0f}s · "
          f"mayoría 2-de-3 {'✓' if t['majority_ok'] else '✗ (excede T_max)'} · "
          f"resuelve a peso_canal={t['peso_canal']:.2f}")
    print(f"    Pesos de referencia: cable={PESO_CABLE:.2f} | ULF a tiempo={PESO_ULF_OK:.2f} | "
          f"ULF degradado={PESO_ULF_DEGRADADO:.2f} | rechazo degradado={PESO_ULF_RECHAZO_DEGRADADO:.2f}")

    es = e["estres"]
    print(f"\n  [B4] Estrés")
    print(f"    Rechazo {p.rej_db:.0f}→{es['rej_db']:.0f} dB: SNR diurno={es['snr_dB']:.1f} dB {_est(es['snr_dB'])} · "
          f"peso_canal={es['peso_canal']:.2f} → ROJA bloqueada")
    print(f"    Gradiente {es['grad']:.0f}°C/km: T_fondo={es['t_fondo']:.0f}°C · μ_T={es['mu_T']:.0f} · "
          f"SNR={es['snr_geo_dB']:.1f} dB {_est(es['snr_geo_dB'])}")

    print(f"\n  [B5] Litologías (Pc1 típico)")
    for x in e["litologias"]:
        print(f"    {x['nombre']:<22} σ={x['sigma']:.1e}  SNR={x['snr_dB']:5.1f} dB")
    print(f"\n  [B6] T@{p.depth_m:.0f}m={e['t_pozo']:.0f}°C · μ_T={e['mu_T']:.0f} · SNR@T={e['snr_Tpozo_dB']:.1f} dB")

    print(f"\n  [B7] P(cizalla) k={SHEAR_K} M0={SHEAR_M0}")
    for mw, ps in e["shear"]["por_mw"].items():
        modo = "cable OK" if ps < 0.15 else ("mixto" if ps <= 0.35 else "ULF probable")
        print(f"    Mw {mw:.1f}  P={ps * 100:5.1f}%  {modo}")
    print(f"  → P(ULF necesario): {e['shear']['p_ulf_necesario'] * 100:.0f}%")

    print(f"\n  [B8] Perfil térmico (SCADA)")
    print(f"  {'Grad °C/km':>12} {'T_fondo':>9} {'μ_T':>7} {'SNR dB':>8}  perfil (20–45 dB)")
    for x in e["termico"]:
        n = max(0, min(30, int((x["snr_dB"] - 20) / 25 * 30)))
        print(f"  {x['grad']:>12} {x['t_fondo']:>9.1f} {x['mu_T']:>7.1f} {x['snr_dB']:>8.1f}  "
              f"{'█' * n}{'░' * (30 - n)}")

    print(f"\n  [B9] VERIFICACIONES DE DISEÑO\n")
    print(f"    Saturación: B núcleo={sa['b_nucleo_T']:.3f} T · B_sat={sa['b_sat_T']:.2f} T · "
          f"utilización {sa['utilizacion'] * 100:.1f} % (objetivo ≤ {sa['objetivo'] * 100:.0f} %) · "
          f"{'EXCEDE' if sa['excede'] else ('SIN MARGEN' if sa['sin_margen'] else 'con margen')}")
    print(f"    I_sat={sa['corriente_saturacion_A']:.2f} A · I con margen={sa['i_con_margen_A']:.2f} A · "
          f"pérdida por saturación={sa['perdida_dB']:.1f} dB")
    print(f"    {'Indicador':<30} {'Diseño':>9} {'Con margen':>11}")
    for et, a_, b_ in (("SNR típico (dB)", e["snr_tipico_dB"], mg["snr_tipico_dB"]),
                       ("SNR rechazo 10 dB (dB)", e["estres"]["snr_dB"], mg["snr_estres_dB"]),
                       ("Potencia media (W)", e["potencia_media_W"], mg["potencia_W"])):
        print(f"    {et:<30} {a_:>9.1f} {b_:>11.1f}")
    rep_m = f"{mg['tormenta_bits']}" if mg["tormenta_alcanzado"] else f">{MAX_BITS} (no alcanza)"
    print(f"    {'Repeticiones en tormenta':<30} {t['nbit']:>9d} {rep_m:>11}")
    print("    Sensibilidad a B_sat: " + " · ".join(
        f"{k} T → util {x['utilizacion'] * 100:.0f} %, pérdida {x['perdida_dB']:.1f} dB, "
        f"SNR {x['snr_tipico_dB']:.1f}" for k, x in sa["barrido_bsat"].items()))
    print(f"    Geometría: Ø exterior bobina {ge['d_ext_bobina_mm']:.1f} mm vs interior útil "
          f"{ge['d_int_sonda_mm']:.0f} mm → holgura radial {ge['holgura_radial_mm']:.1f} mm "
          f"({'OK' if ge['ajuste_ok'] else 'AJUSTADA, mínimo ' + format(ge['holgura_min_mm'], '.0f') + ' mm'})")
    print(f"    Devanado: hilo Ø{ge['d_hilo_mm']:.2f} mm · {ge['vueltas_por_capa']} vueltas/capa "
          f"({'una capa alcanza' if ge['una_capa_ok'] else 'requiere varias capas'}) · cobre {ge['masa_cobre_kg']:.0f} kg")
    print(f"    μ_eff: teórico {mu['teorica']:.0f} vs diseño {mu['diseno']:.0f} → margen {mu['margen_dB']:.1f} dB")

    print(f"\n{R}\n[C] ÁRBOL DE DECISIÓN (fases 1-4; ROJA = código 111)\n")
    for x in res["arbol"]:
        ic = "🔴" if x["codigo"] == "111" else ("🟠" if x["codigo"] == "010" else "🟡")
        print(f"  {x['nombre']:<24} M{x['mw']:.1f}  {x['fase_nombre']:<9} {x['codigo']} {ic} {x['texto']}")
    print(f"\n  [C2] Gate de canal — mismo evento, distinto canal\n")
    for x in res["gate_canal"]:
        print(f"    peso={x['peso']:.2f}  {x['etiqueta']:<52} → {x['codigo']}  {x['texto']}")

    dt = res["deteccion"]
    print(f"\n{R}\n[D] DETECCIÓN Y DAÑOS EVITADOS (supuestos H05/H06, no validados)\n")
    print(f"  {'Escenario':<14} {'Tipo':<11} {'Mw':>4} {'Pd':>5} {'Aviso':>6} {'Ahorro esp.':>12}")
    for f in dt["por_escenario"]:
        yr = f["anio"] if f["anio"] else "—"
        print(f"  {f['nombre'] + ' ' + str(yr):<14} {f['tipo']:<11} {f['mw']:>4.1f} {f['pd']:>5.2f} "
              f"{f['aviso_h']:>5}h ${f['ahorro_esperado_musd']:>9.1f}M")
    m = dt["mc"]
    print(f"  Analítico: ${dt['ahorro_esperado_musd']:.1f}M · MC({m['n']:,}): ${m['ahorro_medio_musd']:.1f}M "
          f"± {m['ahorro_se_musd']:.2f} (P5–P95: {m['ahorro_p5_musd']:.0f}–{m['ahorro_p95_musd']:.0f}) · "
          f"FN medio {m['fn_medio']:.2f}/{m['n_eventos']}")

    print(f"\n{R}\n[E] COSTOS\n")
    print(f"  CAPEX ${c['capex']:,} (subtotal ${c['capex_subtotal']:,} + contingencia "
          f"{p.contingencia_pct * 100:.0f}% ${c['contingencia']:,})")
    print(f"  OPEX/año ${c['opex_anual']:,} · OPEX 30a ${c['opex_30']:,.0f}")
    print(f"  Reemplazos derivados [V]: ${c['reemplazos']:,.0f} "
          f"({c['cobertura_reemplazos']['partidas_con_reposicion']}/{c['cobertura_reemplazos']['partidas_capex']} partidas)")
    print(f"  Total 30a ${c['total_30']:,.0f}")

    pr, eq = c["caso_prudente"], c["equilibrio"]
    print(f"\n[F] VALORACIÓN MATERIAL (r={p.r_disc * 100:.0f}%, {p.years} años, sin VSL)\n")
    print(f"  Beneficio privado 30a ${c['beneficio_privado_30'] / 1e6:.1f}M + público "
          f"${c['beneficio_publico_30'] / 1e6:.1f}M (${p.gasto_publico_por_evento_usd / 1e6:.0f}M/evento × ΣPd) "
          f"× φ={p.fraccion_eventos_horizonte:.2f} = ${c['benef_total_30'] / 1e6:.1f}M")
    print(f"  B/C descontado {c['bc_desc']:.2f}:1 · VAN ${c['van'] / 1e6:.1f}M · B/C simple {c['bc_simple']:.2f}:1")
    print(f"  Contraste (reposiciones en su año): VAN ${c['van_cal'] / 1e6:.1f}M · B/C {c['bc_desc_cal']:.2f}:1")
    print(f"  Caso prudente (φ={pr['phi']:.2f}, sin gasto público): B/C {pr['bc_desc']:.2f}:1 · VAN ${pr['van'] / 1e6:.1f}M")
    print(f"  Equilibrio: el costo se cubre con {eq['factor_beneficio'] * 100:.1f} % del beneficio modelado · "
          f"φ* = {eq['phi_solo_privado'] * 100:.1f} % del catálogo (solo daños privados)")
    sr = res["sensibilidad"]["tasa_descuento"]
    print("  Tasa de descuento: " + " · ".join(f"{float(k) * 100:.0f}% → VAN ${x['van'] / 1e6:.1f}M, "
                                               f"B/C {x['bc_desc']:.2f}" for k, x in sr.items()))
    print("  OPEX: " + " · ".join(f"{k} → {x:.2f}" for k, x in res["sensibilidad"]["opex_bc_desc"].items()))
    print("  Gasto público/evento: " + " · ".join(f"{k} → {x:.2f}" for k, x in res["sensibilidad"]["gasto_publico_bc_desc"].items()))
    print(f"  {'φ (catálogo en 30 a)':<22}" + "".join(f"{k:>8}" for k in res["sensibilidad"]["phi_bc_desc"]))
    for etiqueta, nombre in (("con_gasto_publico", "con gasto público"), ("solo_privado", "solo privado")):
        print(f"  {'B/C ' + nombre:<22}" + "".join(
            f"{x[etiqueta]:>8.2f}" for x in res["sensibilidad"]["phi_bc_desc"].values()))

    rd = res["red"]
    print(f"\n[G] RED · disponibilidad de nodo {rd['disp_nodo'] * 100:.1f}% · P(≥3 nodos) "
          f"analítica {rd['p_min3_analitica'] * 100:.1f}% · MC {rd['p_min3_mc']['p_min_k'] * 100:.1f}% "
          f"± {rd['p_min3_mc']['se'] * 100:.2f}")
    lt = res["latencia"]
    print(f"[H] SERVICIO (supuestos) · latencia {lt['cable_s']:.1f} s cable / {lt['ulf_s']:.1f} s ULF · "
          f"FA {lt['fa_anual']:.2f}/año")

    print(f"\n{R}\n[I] HALLAZGOS DE AUDITORÍA\n")
    for h in res["hallazgos"]:
        print(f"  [{h['id']}] {h['severidad']:<6} {h['titulo']}")
        print(f"        {h['detalle']}")
        print(f"        → {h['accion']}")

    print(f"\n{L}\n DIAGNÓSTICO — GEO-PROBE CR v{VERSION}\n")
    filas = [
        ("Pozo", f"Ø{p.d_hole_mm:.0f} mm × {p.depth_m:.0f} m · {d['dias_nodo']:.0f} d/nodo", "✓"),
        ("Enlace típico", f"{e['snr_tipico_dB']:.1f} dB · @T {e['snr_Tpozo_dB']:.1f} · peor lito {e['snr_peor_lito_dB']:.1f}",
         _est(e["snr_tipico_dB"])),
        ("Enlace estrés 10 dB", f"{es['snr_dB']:.1f} dB", _est(es["snr_dB"]).replace("⚠", "⚠ ABIERTO")),
        ("Saturación ferrita", f"utilización {sa['utilizacion'] * 100:.0f} % de B_sat",
         "⚠ SIN MARGEN" if sa["sin_margen"] else "✓"),
        ("Geometría sonda", f"holgura radial {ge['holgura_radial_mm']:.1f} mm", "✓" if ge["ajuste_ok"] else "⚠ AJUSTADA"),
        ("P(ULF necesario)", f"{e['shear']['p_ulf_necesario'] * 100:.0f}%", "✓"),
        ("Árbol de decisión", "gate de canal activo (ROJA→pre-alerta si peso<0.5)", "✓"),
        ("CAPEX", f"${c['capex']:,}", "✓"),
        ("B/C desc. / VAN", f"{c['bc_desc']:.1f}:1 / ${c['van'] / 1e6:.0f}M (base)", "✓"),
        ("B/C prudente", f"{pr['bc_desc']:.1f}:1 (φ={pr['phi']:.1f}, sin gasto público)", "✓"),
        ("P(≥3 nodos)", f"{rd['p_min3_analitica'] * 100:.1f}%", "✓"),
        ("Supuestos [H]", f"{sum(1 for s in SUPUESTOS if s['tag'] == 'H')} registrados", "⚠ VALIDAR"),
    ]
    for a, b, c_ in filas:
        print(f"  [{a:<20}] {b:<56} {c_}")
    print(L)


# ══════════════════════════════════════════════════════════════════════════
#  9. AUTOPRUEBAS
# ══════════════════════════════════════════════════════════════════════════
def selftest() -> int:
    fallos: list[str] = []

    def check(nombre: str, cond: bool, detalle: str = "") -> None:
        print(f"  {'✓' if cond else '✗'} {nombre}{(' — ' + detalle) if detalle else ''}")
        if not cond:
            fallos.append(nombre)

    def cerca(a: float, b: float, tol: float) -> bool:
        return abs(a - b) <= tol

    print("AUTOPRUEBAS GEO-PROBE CR v" + VERSION)
    r = simular()
    e, c, v = r["enlace_principal"], r["costos"], r["verificaciones"]
    v6 = calcular_enlace(PARAMS_V6, False)

    print("\n Regresión v6.3/v6.4 (PARAMS_V6: I=20 A, Ø0.10 m, m = μ·N·I·π·r²)")
    check("SNR típico 43.0 dB", cerca(v6["snr_tipico_dB"], 43.0, 0.05), f"{v6['snr_tipico_dB']:.2f}")
    check("SNR @T 42.3 dB", cerca(v6["snr_Tpozo_dB"], 42.3, 0.05), f"{v6['snr_Tpozo_dB']:.2f}")
    check("SNR peor litología 41.1 dB", cerca(v6["snr_peor_lito_dB"], 41.1, 0.05))
    check("Estrés rechazo 10 dB = 23.0 dB", cerca(v6["estres"]["snr_dB"], 23.0, 0.05))
    check("Geotermia 55 °C/km = 41.8 dB (el PDF v6.3 dice 41.7)", cerca(v6["estres"]["snr_geo_dB"], 41.8, 0.05))
    check("Tormenta v6: nbit=13, peso 0.70, mayoría ✗",
          v6["tormenta"]["nbit"] == 13 and v6["tormenta"]["peso_canal"] == 0.70
          and not v6["tormenta"]["majority_ok"])
    check("Potencia media v6 ≈ 39 W", cerca(v6["potencia_media_W"], 39.5, 0.6), f"{v6['potencia_media_W']:.1f}")
    check("P(ULF necesario) ≈ 36 %", round(e["shear"]["p_ulf_necesario"] * 100) == 36)
    check("CAPEX = 3 587 200", c["capex"] == 3_587_200, f"{c['capex']:,}")
    check("Reemplazos = 3 090 000", round(c["reemplazos"]) == 3_090_000)
    check("OPEX anual = 398 000", c["opex_anual"] == 398_000)

    print("\n Cifras de referencia v7.3 (diseño I=6.3 A, Ø0.14 m)")
    check("SNR típico 37.2 dB", cerca(e["snr_tipico_dB"], 37.15, 0.1), f"{e['snr_tipico_dB']:.2f}")
    check("SNR estrés 10 dB = 17.2 dB", cerca(e["estres"]["snr_dB"], 17.15, 0.1))
    check("Tormenta: 49 repeticiones, 1470 s, peso 0.40",
          e["tormenta"]["nbit"] == 49 and e["tormenta"]["t_tx_s"] == 1470
          and e["tormenta"]["peso_canal"] == 0.40)
    check("μ teórico ≈ 236", cerca(e["mu_teorica"], 236.5, 0.5), f"{e['mu_teorica']:.1f}")
    check("Potencia media ≈ 5.3 W", cerca(e["potencia_media_W"], 5.3, 0.1))
    check("Utilización de B_sat ≈ 98.5 %", cerca(v["saturacion"]["utilizacion"], 0.985, 0.005),
          f"{v['saturacion']['utilizacion']:.4f}")
    check("I_sat ≈ 6.40 A", cerca(v["saturacion"]["corriente_saturacion_A"], 6.40, 0.02))
    check("B/C base descontado = 14.07", cerca(c["bc_desc"], 14.07, 0.05), f"{c['bc_desc']:.3f}")
    check("VAN base ≈ 171.8 M", cerca(c["van"] / 1e6, 171.8, 0.6))
    check("Caso prudente B/C ≈ 4.2", cerca(c["caso_prudente"]["bc_desc"], 4.2, 0.1))

    print("\n Lógica del árbol y del gate de canal")
    for x in r["arbol"] + r["gate_canal"]:
        check(x.get("nombre") or x["etiqueta"], x["fase"] == x["esperado"], x["codigo"])

    print("\n Invariantes físicos y económicos")
    check("ceil() corrige vida que no divide el horizonte",
          ciclos_reemplazo(8, 30) == 3 and int(30 / 8) - 1 == 2)
    check("ceil() coincide con vidas 7.5/10/15", [ciclos_reemplazo(x) for x in (7.5, 10, 15)] == [3, 2, 1])
    check("Calendario suma = fondo", cerca(sum(m for *_, m in calendario_reemplazos(VIDA_UTIL, 30)),
                                           c["reemplazos"], 1e-6))
    check("P(cizalla) monótona", all(p_shear(a) < p_shear(b) for a, b in ((6, 7), (7, 8))))
    check("Pd ≤ 0.95", all(prob_deteccion(m, k) <= 0.95 for m in (5, 6, 7, 8) for k in FACTOR_PRECURSOR))
    check("Pérdida por saturación nunca negativa",
          v["saturacion"]["perdida_dB"] >= 0
          and all(x["perdida_dB"] >= 0 for x in v["saturacion"]["barrido_bsat"].values()))
    pv = verificaciones(replace(PARAMS_V6, area_efectiva=True))["saturacion"]
    check("Con I=20 A (diseño v6) el núcleo satura: pérdida ≈ 9.8 dB",
          pv["excede"] and cerca(pv["perdida_dB"], 9.8, 0.3), f"{pv['perdida_dB']:.2f} dB")
    check("Momento operativo ≤ momento lineal y ≤ saturado",
          momento_operativo(200, P0, True) <= min(momento_lineal(200, P0), momento_saturado(P0)) + 1e-9)
    check("Con margen: utilización ≤ objetivo",
          utilizacion_bsat(P0.mu_eff_design, replace(P0, i_a=v["con_margen"]["i_a"]))
          <= P0.util_bsat_objetivo + 1e-9)
    check("Beneficio escala linealmente con φ",
          cerca(beneficio_catalogo(P0, phi=0.5)["total"], 0.5 * beneficio_catalogo(P0, phi=1.0)["total"], 1e-3))
    ben1 = beneficio_catalogo(P0, phi=1.0, gasto=0.0)["total"]
    cal = calendario_reemplazos(VIDA_UTIL, 30)
    base = valorar(P0, c["capex"], c["opex_anual"], cal, beneficio_30=ben1)
    eq = valorar(P0, c["capex"], c["opex_anual"], cal,
                 beneficio_30=ben1 * c["equilibrio"]["phi_solo_privado"])
    check("φ de equilibrio → B/C = 1", cerca(eq["bc_desc"], 1.0, 1e-9), f"{eq['bc_desc']:.6f}")
    check("Beneficio privado = ahorro analítico del catálogo",
          cerca(c["beneficio_privado_30"] / 1e6, r["deteccion"]["ahorro_esperado_musd"], 1e-6))
    mc, an = r["deteccion"]["mc"], r["deteccion"]["ahorro_esperado_musd"]
    check("MC de ahorro ≈ analítico (4 SE)", abs(mc["ahorro_medio_musd"] - an) <= 4 * mc["ahorro_se_musd"])
    rm = r["red"]["p_min3_mc"]
    check("MC de red ≈ analítico (4 SE)", abs(rm["p_min_k"] - r["red"]["p_min3_analitica"]) <= 4 * rm["se"])
    check("Determinismo (misma semilla → mismo JSON)",
          json.dumps(simular(), default=_json_default, sort_keys=True)
          == json.dumps(r, default=_json_default, sort_keys=True))
    check("KPI principal por defecto = saturado", r["modo_principal"] == "con_saturacion")
    check("Hallazgos: ninguno recomienda I mayor que I_sat",
          all("I≈7" not in (h["accion"] + h["detalle"]) for h in r["hallazgos"]))

    print("\n Validación y CLI")
    for nombre, kw in (("depth_m<0", dict(depth_m=-1)), ("φ>1", dict(fraccion_eventos_horizonte=1.5)),
                       ("sonda≥pozo", dict(d_sonde_mm=250)), ("bobina<núcleo", dict(r_bobina_m=0.01))):
        try:
            Params(**kw)
            check(f"Rechaza {nombre}", False)
        except ValueError:
            check(f"Rechaza {nombre}", True)
    with tempfile.TemporaryDirectory() as td:
        ruta = Path(td) / "t.json"
        rc = main(["--quiet", "--out", str(ruta), "--set", "i_a=5.1"])
        d = json.loads(ruta.read_text(encoding="utf-8"))
        check("CLI --set i_a=5.1 aplica y termina en 0", rc == 0 and cerca(d["parametros"]["i_a"], 5.1, 1e-9))
        check("CLI deja el JSON sin NaN/inf", _sin_no_finitos(d))
        main(["--quiet", "--out", str(ruta), "--lineal"])
        check("CLI --lineal cambia el KPI principal",
              json.loads(ruta.read_text(encoding="utf-8"))["modo_principal"] == "lineal")

    print(f"\n{'TODAS LAS PRUEBAS PASAN' if not fallos else 'FALLARON: ' + ', '.join(fallos)}")
    return 0 if not fallos else 1


def _sin_no_finitos(x) -> bool:
    if isinstance(x, float):
        return math.isfinite(x)
    if isinstance(x, dict):
        return all(_sin_no_finitos(v) for v in x.values())
    if isinstance(x, list):
        return all(_sin_no_finitos(v) for v in x)
    return True


# ══════════════════════════════════════════════════════════════════════════
#  10. CLI
# ══════════════════════════════════════════════════════════════════════════
def _aplicar_sets(p: Params, sets: list[str]) -> Params:
    tipos = {f.name: f.type for f in fields(Params)}
    cambios = {}
    for s in sets:
        if "=" not in s:
            raise SystemExit(f"--set espera clave=valor, recibió '{s}'")
        k, v = s.split("=", 1)
        if k not in tipos:
            raise SystemExit(f"Parámetro desconocido '{k}'. Válidos: {', '.join(tipos)}")
        t = str(tipos[k])
        cambios[k] = (v.lower() in ("1", "true", "si", "sí")) if "bool" in t else \
            int(v) if t == "int" else float(v)
    return replace(p, **cambios)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=f"GEO-PROBE CR v{VERSION}")
    ap.add_argument("--out", default="GEO_PROBE_CR_v7_3_resultados.json", help="ruta del JSON")
    ap.add_argument("--seed", type=int, default=SEED)
    ap.add_argument("--lineal", action="store_true",
                    help="KPI principal sin tope de saturación (default: con tope)")
    ap.add_argument("--set", action="append", default=[], metavar="CLAVE=VALOR",
                    help="sobrescribe un parámetro (repetible)")
    ap.add_argument("--selftest", action="store_true", help="ejecutar pruebas y salir")
    ap.add_argument("--quiet", action="store_true", help="no imprimir el informe")
    a = ap.parse_args(argv)

    if a.selftest:
        return selftest()
    p = _aplicar_sets(P0, a.set)
    res = simular(p, seed=a.seed, saturacion=not a.lineal)
    if not a.quiet:
        imprimir(res, p)
    ruta = guardar_json(res, Path(a.out))
    if not a.quiet:
        print(f"\n  JSON → {ruta}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
