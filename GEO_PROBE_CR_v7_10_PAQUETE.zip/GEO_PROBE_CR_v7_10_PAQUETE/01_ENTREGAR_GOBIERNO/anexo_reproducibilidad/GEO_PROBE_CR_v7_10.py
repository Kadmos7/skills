#!/usr/bin/env python3
"""
GEO-PROBE CR — v7.10 CANÓNICA (auditada y probada)
Red Nacional de Precursores Sísmicos · Costa Rica
Inventor: Jason Manuel Sarmiento Salazar · OTPR CR / PCT WIPO
Divulgación técnica: 12 de septiembre de 2026

Línea v3 → v7.10 consolidada: borehole 600 m, sin reactor, cable primario +
ULF de respaldo, decisión bayesiana multi-fase, beneficio material sin VSL.

USO
    python GEO_PROBE_CR_v7_10.py                      # informe + JSON
    python GEO_PROBE_CR_v7_10.py --out resultados.json
    python GEO_PROBE_CR_v7_10.py --lineal             # KPI principal sin tope de saturación
    python GEO_PROBE_CR_v7_10.py --set i_a=5.4 --set mu_limitado_por_geometria=no
    python GEO_PROBE_CR_v7_10.py --selftest           # pruebas
    python GEO_PROBE_CR_v7_10.py --quiet --n-mc 20000 --dias 3650   # solo JSON
    Códigos de salida: 0 correcto · 1 error de escritura · 2 parámetros inválidos.

TRAZABILIDAD   [V] fórmula estándar / derivado · [H] hipótesis sin fuente.
               El registro completo está en SUPUESTOS y se exporta al JSON.

REVISIÓN 7.10 (pendientes que se pueden calcular)
   1. Réplicas con el cable cortado: tras un sismo Mw 7.6 se simulan 24 h de réplicas
      (Omori-Utsu con p = 1, c = 0.05 d; Gutenberg-Richter con la Mc del catálogo de
      OVSICORI; máxima = Mw − 1.2 de Båth) en un disco de 80 km alrededor del nodo, se
      pasan por la misma cascada y el canal ULF atiende los mensajes naranja o más en una
      cola FIFO por condición geomagnética (200 secuencias).
   2. Sensibilidades del estrés: rechazo de ruido mínimo para 20 dB y para 1 dB de margen
      (el SNR es lineal en el rechazo) y SNR de la peor litología frente al coeficiente
      térmico de la conductividad (0 a 5 % por °C).
   3. Hallazgos F13 y F14; supuestos H26 y H27; --n-rep.

REVISIÓN 7.9 (sobre la v7.8 recibida)
   1. La corrección térmica de la conductividad (σ crece 2 %/°C) se aplicaba solo a la
      tabla de litologías, a la temperatura del fondo para todo el trayecto: la fila
      «Basalto húmedo CR» (40.07 dB) no coincidía con el SNR típico de la misma roca
      (40.10 dB) y el SNR a temperatura de pozo no usaba σ(T). Ahora σ(T) se integra a lo
      largo del pozo con T(z) = T_sup + gradiente·z (forma cerrada, sigma_trayecto) y se
      usa en todos los cálculos del enlace, con el gradiente de cada escenario.
      sigma_termico=no reproduce la v7.7 y anteriores.
   2. Pruebas: la v7.8 reemplazó cifras fijas por cotas («peor litología ≤ 41.2 dB»,
      «T/geo/peor lito coherentes»). Se restauran cifras fijas y se agregan pruebas de
      la integral contra integración numérica y de coherencia entre filas.
   3. Atenuación por litología (atenuacion_dB) en el JSON: la afirmación «menos de 2.1 dB»
      del informe ya no era cierta (arcilla ácida con σ(T): más de 2.1 dB).
   4. Rótulos corregidos: USO, SCHEMA y «Línea v3 →» de la v7.8 seguían en 7.7;
      el registro de supuestos no incluía el coeficiente térmico (H25).

REVISIÓN 7.7 (márgenes de tiempo con sismicidad de fondo diaria)
   1. Presupuesto de tiempo del enlace ULF por condición geomagnética: primer bit
      (basta para reconocer 111, pues 001 y 010 empiezan en 0), mensaje completo de
      3 bits y latencia de extremo a extremo, frente a T_max y a las horas de aviso.
   2. Simulación de sismicidad de fondo anclada en el catálogo de OVSICORI (38 sismos
      por día): Poisson + Gutenberg-Richter, detectabilidad por distancia a cada nodo,
      cascada de decisión vectorizada (probada contra evaluar_evento), solapamiento de
      ventanas de 30 s, cola del canal ULF y tasa de ROJA de fondo con su criterio.
   3. Hallazgos F10 a F12: la latencia ULF de 7.3 s es incompatible con 30 s por bit;
      el mensaje completo no cabe en T_max durante tormenta; la tasa de falsas alarmas
      depende de la cola de la razón de verosimilitud del fondo.

REVISIÓN 7.6 (sobre la v7.5 recibida)
   1. μ_eff acotado por la geometría. La v7.5 cerraba el estrés de 10 dB (20.7 dB)
      con μ_eff = 200 en un núcleo de Ø185 mm × 4 m cuyo máximo físico (factor
      desmagnetizante) es 156. Con μ_eff = 156 y la misma corriente de 5.4 A el
      estrés da 18.5 dB: el cierre no existía. mu_efectivo() usa el menor entre el
      valor de diseño y el teórico. mu_limitado_por_geometria=no reproduce la v7.5.
   2. Diseño coherente con sus propios criterios: I = 6.5 A (utilización de B_sat
      ≤ 80 %), sonda Ø220 mm (holgura bobina–pared ≥ 5 mm) y pozo Ø240 mm (holgura
      sonda–pozo ≥ 10 mm). La v7.5 bajó el criterio a 2.5 mm en los documentos pero
      no en el código, y dejaba 7.5 mm entre sonda y pozo sin verificarlo.
   3. Nuevas verificaciones: holgura sonda–pozo y pozo mínimo; margen del SNR de
      estrés (F2 ya no dice «cerrado» con 0.2 dB); F9 (CAPEX y plazos no
      recalculados para la geometría); sensibilidad al CAPEX.
   4. Texto de F2 corregido: decía «660 s por encima de T_max = 900 s».
   5. Pruebas: se restauran cifras de referencia fijas (la v7.5 las había
      reemplazado por cotas como «SNR ≥ 40 dB» y «B/C > 10»); regresión de la
      v7.5 con PARAMS_V75; prueba de mutación ampliada.

HISTORIAL
   7.9  σ(T) integrada a lo largo del pozo; pruebas con cifras fijas (v7.8 recibida).
   7.8  (recibida) σ(T) solo en la tabla de litologías; pruebas como cotas.
   7.7  márgenes de tiempo y sismicidad de fondo; F10 a F12.
   7.6  μ_eff acotada; diseño con I = 6.5 A, sonda Ø220 mm, pozo Ø240 mm.
   7.5  (recibida) núcleo Ø185 mm, I = 5.4 A, pozo Ø230 mm; estrés 10 dB «cerrado».
   7.4  (recibida) núcleo Ø170 mm, I = 5.5 A.
   7.3.1 validación de entradas, CLI robusto, pruebas de mutación 42/42.
   7.3  auditoría de la v7.2: modo saturado por defecto, pérdidas ≥ 0, hallazgos
        calculados, φ del catálogo, geometría, margen de saturación, --set.
   7.2  I = 6.3 A, núcleo Ø140 mm; beneficio sin VSL.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import math
import os
import random
import sys
import tempfile
import warnings
from dataclasses import asdict, dataclass, fields, replace
from enum import IntEnum
from math import ceil, comb
from pathlib import Path
from typing import Any

import numpy as np

warnings.filterwarnings("ignore")

VERSION = "7.10 CANÓNICA"
SCHEMA = "7.10"
SEED = 2026
ANCHO = 74
MU0 = 4.0e-7 * math.pi
ALPHA_SIGMA = 0.02          # [H] dσ/σ por °C: conducción iónica de los fluidos de poro
INVENTOR = "Jason Manuel Sarmiento Salazar"
FECHA_DIVULGACION = "2026-09-12"
MARGEN_SNR_MIN_DB = 1.0     # [H] margen mínimo sobre el umbral de SNR para llamar «cerrado» a un enlace


# ══════════════════════════════════════════════════════════════════════════
#  1. PARÁMETROS
# ══════════════════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class Params:
    # — Sitio y perforación —
    depth_m: float = 600.0
    n_nodos: int = 5
    d_hole_mm: float = 240.0
    d_sonde_mm: float = 220.0
    l_sonde_m: float = 6.0
    rop_m_dia: float = 45.0
    dias_compl: float = 6.0
    n_equipos: int = 2
    espesor_pared_sonde_mm: float = 6.0   # [H] carcasa Ti/PTFE
    holgura_min_mm: float = 5.0            # [H17] holgura radial mínima bobina–pared de la sonda
    holgura_pozo_min_mm: float = 10.0      # [H19] holgura radial mínima sonda–pozo

    # — Enlace ULF (diseño v7.2) —
    f_ulf: float = 2.0
    t_bit: float = 30.0
    mu_r: float = 2000.0
    l_core: float = 4.0
    d_core: float = 0.185
    mu_eff_design: float = 200.0
    rho_fer: float = 4800.0
    rho_cu: float = 1.68e-8
    n_turns: int = 1000
    i_a: float = 6.5
    a_cond_mm2: float = 10.0
    r_bobina_m: float = 0.0965            # radio efectivo del devanado (= radio del núcleo + 4 mm)
    duty: float = 0.17
    rej_db: float = 30.0
    b_sat_ferrita_t: float = 0.40         # [H] MnZn a temperatura de pozo; verificar
    util_bsat_objetivo: float = 0.80      # [H] utilización máxima recomendada de B_sat
    area_efectiva: bool = True            # False reproduce el modelo v6.x (m = μ·N·I·π·r²)
    mu_limitado_por_geometria: bool = True  # False reproduce la v7.5 (μ_eff sin tope físico)
    sigma_termico: bool = True            # False reproduce la v7.7 (σ fija a 25 °C)
    alpha_sigma: float = ALPHA_SIGMA      # [H] coeficiente térmico de la conductividad

    # — Térmico —
    t_surf: float = 25.0
    grad_termico: float = 30.0
    derate_pct_per_c: float = 0.004
    mu_min: float = 80.0

    # — Economía —
    contingencia_pct: float = 0.18
    r_disc: float = 0.06
    inflacion: float = 0.035
    years: int = 30
    gasto_publico_por_evento_usd: float = 25_000_000.0   # [H]
    fraccion_eventos_horizonte: float = 1.0              # [H] φ: parte del catálogo que ocurre en 30 a

    def __post_init__(self) -> None:
        for f in fields(self):
            v = getattr(self, f.name)
            if isinstance(v, bool):
                continue
            if isinstance(v, (int, float)) and not math.isfinite(v):
                raise ValueError(f"Parámetro '{f.name}' debe ser finito, recibió {v}")
        positivos = ("depth_m", "rop_m_dia", "f_ulf", "t_bit", "l_core", "d_core", "i_a",
                     "a_cond_mm2", "r_bobina_m", "years", "n_nodos", "n_equipos",
                     "b_sat_ferrita_t", "n_turns", "mu_r", "d_hole_mm", "d_sonde_mm",
                     "l_sonde_m", "rho_fer", "rho_cu", "holgura_min_mm", "holgura_pozo_min_mm")
        for nombre in positivos:
            if getattr(self, nombre) <= 0:
                raise ValueError(f"Parámetro '{nombre}' debe ser > 0")
        no_negativos = ("dias_compl", "espesor_pared_sonde_mm", "grad_termico",
                        "derate_pct_per_c", "mu_min", "gasto_publico_por_evento_usd", "alpha_sigma")
        for nombre in no_negativos:
            if getattr(self, nombre) < 0:
                raise ValueError(f"Parámetro '{nombre}' debe ser ≥ 0")
        for nombre in ("duty", "util_bsat_objetivo", "fraccion_eventos_horizonte"):
            if not 0 < getattr(self, nombre) <= 1:
                raise ValueError(f"{nombre} debe estar en (0, 1]")
        if self.alpha_sigma > 0.1:
            raise ValueError("alpha_sigma debe estar en [0, 0.1] por °C")
        if not 1.0 < self.mu_eff_design <= self.mu_r:
            raise ValueError("mu_eff_design debe estar en (1, mu_r]")
        if not 0.0 <= self.contingencia_pct <= 1.0:
            raise ValueError("contingencia_pct debe estar en [0, 1]")
        if not 0.0 <= self.r_disc < 1.0:
            raise ValueError("r_disc debe estar en [0, 1)")
        if not -0.5 < self.inflacion < 1.0:
            raise ValueError("inflacion debe estar en (-0.5, 1)")
        if not 0.0 <= self.rej_db <= 120.0:
            raise ValueError("rej_db debe estar en [0, 120] dB")
        if self.l_core < 5 * self.d_core:
            raise ValueError("l_core/d_core debe ser ≥ 5 (fórmula de desmagnetización de varilla)")
        if self.r_bobina_m < self.d_core / 2:
            raise ValueError("La bobina no puede ser menor que el núcleo")
        if self.d_sonde_mm >= self.d_hole_mm:
            raise ValueError("La sonda debe caber en el pozo")
        if 2 * self.espesor_pared_sonde_mm >= self.d_sonde_mm:
            raise ValueError("El espesor de pared no puede consumir la sonda")


P0 = Params()
PARAMS_V6 = replace(P0, i_a=20.0, d_core=0.10, r_bobina_m=0.055, area_efectiva=False, sigma_termico=False,
                   d_hole_mm=200.0, d_sonde_mm=168.0)
PARAMS_V73 = replace(P0, i_a=6.3, d_core=0.14, r_bobina_m=0.075, d_hole_mm=200.0, d_sonde_mm=168.0,
                     sigma_termico=False)
PARAMS_V75 = replace(P0, i_a=5.4, d_core=0.185, r_bobina_m=0.0965, d_hole_mm=230.0,
                     d_sonde_mm=215.0, mu_limitado_por_geometria=False, sigma_termico=False)
ALTERNATIVA_N200: dict[str, Any] = {"d_core": 0.20, "r_bobina_m": 0.104, "i_a": 7.4, "d_sonde_mm": 236.0, "d_hole_mm": 256.0}
GEOM_BASE_CAPEX = {"d_hole_mm": 200.0, "d_core": 0.10}   # [H] geometría de la que provienen CAPEX y ROP (v6.x)

SIGMA_REF = 1.2e-4                     # [H] basalto húmedo CR, S/m
PC1_RUIDO = {
    "Tranquilo (noche, Kp≤2)": 20.0,
    "Típico diurno": 60.0,
    "Activo (Kp 4–5)": 300.0,
    "Tormenta CME (Kp≥7)": 3000.0,
}
KP_BANDAS = ((0, 2, "Tranquilo", 20.0), (3, 4, "Moderado", 60.0),
             (5, 6, "Activo", 300.0), (7, 9, "Tormenta", 3000.0))
LITOLOGIAS = (("Basalto seco", 5e-5), ("Basalto húmedo CR", 1.2e-4),
              ("Andesita", 3e-4), ("Sedimento", 1e-3),
              ("Falla fluidos", 5e-3), ("Arcilla ácida", 2e-2))
SNR_OBJETIVO_DB = 20.0
MAX_BITS = 64
T_MAX_ULF_S = 15 * 60
REJ_ESTRES_DB = 10.0
REJ_ESTRES_MITIGADO_DB = 15.0  # [H] con filtrado y generadores apartados
GRAD_ESTRES = 55.0

PESO_CABLE = 1.00                      # [H] política de confianza por canal
PESO_ULF_OK = 0.70
PESO_ULF_DEGRADADO = 0.40
PESO_ULF_RECHAZO_DEGRADADO = 0.35

SHEAR_K, SHEAR_M0 = 1.937, 7.581       # [H] calibración no documentada
MW_EVENTOS_MAYORES = (6.5, 7.0, 7.5, 7.8)

EFICACIA_REDUCCION = 0.7               # [H]
FACTOR_PRECURSOR = {"documentado": 1.15, "posible": 1.02, "ninguno": 0.82}

# [H] Latencia y FA son supuestos de diseño, NO resultados calculados.
T_CABLE_S, T_ULF_S, FA_ANUAL = 5.70, 7.30, 0.05

# ---- Márgenes de tiempo y sismicidad de fondo (v7.7)
N_BITS_MENSAJE = 3                     # protocolo 001 / 010 / 111 (bit más significativo primero)
LAT_CB_S = 2.0                         # [H] difusión Cell Broadcast
N_SENSORES = 8
VENTANA_S = 30.0                       # ventana de integración de un bit
# [F] OVSICORI 2024: 13 495 sismos localizados (38 por día), 36 de Mw ≥ 5.0 (Diario Extra, 2024);
#     2025: 14 481 (repositorio UNA). El catálogo está dominado por Mw < 3.5.
SISMICIDAD_FONDO = {"n_anio": 13_495, "n_m5_anio": 36, "n_anio_2025": 14_481, "b": 1.0, "m_max": 6.5}
KP_TIEMPO = {"Tranquilo": 0.40, "Moderado": 0.45, "Activo": 0.145, "Tormenta": 0.005}   # [H] fracción del tiempo
REGION_LAT, REGION_LON = (8.0, 11.2), (-86.0, -82.5)    # [H] caja que incluye el Pacífico y el Caribe
NODOS_ILUSTRATIVOS = (("Osa", 8.55, -83.5), ("Gran Área Metropolitana", 9.93, -84.08),
                      ("Tilarán y Arenal", 10.46, -84.7), ("Cinturón Central", 10.2, -84.2),
                      ("Limón", 10.0, -83.03))
M_DET_A, M_DET_B = 1.0, 1.7            # [H] Mw mínima detectable a r km: A + B·log10(r)
SENSORES_POR_UNIDAD = 2.5              # [H] sensores adicionales por unidad de Mw sobre el umbral
PRIOR_96H = 2 / (35 * 365.25) * 4      # [H] 2 eventos Mw ≥ 7.5 (1991, 2012) en 35 años, ventana de 96 h
SIGMA_LR = 0.5                         # [H] dispersión (log10) de la razón de verosimilitud del fondo
SIGMAS_BARRIDO = (0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0)
DIAS_SIM = 36_500                      # 100 años de sismicidad de fondo
# [H] Réplicas de un sismo grande (Omori-Utsu con p = 1; Gutenberg-Richter con la Mc del catálogo)
REPLICAS = {"m_main": 7.6, "bath": 1.2, "c_dias": 0.05, "t_catalogo_dias": 365.0, "radio_km": 80.0, "horas": 24.0}
N_REP_DEFECTO = 200
RECHAZOS_BARRIDO = (5.0, 8.0, 10.0, 12.0, 15.0, 20.0, 25.0, 30.0)
ALPHAS_BARRIDO = (0.0, 0.01, 0.02, 0.03, 0.05)
DIAS_PRUEBA = 120

MODOS_FALLA = (("Modo 1", 0.30, 0.95), ("Modo 2", 0.45, 0.85),
               ("Modo 3", 0.35, 0.92), ("Modo 4", 0.12, 0.98),
               ("Modo 5", 0.20, 0.99))   # [H] rótulos pendientes
P_REGIMEN_CORRELACIONADO = 0.08        # [H]
P_UP_CORRELACIONADO = 0.55             # [H]

CAPEX_BASE = {                         # USD
    "Perforación 5×600m": 550_000,
    "Entubado/cementado": 180_000,
    "DAS (5)": 750_000,
    "SQUID superficie (5)": 350_000,
    "Rb-87 pozo (10)": 200_000,
    "Cable armado (5) PRIMARIO": 60_000,
    "Bobina ULF (5) RESPALDO": 85_000,
    "Radón (5)": 60_000,
    "Presión poros (10)": 60_000,
    "Sondes Ti/PTFE (5)": 140_000,
    "Telecom ICE+LEO": 75_000,
    "Cómputo OVSICORI": 150_000,
    "Gateway CB CNE": 180_000,
    "Ingeniería/comisionado": 200_000,
}
# [H] Los montos vienen del código v6.x sin rótulo; los nombres se asignaron
# en v7.1 y son PROVISIONALES: confirmar contra el presupuesto real.
OPEX_ANUAL = {
    "Personal técnico OVSICORI/RSN [prov.]": 125_000,
    "Helio / criogenia SQUID [prov.]": 18_000,
    "Energía y respaldo sitios [prov.]": 18_000,
    "Mantenimiento pozos y sensores [prov.]": 182_000,
    "Telecom / enlaces [prov.]": 10_000,
    "Seguros y permisos [prov.]": 25_000,
    "Capacitación y ejercicios CNE [prov.]": 20_000,
}
VIDA_UTIL = {"DAS (5)": 10.0, "SQUID superficie (5)": 10.0,       # [H] años
             "Rb-87 pozo (10)": 7.5, "Sondes Ti/PTFE (5)": 15.0,
             "Telecom ICE+LEO": 10.0}
VIDA_UTIL_TI_AMPLIADO = {"Cómputo OVSICORI": 7.0, "Gateway CB CNE": 7.0}   # [H] contraste

PHI_PRUDENTE = 0.40                    # [H] caso prudente ilustrativo: 2 de 5 eventos
GASTO_PUBLICO_PRUDENTE = 0.0


@dataclass(frozen=True)
class Escenario:
    nombre: str
    anio: int | None
    mw: float
    precursor: str
    dano_usd: float
    tipo: str          # "histórico" | "proyección" | "escenario"

    def __post_init__(self) -> None:
        if self.precursor not in FACTOR_PRECURSOR:
            raise ValueError(f"precursor '{self.precursor}' inválido; use {sorted(FACTOR_PRECURSOR)}")
        if self.tipo not in ("histórico", "proyección", "escenario"):
            raise ValueError(f"tipo '{self.tipo}' inválido")
        if not (math.isfinite(self.mw) and 0 < self.mw < 10):
            raise ValueError("mw debe estar en (0, 10)")
        if not (math.isfinite(self.dano_usd) and self.dano_usd >= 0):
            raise ValueError("dano_usd debe ser ≥ 0 y finito")


ESCENARIOS = (
    Escenario("Limón", 1991, 7.6, "posible", 92e6, "histórico"),
    Escenario("Cinchona", 2009, 6.2, "ninguno", 100e6, "histórico"),
    Escenario("Nicoya", 2012, 7.6, "documentado", 45e6, "histórico"),
    Escenario("GAM", None, 6.5, "posible", 150e6, "escenario"),
    Escenario("Osa", 2035, 7.8, "documentado", 300e6, "proyección"),
)


# ══════════════════════════════════════════════════════════════════════════
#  2. FÍSICA DEL ENLACE ULF
# ══════════════════════════════════════════════════════════════════════════
def skin_depth_m(sigma: float, f_hz: float) -> float:
    """[V] Profundidad pelicular δ = √(2/(ωμ0σ))."""
    return math.sqrt(2.0 / (2.0 * math.pi * f_hz * MU0 * sigma))


def sigma_at_T(sigma_25: float, t_c: float, alpha: float = ALPHA_SIGMA) -> float:
    """[H] Conductividad local con dependencia térmica lineal (electrolito en los poros)."""
    return max(1e-6, sigma_25 * (1.0 + alpha * (t_c - 25.0)))


def sigma_trayecto(sigma_25: float, grad_c_km: float, p: Params, d: float | None = None) -> float:
    """[V] Conductividad efectiva a lo largo del trayecto de d metros, con T(z) = T_sup + grad·z.
    Es la que reproduce la atenuación integrada: ∫ dz/δ(z) = d/δ_ef (forma cerrada)."""
    d = p.depth_m if d is None else d
    if not p.sigma_termico:
        return sigma_25
    a = sigma_at_T(sigma_25, p.t_surf, p.alpha_sigma)
    b = sigma_25 * p.alpha_sigma * grad_c_km / 1000.0
    if b == 0:
        return a
    media_raiz = 2.0 / (3.0 * b * d) * ((a + b * d) ** 1.5 - a ** 1.5)
    return media_raiz ** 2


def mu_eff_teorica(l_m: float, d_m: float, mu_r: float) -> tuple[float, float]:
    """[V] Permeabilidad efectiva de varilla (factor desmagnetizante de elipsoide)."""
    ld = l_m / d_m
    nd = (math.log(2 * ld) - 1) / ld ** 2
    return mu_r / (1 + nd * (mu_r - 1)), nd


def mu_efectivo(p: Params) -> float:
    """[V] μ_eff utilizable: el de diseño acotado por el máximo físico de la geometría
    del núcleo (factor desmagnetizante). Un núcleo más grueso baja el máximo."""
    if not p.mu_limitado_por_geometria:
        return p.mu_eff_design
    mu_th, _ = mu_eff_teorica(p.l_core, p.d_core, p.mu_r)
    return min(p.mu_eff_design, mu_th)


def areas_m2(p: Params) -> tuple[float, float]:
    return math.pi * (p.d_core / 2) ** 2, math.pi * p.r_bobina_m ** 2


def magnetizacion_sat(p: Params) -> float:
    """[V] Ms = B_sat/μ0 (A/m)."""
    return p.b_sat_ferrita_t / MU0


def momento_lineal(mu_eff: float, p: Params) -> float:
    """[V] Momento dipolar lineal (A·m²).
    area_efectiva=True : m = N·I·[A_bobina + (μ_eff−1)·A_núcleo]
    area_efectiva=False: m = μ_eff·N·I·π·r²   (modelo v6.x, solo regresión)"""
    a_core, a_coil = areas_m2(p)
    if p.area_efectiva:
        return p.n_turns * p.i_a * (a_coil + (mu_eff - 1) * a_core)
    return mu_eff * p.n_turns * p.i_a * a_coil


def momento_saturado(p: Params) -> float:
    """[V] Tope físico: devanado en aire + núcleo magnetizado a B_sat."""
    a_core, a_coil = areas_m2(p)
    return p.n_turns * p.i_a * a_coil + magnetizacion_sat(p) * a_core * p.l_core


def momento_operativo(mu_eff: float, p: Params, sat: bool) -> float:
    m = momento_lineal(mu_eff, p)
    return min(m, momento_saturado(p)) if sat else m


def utilizacion_bsat(mu_eff: float, p: Params) -> float:
    """[V] M_lineal / Ms en el núcleo; > 1 significa que satura."""
    h0 = p.n_turns * p.i_a / p.l_core
    return (mu_eff - 1) * h0 / magnetizacion_sat(p)


def corriente_saturacion_a(mu_eff: float, p: Params) -> float:
    """[V] Corriente a la que M_lineal alcanza Ms."""
    if mu_eff <= 1:
        raise ValueError("mu_eff debe ser > 1")
    return magnetizacion_sat(p) * p.l_core / ((mu_eff - 1) * p.n_turns)


def campo_pT(m: float, p: Params, d: float | None = None,
             sigma: float = SIGMA_REF) -> float:
    """[V] Campo axial de dipolo con atenuación pelicular, en pT."""
    d = p.depth_m if d is None else d
    return (MU0 * m / (2 * math.pi * d ** 3)
            * math.exp(-d / skin_depth_m(sigma, p.f_ulf)) * 1e12)


def snr_db(m: float, pc1_pT: float, p: Params, rej_db: float | None = None,
           d: float | None = None, sigma: float = SIGMA_REF,
           grad: float | None = None) -> tuple[float, float]:
    """(SNR crudo, SNR procesado) en dB. [H] rechazo Pc1 y ganancia f·T.
    sigma es la conductividad a 25 °C; grad (°C/km) fija la temperatura a lo largo del trayecto."""
    rej = p.rej_db if rej_db is None else rej_db
    g = p.grad_termico if grad is None else grad
    b = campo_pT(m, p, d, sigma_trayecto(sigma, g, p, d))
    eff = pc1_pT / 10 ** (rej / 20)
    raw = 20 * math.log10(b / eff)
    return raw, raw + 10 * math.log10(p.f_ulf * p.t_bit)


def bits_requeridos(snr_proc: float, objetivo: float = SNR_OBJETIVO_DB,
                    max_bits: int = MAX_BITS) -> tuple[int, bool]:
    """Repeticiones de bit para alcanzar el SNR objetivo (forma cerrada).
    Devuelve (repeticiones, alcanzado). NaN o SNR muy bajo → (max_bits, False)."""
    if math.isnan(snr_proc):
        return max_bits, False
    if snr_proc >= objetivo:
        return 1, True
    exceso = (objetivo - snr_proc) / 10
    if exceso > math.log10(max_bits):          # evita OverflowError con SNR extremo
        return max_bits, False
    n = ceil(10 ** exceso)
    return (n, True) if n <= max_bits else (max_bits, False)


def peso_canal_ulf(t_tx_s: float) -> float:
    """Peso del canal ULF: a tiempo (T_tx ≤ T_max) o degradado."""
    return PESO_ULF_OK if t_tx_s <= T_MAX_ULF_S else PESO_ULF_DEGRADADO


def temperatura_fondo(grad_c_km: float, p: Params) -> float:
    return p.t_surf + grad_c_km * p.depth_m / 1000.0


def mu_termico(t_c: float, p: Params) -> float:
    """[H] Deriva lineal de μ con la temperatura."""
    return max(p.mu_min, mu_efectivo(p) * (1 - p.derate_pct_per_c * max(0.0, t_c - 25.0)))


def potencia_media_w(p: Params) -> float:
    lw = p.n_turns * 2 * math.pi * p.r_bobina_m
    rc = p.rho_cu * lw / (p.a_cond_mm2 * 1e-6)
    return p.i_a ** 2 * rc * p.duty


def p_shear(mw: float) -> float:
    """[H] Probabilidad de cizalla del cable de pozo por magnitud."""
    return 1.0 / (1.0 + math.exp(-SHEAR_K * (mw - SHEAR_M0)))


# ══════════════════════════════════════════════════════════════════════════
#  3. ÁRBOL DE DECISIÓN (sin estado)
# ══════════════════════════════════════════════════════════════════════════
class Fase(IntEnum):
    ARCHIVADO = 0
    AMARILLA = 1
    NARANJA = 2
    PREALERTA = 3
    ROJA = 4


CODIGO_3BIT = {Fase.ARCHIVADO: "001", Fase.AMARILLA: "001", Fase.NARANJA: "010",
               Fase.PREALERTA: "010", Fase.ROJA: "111"}


@dataclass(frozen=True)
class Evento:
    energia: float
    umbral: float
    sensores: int
    nodos_adj: int
    p_bayes: float

    def __post_init__(self) -> None:
        if not (math.isfinite(self.energia) and math.isfinite(self.umbral)):
            raise ValueError("energia y umbral deben ser finitos")
        if self.sensores < 0 or self.nodos_adj < 0:
            raise ValueError("sensores y nodos_adj deben ser ≥ 0")


@dataclass(frozen=True)
class ConfigArbol:
    p_fase3: float = 0.85
    lat_bayes_s: float = 1.8
    peso_minimo_roja: float = 0.50
    p_override: float = 0.95
    nodos_override: int = 3


CFG_ARBOL = ConfigArbol()


@dataclass(frozen=True)
class Decision:
    fase: Fase
    codigo: str
    texto: str
    degradada: bool = False


def evaluar_evento(e: Evento, peso_canal: float = PESO_CABLE,
                   cfg: ConfigArbol = CFG_ARBOL) -> Decision:
    """Cascada ARCHIVADO→ROJA. Una ROJA sostenida solo por un canal débil
    (peso < peso_minimo_roja) baja a PREALERTA, salvo consenso fuerte
    (P > p_override y nodos_adj ≥ nodos_override)."""
    if not 0.0 <= e.p_bayes <= 1.0:
        raise ValueError("p_bayes fuera de [0, 1]")
    if not 0.0 <= peso_canal <= 1.0:
        raise ValueError("peso_canal fuera de [0, 1]")

    def dec(f: Fase, txt: str, deg: bool = False) -> Decision:
        return Decision(f, CODIGO_3BIT[f], txt, deg)

    if e.energia <= e.umbral:
        return dec(Fase.ARCHIVADO, "Archivado — ruido local")
    if e.sensores < 3:
        return dec(Fase.AMARILLA, "Amarilla interna — 1-2 sensores")
    if e.nodos_adj < 2:
        return dec(Fase.NARANJA, "Naranja — informe OVSICORI/RSN")
    if e.p_bayes <= cfg.p_fase3:
        return dec(Fase.PREALERTA, f"Pre-alerta — P={e.p_bayes:.2f}")
    override = e.p_bayes > cfg.p_override and e.nodos_adj >= cfg.nodos_override
    if peso_canal < cfg.peso_minimo_roja and not override:
        return dec(Fase.PREALERTA,
                   f"ROJA→pre-alerta: peso_canal={peso_canal:.2f}<"
                   f"{cfg.peso_minimo_roja:.2f} sin consenso fuerte", True)
    return dec(Fase.ROJA,
               f"ROJA — Cell Broadcast (latencia bayesiana {cfg.lat_bayes_s} s)")


CASOS_ARBOL = (
    ("Radón aislado Arenal", 0.0, Evento(1.8, 1.5, 1, 0, 0.12), PESO_CABLE, Fase.AMARILLA),
    ("Anomalía GAM", 5.5, Evento(3.2, 1.5, 3, 1, 0.55), PESO_CABLE, Fase.NARANJA),
    ("Enjambre Osa", 6.2, Evento(5.1, 1.5, 5, 2, 0.78), PESO_CABLE, Fase.PREALERTA),
    ("Dilatancia GAM", 6.5, Evento(7.3, 1.5, 6, 3, 0.92), PESO_CABLE, Fase.ROJA),
    ("Megathrust Osa", 7.5, Evento(9.8, 1.5, 8, 4, 0.97), PESO_CABLE, Fase.ROJA),
)
_E_FUERTE = Evento(9.8, 1.5, 8, 4, 0.97)
_E_DEBIL = Evento(7.3, 1.5, 6, 2, 0.90)
CASOS_GATE = (
    ("Megathrust Osa, cable primario", _E_FUERTE, PESO_CABLE, Fase.ROJA),
    ("Megathrust Osa, solo ULF degradado, consenso fuerte", _E_FUERTE,
     PESO_ULF_DEGRADADO, Fase.ROJA),
    ("Evento menor, solo ULF degradado, sin consenso fuerte", _E_DEBIL,
     PESO_ULF_DEGRADADO, Fase.PREALERTA),
)


# ══════════════════════════════════════════════════════════════════════════
#  4. DETECCIÓN, DAÑOS Y RED
# ══════════════════════════════════════════════════════════════════════════
def prob_deteccion(mw: float, precursor: str) -> float:
    """[H] Pd heurística por magnitud y calidad del precursor."""
    if precursor not in FACTOR_PRECURSOR:
        raise ValueError(f"precursor '{precursor}' inválido; use {sorted(FACTOR_PRECURSOR)}")
    base = (0.55 if mw < 6 else 0.60 if mw < 6.5 else 0.72 if mw < 7
            else 0.85 if mw < 7.5 else 0.92)
    return min(0.95, base * FACTOR_PRECURSOR[precursor])


def aviso_horas(mw: float) -> int:
    """[H] Horas de aviso por magnitud."""
    return 6 if mw < 6 else 18 if mw < 6.5 else 36 if mw < 7 else 60 if mw < 7.5 else 96


def fraccion_reducible(h: float) -> float:
    """[H] Fracción de daño evitable según horas de aviso."""
    return 0.20 if h <= 6 else 0.45 if h <= 24 else 0.70 if h <= 48 else 0.80


def deteccion_analitica(escenarios=ESCENARIOS) -> list[dict]:
    filas = []
    for s in escenarios:
        pd = prob_deteccion(s.mw, s.precursor)
        h = aviso_horas(s.mw)
        ahorro_si = s.dano_usd * fraccion_reducible(h) * EFICACIA_REDUCCION
        filas.append(dict(nombre=s.nombre, anio=s.anio, tipo=s.tipo, mw=s.mw,
                          precursor=s.precursor, pd=pd, aviso_h=h,
                          dano_musd=s.dano_usd / 1e6,
                          ahorro_si_detecta_musd=ahorro_si / 1e6,
                          ahorro_esperado_musd=pd * ahorro_si / 1e6))
    return filas


def deteccion_mc(rng: np.random.Generator, n: int, escenarios=ESCENARIOS) -> dict:
    pd = np.array([prob_deteccion(s.mw, s.precursor) for s in escenarios])
    ah = np.array([s.dano_usd * fraccion_reducible(aviso_horas(s.mw))
                   * EFICACIA_REDUCCION for s in escenarios]) / 1e6
    det = rng.random((n, len(escenarios))) < pd
    ahorro = (det * ah).sum(axis=1)
    fn = (~det).sum(axis=1)
    return dict(n=n, ahorro_medio_musd=float(ahorro.mean()),
                ahorro_se_musd=float(ahorro.std(ddof=1) / math.sqrt(n)),
                ahorro_p5_musd=float(np.percentile(ahorro, 5)),
                ahorro_p95_musd=float(np.percentile(ahorro, 95)),
                fn_medio=float(fn.mean()), n_eventos=len(escenarios))


def disponibilidad_nodo(modos=MODOS_FALLA) -> float:
    p_up = 1.0
    for _, p_ev, efic in modos:
        p_up *= 1 - p_ev * (1 - efic)
    return p_up


def p_min_k_analitica(n: int, k: int, q: float) -> float:
    return sum(comb(n, j) * q ** j * (1 - q) ** (n - j) for j in range(k, n + 1))


def red_analitica(p: Params, p_up: float, k: int = 3) -> float:
    return ((1 - P_REGIMEN_CORRELACIONADO) * p_min_k_analitica(p.n_nodos, k, p_up)
            + P_REGIMEN_CORRELACIONADO * p_min_k_analitica(p.n_nodos, k, P_UP_CORRELACIONADO))


def red_mc(rng: np.random.Generator, n: int, p: Params, p_up: float, k: int = 3) -> dict:
    q = np.where(rng.random(n) < P_REGIMEN_CORRELACIONADO, P_UP_CORRELACIONADO, p_up)
    activos = rng.binomial(p.n_nodos, q)
    frac = float((activos >= k).mean())
    return dict(n=n, p_min_k=frac, se=math.sqrt(frac * (1 - frac) / n))


# ══════════════════════════════════════════════════════════════════════════
#  5. ECONOMÍA
# ══════════════════════════════════════════════════════════════════════════
def ciclos_reemplazo(vida_anos: float, horizonte: int = 30) -> int:
    """[V] Compras de reposición dentro del horizonte (ceil, no int)."""
    if vida_anos <= 0:
        raise ValueError("vida_anos debe ser > 0")
    return max(0, ceil(horizonte / vida_anos) - 1)


def calendario_reemplazos(vidas: dict[str, float], horizonte: int) -> list[tuple[float, str, float]]:
    cal = []
    for partida, vida in vidas.items():
        for k in range(1, ciclos_reemplazo(vida, horizonte) + 1):
            cal.append((k * vida, partida, float(CAPEX_BASE[partida])))
    return sorted(cal)


def factor_anualidad(r: float, n: int) -> float:
    return sum(1 / (1 + r) ** t for t in range(1, n + 1))


def beneficio_catalogo(p: Params, phi: float | None = None,
                       gasto: float | None = None) -> dict:
    """Beneficio material esperado en el horizonte, sin VSL.

    privado = Σ_eventos Pd·daño·fracción_reducible·eficacia
    público = gasto_por_evento · Σ_eventos Pd
    ambos × φ (parte del catálogo que ocurre en el horizonte).
    El catálogo mezcla sismos ya ocurridos con un escenario y una proyección:
    φ=1 equivale a suponer los cinco dentro de los próximos 30 años [H].
    """
    phi = p.fraccion_eventos_horizonte if phi is None else phi
    gasto = p.gasto_publico_por_evento_usd if gasto is None else gasto
    filas = deteccion_analitica()
    priv = sum(f["ahorro_esperado_musd"] for f in filas) * 1e6 * phi
    pub = gasto * sum(f["pd"] for f in filas) * phi
    return dict(phi=phi, gasto=gasto, privado=priv, publico=pub, total=priv + pub,
                promedio_dano_privado=sum(f["dano_musd"] for f in filas) / len(filas) * 1e6,
                detalle=filas)


def valorar(p: Params, capex_t: float, opex1: float, calendario: list,
            *, beneficio_30: float, r: float | None = None,
            opex_factor: float = 1.0) -> dict:
    r = p.r_disc if r is None else r
    n = p.years
    reemplazos = sum(m for _, _, m in calendario)
    opex_t = [opex1 * opex_factor * (1 + p.inflacion) ** (t - 1) for t in range(1, n + 1)]
    opex_30 = sum(opex_t)
    total_30 = capex_t + opex_30 + reemplazos
    benef_a = beneficio_30 / n
    af = factor_anualidad(r, n)
    pvb = benef_a * af
    # Convención sellada: reemplazos prorrateados en partes iguales
    pvc = capex_t + sum((opex_t[t - 1] + reemplazos / n) / (1 + r) ** t
                        for t in range(1, n + 1))
    # Contraste: cada reposición en su año real
    pvc_cal = (capex_t + sum(o / (1 + r) ** t for t, o in enumerate(opex_t, 1))
               + sum(m / (1 + r) ** a for a, _, m in calendario))
    return dict(opex_30=opex_30, reemplazos=reemplazos, total_30=total_30,
                benef_total_30=beneficio_30, benef_anual=benef_a,
                bc_simple=beneficio_30 / total_30, pvb=pvb, pvc=pvc,
                van=pvb - pvc, bc_desc=pvb / pvc,
                pvc_cal=pvc_cal, van_cal=pvb - pvc_cal, bc_desc_cal=pvb / pvc_cal,
                factor_equilibrio=pvc / pvb)       # fracción del beneficio modelado que cubre el costo


# ══════════════════════════════════════════════════════════════════════════
#  6. CÁLCULO DE ENLACE
# ══════════════════════════════════════════════════════════════════════════
def calcular_enlace(p: Params, sat: bool) -> dict:
    mu_th, nd = mu_eff_teorica(p.l_core, p.d_core, p.mu_r)
    m_ref = momento_operativo(mu_efectivo(p), p, sat)
    b_ref = campo_pT(m_ref, p, sigma=sigma_trayecto(SIGMA_REF, p.grad_termico, p))
    snr_pc1 = {c: snr_db(m_ref, v, p)[1] for c, v in PC1_RUIDO.items()}
    snr_tip = snr_pc1["Típico diurno"]

    kp: list[dict[str, Any]] = []
    for k0, k1, nombre, pc1 in KP_BANDAS:
        proc = snr_db(m_ref, pc1, p)[1]
        nbit, ok = bits_requeridos(proc)
        kp.append(dict(kp=f"{k0}–{k1}", nombre=nombre, pc1_pT=pc1, snr_dB=proc,
                       bits=nbit, t_tx_s=nbit * p.t_bit, alcanzado=ok,
                       snr_eff_dB=proc + 10 * math.log10(nbit)))
    tormenta = kp[-1]
    t_storm = tormenta["t_tx_s"]
    peso_storm = peso_canal_ulf(t_storm)

    snr_estres = snr_db(m_ref, 60.0, p, rej_db=REJ_ESTRES_DB)[1]
    snr_estres_mit = snr_db(m_ref, 60.0, p, rej_db=REJ_ESTRES_MITIGADO_DB)[1]
    t_an = temperatura_fondo(GRAD_ESTRES, p)
    mu_an = mu_termico(t_an, p)
    snr_an = snr_db(momento_operativo(mu_an, p, sat), 60.0, p, grad=GRAD_ESTRES)[1]

    t_pozo = temperatura_fondo(p.grad_termico, p)
    mu_T = mu_termico(t_pozo, p)
    snr_T = snr_db(momento_operativo(mu_T, p, sat), 60.0, p)[1]

    lito: list[dict[str, Any]] = [
        dict(nombre=n, sigma_25=s, sigma=sigma_trayecto(s, p.grad_termico, p),
             atenuacion_dB=20 * math.log10(math.e) * p.depth_m
             / skin_depth_m(sigma_trayecto(s, p.grad_termico, p), p.f_ulf),
             snr_dB=snr_db(m_ref, 60.0, p, sigma=s)[1]) for n, s in LITOLOGIAS]

    termico = []
    for g in range(20, 61, 5):
        tf = temperatura_fondo(g, p)
        mf = mu_termico(tf, p)
        termico.append(dict(grad=g, t_fondo=tf, mu_T=mf,
                            snr_dB=snr_db(momento_operativo(mf, p, sat), 60.0, p, grad=g)[1]))

    majors = [p_shear(m) for m in MW_EVENTOS_MAYORES]
    return dict(
        modo="con_saturacion" if sat else "lineal",
        i_a=p.i_a, mu_teorica=mu_th, nd=nd, m_ref=m_ref, b_ref_pT=b_ref,
        mu_utilizable=mu_efectivo(p),
        margen_fabrica_dB=20 * math.log10(mu_th / p.mu_eff_design),
        potencia_media_W=potencia_media_w(p),
        snr_por_pc1=snr_pc1, snr_tipico_dB=snr_tip, kp=kp,
        tormenta=dict(nbit=tormenta["bits"], t_tx_s=t_storm,
                      majority_ok=3 * t_storm <= T_MAX_ULF_S, peso_canal=peso_storm),
        estres=dict(rej_db=REJ_ESTRES_DB, snr_dB=snr_estres,
                    rej_mitigado_db=REJ_ESTRES_MITIGADO_DB, snr_mitigado_dB=snr_estres_mit,
                    peso_canal=PESO_ULF_RECHAZO_DEGRADADO,
                    grad=GRAD_ESTRES, t_fondo=t_an, mu_T=mu_an, snr_geo_dB=snr_an),
        t_pozo=t_pozo, mu_T=mu_T, snr_Tpozo_dB=snr_T,
        litologias=lito, snr_peor_lito_dB=min(x["snr_dB"] for x in lito),
        atenuacion_max_dB=max(x["atenuacion_dB"] for x in lito),
        termico=termico,
        shear=dict(por_mw={m: p_shear(m) for m in (6.0, 6.5, 7.0, 7.5, 7.8, 8.0)},
                   p_ulf_necesario=float(np.mean(majors))),
    )


def _punto_operacion(p: Params) -> dict:
    """SNR, repeticiones y potencia del enlace saturable a la corriente de p."""
    en = calcular_enlace(p, True)
    return dict(i_a=p.i_a, snr_tipico_dB=en["snr_tipico_dB"],
                snr_estres_dB=en["estres"]["snr_dB"],
                snr_mitigado_dB=en["estres"]["snr_mitigado_dB"],
                tormenta_bits=en["tormenta"]["nbit"],
                tormenta_alcanzado=en["kp"][-1]["alcanzado"],
                tormenta_t_s=en["tormenta"]["t_tx_s"],
                potencia_W=en["potencia_media_W"])


def resumen_diseno(p: Params) -> dict:
    """Indicadores comparables de un diseño (para contrastar v7.5 y v7.6)."""
    ver = verificaciones(p, con_comparacion=False)
    e = calcular_enlace(p, True)
    ge, sa = ver["geometria"], ver["saturacion"]
    return dict(
        i_a=p.i_a, d_core_mm=p.d_core * 1000, d_sonde_mm=p.d_sonde_mm, d_hole_mm=p.d_hole_mm,
        mu_diseno=p.mu_eff_design, mu_teorico=ver["mu"]["teorica"], mu_utilizable=ver["mu"]["utilizable"],
        utilizacion=sa["utilizacion"], snr_tipico_dB=e["snr_tipico_dB"],
        snr_estres_dB=e["estres"]["snr_dB"], snr_mitigado_dB=e["estres"]["snr_mitigado_dB"],
        tormenta_bits=e["tormenta"]["nbit"], tormenta_t_s=e["tormenta"]["t_tx_s"],
        tormenta_peso=e["tormenta"]["peso_canal"],
        holgura_bobina_mm=ge["holgura_radial_mm"], holgura_pozo_mm=ge["holgura_pozo_sonda_mm"],
        d_pozo_min_mm=ge["d_pozo_min_mm"], masa_ferrita_kg=ge["masa_ferrita_kg"],
        potencia_W=e["potencia_media_W"])


def verificaciones(p: Params, con_comparacion: bool = True) -> dict:
    """Comprobaciones de diseño: saturación, margen, geometría y μ_eff."""
    mu_th, _ = mu_eff_teorica(p.l_core, p.d_core, p.mu_r)
    mu_use = mu_efectivo(p)
    a_core, a_coil = areas_m2(p)
    m_lin = momento_lineal(mu_use, p)
    m_sat = momento_saturado(p)
    util = utilizacion_bsat(mu_use, p)
    i_sat = corriente_saturacion_a(mu_use, p)
    i_obj = p.util_bsat_objetivo * i_sat
    i_margen = min(p.i_a, i_obj)
    b_nucleo = MU0 * mu_use * p.n_turns * p.i_a / p.l_core

    barrido = {}
    for b in (0.35, 0.40, 0.45, 0.55):
        pb = replace(p, b_sat_ferrita_t=b)
        ratio = momento_lineal(mu_use, pb) / momento_saturado(pb)
        barrido[f"{b:.2f}"] = dict(
            utilizacion=utilizacion_bsat(mu_use, pb),
            perdida_dB=20 * math.log10(max(1.0, ratio)),
            snr_tipico_dB=snr_db(momento_operativo(mu_use, pb, True), 60.0, pb)[1])

    d_hilo_mm = math.sqrt(4 * p.a_cond_mm2 / math.pi)
    vueltas_capa = int(p.l_core * 1000 / d_hilo_mm)
    d_ext_bob = 2 * p.r_bobina_m * 1000 + d_hilo_mm
    d_int_sonda = p.d_sonde_mm - 2 * p.espesor_pared_sonde_mm
    holgura = (d_int_sonda - d_ext_bob) / 2
    d_sonde_min = d_ext_bob + 2 * p.holgura_min_mm + 2 * p.espesor_pared_sonde_mm
    holgura_pozo = (p.d_hole_mm - p.d_sonde_mm) / 2
    d_pozo_min = d_sonde_min + 2 * p.holgura_pozo_min_mm
    hueco_nucleo = (2 * p.r_bobina_m * 1000 - d_hilo_mm - p.d_core * 1000) / 2
    masa_fer = p.rho_fer * a_core * p.l_core
    masa_cu = 8960.0 * p.n_turns * 2 * math.pi * p.r_bobina_m * p.a_cond_mm2 * 1e-6

    m_area = p.n_turns * p.i_a * (a_coil + (mu_use - 1) * a_core)
    m_sin_area = mu_use * p.n_turns * p.i_a * a_coil

    out = dict(
        saturacion=dict(
            b_nucleo_T=b_nucleo, b_sat_T=p.b_sat_ferrita_t, utilizacion=util,
            objetivo=p.util_bsat_objetivo, excede=util > 1.0,
            sin_margen=util > p.util_bsat_objetivo,
            m_lineal=m_lin, m_saturado=m_sat,
            perdida_dB=20 * math.log10(max(1.0, m_lin / m_sat)),
            corriente_saturacion_A=i_sat, i_con_margen_A=i_margen,
            i_utilizacion_objetivo_A=i_obj, barrido_bsat=barrido),
        geometria=dict(
            d_hilo_mm=d_hilo_mm, vueltas_por_capa=vueltas_capa,
            una_capa_ok=vueltas_capa >= p.n_turns,
            d_ext_bobina_mm=d_ext_bob, d_int_sonda_mm=d_int_sonda,
            holgura_radial_mm=holgura, holgura_min_mm=p.holgura_min_mm,
            ajuste_ok=holgura >= p.holgura_min_mm,
            d_sonde_min_mm=d_sonde_min, sonde_min_cabe_en_pozo=d_sonde_min < p.d_hole_mm,
            holgura_pozo_sonda_mm=holgura_pozo, holgura_pozo_min_mm=p.holgura_pozo_min_mm,
            pozo_ok=holgura_pozo >= p.holgura_pozo_min_mm, d_pozo_min_mm=d_pozo_min,
            hueco_nucleo_bobina_mm=hueco_nucleo,
            masa_ferrita_kg=masa_fer, masa_cobre_kg=masa_cu,
            nucleo_cabe_en_sonda=p.l_core <= p.l_sonde_m),
        mu=dict(teorica=mu_th, diseno=p.mu_eff_design, utilizable=mu_use,
                limitado=mu_use < p.mu_eff_design,
                margen_dB=20 * math.log10(mu_th / p.mu_eff_design),
                ok=mu_th >= p.mu_eff_design, l_sobre_d=p.l_core / p.d_core),
        area_nucleo=dict(m_con_area=m_area, m_sin_area=m_sin_area,
                         correccion_dB=20 * math.log10(m_area / m_sin_area)),
    )
    if con_comparacion:
        out["con_margen"] = _punto_operacion(replace(p, i_a=i_margen))
        out["a_objetivo"] = _punto_operacion(replace(p, i_a=i_obj))
    return out


# ══════════════════════════════════════════════════════════════════════════
#  6b. MÁRGENES DE TIEMPO Y SISMICIDAD DE FONDO
# ══════════════════════════════════════════════════════════════════════════
def mc_desde_catalogo(n_total: float, n_m5: float, b: float = 1.0, m5: float = 5.0) -> float:
    """[V] Magnitud de completitud implícita en un catálogo Gutenberg-Richter."""
    return m5 - math.log10(n_total / n_m5) / b


def mag_gr_truncada(rng: np.random.Generator, n: int, m_min: float, b: float, m_max: float) -> np.ndarray:
    """[V] Magnitudes Gutenberg-Richter truncadas (inversa de la distribución)."""
    beta = b * math.log(10)
    u = rng.random(n)
    return m_min - np.log(1 - u * (1 - np.exp(-beta * (m_max - m_min)))) / beta


def dist_km(lat: np.ndarray, lon: np.ndarray, lat0: float, lon0: float) -> np.ndarray:
    dy = (lat - lat0) * 111.2
    dx = (lon - lon0) * 111.2 * np.cos(np.radians((lat + lat0) / 2))
    return np.hypot(dx, dy)


def m_detectable(r_km: np.ndarray) -> np.ndarray:
    return M_DET_A + M_DET_B * np.log10(np.maximum(r_km, 1.0))


def fases_vectorizado(delta: np.ndarray, sensores: np.ndarray, nodos_adj: np.ndarray,
                      p_bayes: np.ndarray, peso: float = PESO_CABLE,
                      cfg: ConfigArbol = CFG_ARBOL) -> np.ndarray:
    """Misma cascada que evaluar_evento, vectorizada (delta = Mw − Mw detectable)."""
    override = (p_bayes > cfg.p_override) & (nodos_adj >= cfg.nodos_override)
    f = np.full(delta.shape, int(Fase.ROJA))
    if peso < cfg.peso_minimo_roja:
        f = np.where(~override, int(Fase.PREALERTA), f)
    f = np.where(p_bayes <= cfg.p_fase3, int(Fase.PREALERTA), f)
    f = np.where(nodos_adj < 2, int(Fase.NARANJA), f)
    f = np.where(sensores < 3, int(Fase.AMARILLA), f)
    return np.where(delta <= 0, int(Fase.ARCHIVADO), f)


def p_bayes_desde_lr(xi: np.ndarray, sigma: float, prior: float = PRIOR_96H) -> np.ndarray:
    """Posterior con razón de verosimilitud log-normal: LR = 10^(σ·ξ), ξ ~ N(0,1)."""
    log_odds = math.log(prior / (1 - prior)) + sigma * xi * math.log(10)
    return 1 / (1 + np.exp(-np.clip(log_odds, -700, 700)))


def phi_cola_normal(x: float) -> float:
    return 0.5 * math.erfc(x / math.sqrt(2))


def xi_umbral(sigma: float, cfg: ConfigArbol = CFG_ARBOL, prior: float = PRIOR_96H) -> float:
    """ξ a partir del cual el posterior supera p_fase3."""
    lr = (cfg.p_fase3 / (1 - cfg.p_fase3)) / (prior / (1 - prior))
    return math.log10(lr) / sigma


def sigma_critico(tasa_pasan_anio: float, meta_anio: float = FA_ANUAL,
                  cfg: ConfigArbol = CFG_ARBOL) -> float:
    """Mayor σ_LR con el que la tasa de ROJA de fondo no supera la meta (bisección)."""
    if tasa_pasan_anio <= meta_anio:
        return math.inf
    lo, hi = 0.05, 50.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if tasa_pasan_anio * phi_cola_normal(xi_umbral(mid, cfg)) > meta_anio:
            hi = mid
        else:
            lo = mid
    return lo


def poisson_ic95(k: int) -> tuple[float, float]:
    """IC95 % de un conteo de Poisson (aproximación de Wilson-Hilferty; k = 0 → regla de tres)."""
    if k == 0:
        return 0.0, 3.0
    hi = (k + 1) * (1 - 1 / (9 * (k + 1)) + 1.96 / (3 * math.sqrt(k + 1))) ** 3
    lo = k * (1 - 1 / (9 * k) - 1.96 / (3 * math.sqrt(k))) ** 3
    return lo, hi


def cola_fifo(llegadas_s: np.ndarray, servicio_s: float) -> np.ndarray:
    """Espera (s) de cada mensaje en una cola FIFO de un servidor (recursión de Lindley)."""
    w = np.zeros(len(llegadas_s))
    fin = -math.inf
    for i, t in enumerate(llegadas_s):
        inicio = max(float(t), fin)
        w[i] = inicio - t
        fin = inicio + servicio_s
    return w


def cabe_en_tmax(t_s: float, alcanzado: bool = True) -> bool:
    """¿Cabe una transmisión de t_s segundos en T_max? Un enlace que no alcanza el SNR objetivo no cabe."""
    return alcanzado and t_s <= T_MAX_ULF_S


def presupuesto_tiempo(p: Params, enlace: dict, cfg: ConfigArbol = CFG_ARBOL) -> dict:
    """Presupuesto de tiempo del enlace ULF por condición geomagnética frente a T_max."""
    filas = []
    for k in enlace["kp"]:
        t_bit_ef = k["t_tx_s"]
        t_msg = N_BITS_MENSAJE * t_bit_ef
        lat1 = t_bit_ef + cfg.lat_bayes_s + LAT_CB_S
        filas.append(dict(
            nombre=k["nombre"], kp=k["kp"], p_tiempo=KP_TIEMPO[k["nombre"]], nbit=k["bits"],
            alcanzado=k["alcanzado"], t_primer_bit_s=t_bit_ef, t_mensaje_s=t_msg,
            lat_ulf_primer_bit_s=lat1,
            margen_primer_bit_s=T_MAX_ULF_S - t_bit_ef, margen_mensaje_s=T_MAX_ULF_S - t_msg,
            ok_primer_bit=cabe_en_tmax(t_bit_ef, k["alcanzado"]),
            ok_mensaje=cabe_en_tmax(t_msg, k["alcanzado"])))
    lat_min = min(f["lat_ulf_primer_bit_s"] for f in filas)
    lat_peor = max(f["lat_ulf_primer_bit_s"] for f in filas)
    aviso = []
    for mw in (5.5, 6.0, 6.5, 7.0, 7.5, 7.8):
        h = aviso_horas(mw)
        aviso.append(dict(mw=mw, aviso_h=h, lat_peor_h=lat_peor / 3600, margen_h=h - lat_peor / 3600,
                          fraccion_consumida=lat_peor / 3600 / h))
    return dict(
        filas=filas, n_bits_mensaje=N_BITS_MENSAJE, t_max_s=T_MAX_ULF_S,
        frac_tiempo_mensaje_no_cabe=sum(f["p_tiempo"] for f in filas if not f["ok_mensaje"]),
        frac_tiempo_primer_bit_no_cabe=sum(f["p_tiempo"] for f in filas if not f["ok_primer_bit"]),
        lat_cable_s=T_CABLE_S, lat_ulf_supuesta_s=T_ULF_S, lat_ulf_min_s=lat_min, lat_ulf_peor_s=lat_peor,
        lat_ulf_consistente=T_ULF_S >= lat_min, aviso=aviso)


def sismicidad_fondo(rng: np.random.Generator, n_dias: int, presupuesto: dict,
                     cfg: ConfigArbol = CFG_ARBOL) -> dict:
    """Simula n_dias de sismicidad de fondo (Poisson + Gutenberg-Richter) y la pasa por la cascada."""
    if n_dias < 30:
        raise ValueError("n_dias debe ser ≥ 30")
    sf = SISMICIDAD_FONDO
    lam = sf["n_anio"] / 365.0
    m_min = mc_desde_catalogo(sf["n_anio"], sf["n_m5_anio"], sf["b"])
    t_total = n_dias * 86400.0
    n = int(rng.poisson(lam * n_dias))
    t = np.sort(rng.random(n) * t_total)
    dia = np.minimum((t // 86400).astype(int), n_dias - 1)
    lat = rng.uniform(*REGION_LAT, n)
    lon = rng.uniform(*REGION_LON, n)
    mw = mag_gr_truncada(rng, n, m_min, sf["b"], sf["m_max"])
    d = np.stack([dist_km(lat, lon, la, lo) for _, la, lo in NODOS_ILUSTRATIVOS], axis=1)
    cerca = np.argmin(d, axis=1)
    idx = np.arange(n)
    det = mw[:, None] >= m_detectable(d)
    delta = mw - m_detectable(d[idx, cerca])
    nodos_adj = det.sum(axis=1) - det[idx, cerca]
    sensores = np.where(delta > 0, np.minimum(N_SENSORES, 1 + np.floor(SENSORES_POR_UNIDAD * delta)), 0).astype(int)
    xi = rng.standard_normal(n)
    pasa = (delta > 0) & (sensores >= 3) & (nodos_adj >= 2)
    anios = n_dias / 365.25

    def fases(sigma: float) -> np.ndarray:
        return fases_vectorizado(delta, sensores, nodos_adj, p_bayes_desde_lr(xi, sigma), PESO_CABLE, cfg)

    f0 = fases(SIGMA_LR)
    nombres = [fa.name for fa in Fase]
    conteo = np.bincount(f0, minlength=5)
    tabla = {nombres[i]: dict(n=int(conteo[i]), por_dia=float(conteo[i] / n_dias),
                              porcentaje=float(100 * conteo[i] / max(n, 1))) for i in range(5)}
    k_roja = int(conteo[int(Fase.ROJA)])
    roja_lo, roja_hi = poisson_ic95(k_roja)
    por_dia = np.bincount(dia, minlength=n_dias)

    def solape(tt: np.ndarray) -> float:
        if len(tt) < 2:
            return 0.0
        g = np.diff(tt) < VENTANA_S
        s_ = np.zeros(len(tt), bool)
        s_[1:] |= g
        s_[:-1] |= g
        return float(s_.mean())

    det_near = delta > 0
    tasa_det = det_near.sum() / t_total
    # Cola ULF por nodo y por condición geomagnética (si el cable estuviera caído)
    msg = f0 >= int(Fase.NARANJA)
    colas = []
    for fila in presupuesto["filas"]:
        serv = fila["t_mensaje_s"]
        esperas = []
        for j in range(len(NODOS_ILUSTRATIVOS)):
            llegadas = t[msg & (cerca == j)]
            if len(llegadas):
                esperas.append(cola_fifo(llegadas, serv))
        w = np.concatenate(esperas) if esperas else np.zeros(0)
        colas.append(dict(
            nombre=fila["nombre"], servicio_s=serv, mensajes=int(len(w)),
            rho=float(len(w) * serv / (t_total * len(NODOS_ILUSTRATIVOS))),
            espera_media_s=float(w.mean()) if len(w) else 0.0,
            espera_p99_s=float(np.percentile(w, 99)) if len(w) else 0.0,
            espera_max_s=float(w.max()) if len(w) else 0.0,
            p_espera=float((w > 0).mean()) if len(w) else 0.0,
            p_espera_mayor_tmax=float((w > T_MAX_ULF_S).mean()) if len(w) else 0.0))
    tasa_pasan = float(pasa.sum() / anios)
    sens = []
    for sg in SIGMAS_BARRIDO:
        k = int((fases(sg) == int(Fase.ROJA)).sum())
        lo, hi = poisson_ic95(k)
        sens.append(dict(sigma=sg, roja_anio=k / anios, ic_lo=lo / anios, ic_hi=hi / anios,
                         analitico_anio=tasa_pasan * phi_cola_normal(xi_umbral(sg, cfg))))
    return dict(
        n_dias=n_dias, anios=anios, eventos=n, eventos_dia_esperado=lam, mc=m_min, b=sf["b"],
        fuente="OVSICORI 2024: 13 495 sismos localizados y 36 de Mw ≥ 5 (Diario Extra, 2024)",
        por_dia=dict(media=float(por_dia.mean()), p50=float(np.percentile(por_dia, 50)),
                     p95=float(np.percentile(por_dia, 95)), p99=float(np.percentile(por_dia, 99)),
                     maximo=int(por_dia.max())),
        espaciado_medio_min=float(1440 / lam), fases=tabla,
        detectados_por_dia=float(det_near.sum() / n_dias), mensajes_por_dia=float(msg.sum() / n_dias),
        pasan_compuertas_anio=tasa_pasan, sigma_lr=SIGMA_LR, roja_anio=k_roja / anios,
        roja_ic95_anio=(roja_lo / anios, roja_hi / anios),
        solapamiento=dict(ventana_s=VENTANA_S, simulado=solape(t), analitico=1 - math.exp(-2 * lam / 86400 * VENTANA_S),
                          simulado_detectados=solape(t[det_near]),
                          analitico_detectados=1 - math.exp(-2 * tasa_det * VENTANA_S)),
        cola_ulf=colas, sensibilidad_sigma=sens, sigma_critico=sigma_critico(tasa_pasan, FA_ANUAL, cfg),
        sensibilidad_sismicidad=dict(tasa_2025_por_dia=sf["n_anio_2025"] / 365.0,
                                     factor=sf["n_anio_2025"] / sf["n_anio"]))


def fraccion_omori(horas: float, c_dias: float, t_catalogo_dias: float) -> float:
    """[V] Fracción de las réplicas de la secuencia que ocurre en las primeras `horas` (Omori-Utsu, p = 1)."""
    h = horas / 24.0
    return math.log((h + c_dias) / c_dias) / math.log((t_catalogo_dias + c_dias) / c_dias)


def tiempos_omori(rng: np.random.Generator, n: int, horas: float, c_dias: float) -> np.ndarray:
    """[V] Tiempos (s) de n réplicas en [0, horas], por inversa de la CDF de Omori-Utsu con p = 1."""
    h = horas / 24.0
    u = rng.random(n)
    return np.sort((c_dias * ((h + c_dias) / c_dias) ** u - c_dias) * 86400.0)


def replicas_cable_cortado(rng: np.random.Generator, presupuesto: dict, n_rep: int = N_REP_DEFECTO,
                           nodo: int = 0, cfg: ConfigArbol = CFG_ARBOL) -> dict:
    """Réplicas de un sismo grande con el cable del nodo cortado: el canal ULF atiende solo."""
    if n_rep < 2:
        raise ValueError("n_rep debe ser ≥ 2")
    sf, rp = SISMICIDAD_FONDO, REPLICAS
    mc = mc_desde_catalogo(sf["n_anio"], sf["n_m5_anio"], sf["b"])
    m_max = rp["m_main"] - rp["bath"]
    n_total = 10 ** (sf["b"] * (m_max - mc))
    frac = fraccion_omori(rp["horas"], rp["c_dias"], rp["t_catalogo_dias"])
    nombre, la0, lo0 = NODOS_ILUSTRATIVOS[nodo]
    t_horizonte = rp["horas"] * 3600.0
    filas = presupuesto["filas"]
    n_sismos: list[int] = []
    n_msg: list[int] = []
    n_roja: list[int] = []
    fases_acum = np.zeros(5)
    waits: list[list[np.ndarray]] = [[] for _ in filas]
    fin_h: list[list[float]] = [[] for _ in filas]       # hora en que arranca la última atención
    dren: list[list[float]] = [[] for _ in filas]
    for _ in range(n_rep):
        n = int(rng.poisson(n_total * frac))
        t = tiempos_omori(rng, n, rp["horas"], rp["c_dias"])
        mw = mag_gr_truncada(rng, n, mc, sf["b"], m_max)
        r = rp["radio_km"] * np.sqrt(rng.random(n))
        ang = rng.random(n) * 2 * math.pi
        lat = la0 + r * np.sin(ang) / 111.2
        lon = lo0 + r * np.cos(ang) / (111.2 * math.cos(math.radians(la0)))
        d = np.stack([dist_km(lat, lon, la, lo) for _, la, lo in NODOS_ILUSTRATIVOS], axis=1)
        cerca = np.argmin(d, axis=1)
        idx = np.arange(n)
        det = mw[:, None] >= m_detectable(d)
        delta = mw - m_detectable(d[idx, cerca])
        nodos_adj = det.sum(axis=1) - det[idx, cerca]
        sensores = np.where(delta > 0, np.minimum(N_SENSORES, 1 + np.floor(SENSORES_POR_UNIDAD * delta)), 0).astype(int)
        f = fases_vectorizado(delta, sensores, nodos_adj, p_bayes_desde_lr(rng.standard_normal(n), SIGMA_LR), PESO_CABLE, cfg)
        msg = (f >= int(Fase.NARANJA)) & (cerca == nodo)
        llegadas = t[msg]
        n_sismos.append(n)
        n_msg.append(int(msg.sum()))
        n_roja.append(int(((f == int(Fase.ROJA)) & (cerca == nodo)).sum()))
        fases_acum += np.bincount(f[cerca == nodo], minlength=5)
        for j, fila in enumerate(filas):
            w = cola_fifo(llegadas, fila["t_mensaje_s"])
            waits[j].append(w)
            fin_h[j].append(float((llegadas + w).max() / 3600.0) if len(w) else 0.0)
            dren[j].append(float(w[-1] + fila["t_mensaje_s"]) if len(w) else 0.0)
    colas = []
    for j, fila in enumerate(filas):
        todas = np.concatenate(waits[j]) if any(len(w) for w in waits[j]) else np.zeros(0)
        maximos = np.array([w.max() if len(w) else 0.0 for w in waits[j]])
        carga = np.array([len(w) * fila["t_mensaje_s"] for w in waits[j]]) / t_horizonte
        colas.append(dict(
            nombre=fila["nombre"], servicio_s=fila["t_mensaje_s"], rho_24h=float(carga.mean()),
            espera_media_s=float(todas.mean()) if len(todas) else 0.0,
            espera_max_media_s=float(maximos.mean()), espera_max_p95_s=float(np.percentile(maximos, 95)),
            p_espera_mayor_tmax=float((todas > T_MAX_ULF_S).mean()) if len(todas) else 0.0,
            drenaje_medio_s=float(np.mean(dren[j])), cola_no_vacia_24h=float(np.mean([x > rp["horas"] for x in fin_h[j]])),
            latencia_111_con_preempcion_s=fila["t_primer_bit_s"] + VENTANA_S + cfg.lat_bayes_s + LAT_CB_S))
    return dict(
        nodo=nombre, n_rep=n_rep, m_main=rp["m_main"], m_max_replica=m_max, horas=rp["horas"],
        replicas_total_esperadas=float(n_total), fraccion_primeras_horas=frac, radio_km=rp["radio_km"],
        sismos_24h=float(np.mean(n_sismos)), mensajes_24h=float(np.mean(n_msg)),
        mensajes_roja_24h=float(np.mean(n_roja)),
        fases_24h={fa.name: float(fases_acum[int(fa)] / n_rep) for fa in Fase}, colas=colas)


def sensibilidad_estres(p: Params, enlace: dict) -> dict:
    """Rechazo de ruido necesario y sensibilidad al coeficiente térmico de la conductividad."""
    snr_ref = enlace["snr_tipico_dB"]
    rej_min = p.rej_db - (snr_ref - SNR_OBJETIVO_DB)
    rechazos = [dict(rej_db=r, snr_dB=snr_ref - (p.rej_db - r), margen_dB=snr_ref - (p.rej_db - r) - SNR_OBJETIVO_DB)
                for r in RECHAZOS_BARRIDO]
    alphas = []
    for a in ALPHAS_BARRIDO:
        e = calcular_enlace(replace(p, alpha_sigma=a), True)
        alphas.append(dict(alpha=a, snr_peor_lito_dB=e["snr_peor_lito_dB"], atenuacion_max_dB=e["atenuacion_max_dB"],
                           snr_tipico_dB=e["snr_tipico_dB"]))
    return dict(rechazo_nominal_db=p.rej_db, rechazo_minimo_db=rej_min,
                rechazo_minimo_con_margen_db=rej_min + MARGEN_SNR_MIN_DB, rechazos=rechazos, alphas=alphas)


# ══════════════════════════════════════════════════════════════════════════
#  7. SIMULACIÓN COMPLETA (sin imprimir)
# ══════════════════════════════════════════════════════════════════════════
def simular(p: Params = P0, seed: int = SEED, saturacion: bool = True,
            n_mc: int = 100_000, n_dias: int = DIAS_SIM, n_rep: int = N_REP_DEFECTO) -> dict:
    if n_mc < 2:
        raise ValueError("n_mc debe ser ≥ 2")
    ss = np.random.SeedSequence(seed)
    rng_det, rng_red, rng_sis, rng_rep = (np.random.default_rng(s) for s in ss.spawn(4))

    dias_pozo = p.depth_m / p.rop_m_dia
    dias_nodo = dias_pozo + p.dias_compl
    meses_red = dias_nodo * p.n_nodos / p.n_equipos / 30

    enlace_lin = calcular_enlace(p, False)
    enlace_sat = calcular_enlace(p, True)
    principal = enlace_sat if saturacion else enlace_lin
    ver = verificaciones(p)
    presup = presupuesto_tiempo(p, enlace_sat if saturacion else enlace_lin)
    sismos = sismicidad_fondo(rng_sis, n_dias, presup)
    replicas = replicas_cable_cortado(rng_rep, presup, n_rep)
    sens_estres = sensibilidad_estres(p, enlace_sat if saturacion else enlace_lin)
    comparacion: dict[str, Any] = {
        "v75_como_se_recibio": resumen_diseno(PARAMS_V75),
        "v75_con_mu_fisico": resumen_diseno(replace(PARAMS_V75, mu_limitado_por_geometria=True)),
        "vigente": resumen_diseno(p)}
    try:
        comparacion["alternativa_nucleo_200"] = resumen_diseno(replace(p, **ALTERNATIVA_N200))
    except ValueError:
        comparacion["alternativa_nucleo_200"] = None

    # Costos
    sub = sum(CAPEX_BASE.values())
    cont = int(round(sub * p.contingencia_pct))
    capex_t = sub + cont
    opex1 = sum(OPEX_ANUAL.values())
    cal = calendario_reemplazos(VIDA_UTIL, p.years)
    cal_amp = calendario_reemplazos({**VIDA_UTIL, **VIDA_UTIL_TI_AMPLIADO}, p.years)

    ben = beneficio_catalogo(p)
    val = valorar(p, capex_t, opex1, cal, beneficio_30=ben["total"])
    val_amp = valorar(p, capex_t, opex1, cal_amp, beneficio_30=ben["total"])
    ben_pr = beneficio_catalogo(p, phi=PHI_PRUDENTE, gasto=GASTO_PUBLICO_PRUDENTE)
    val_pr = valorar(p, capex_t, opex1, cal, beneficio_30=ben_pr["total"])
    ben_priv1 = beneficio_catalogo(p, phi=1.0, gasto=0.0)
    val_priv1 = valorar(p, capex_t, opex1, cal, beneficio_30=ben_priv1["total"])
    phi_eq_total = val["factor_equilibrio"] * p.fraccion_eventos_horizonte
    phi_eq_priv = val_priv1["factor_equilibrio"]

    sens_r = {f"{r:.2f}": dict(van=(v := valorar(p, capex_t, opex1, cal,
                                                 beneficio_30=ben["total"], r=r))["van"],
                               bc_desc=v["bc_desc"])
              for r in (0.03, 0.06, 0.08, 0.12)}
    sens_opex = {f"opex{round(f * 100)}": valorar(p, capex_t, opex1, cal,
                                                beneficio_30=ben["total"], opex_factor=f)["bc_desc"]
                 for f in (0.8, 1.0, 1.2, 1.4)}
    sens_phi = {}
    for phi in (0.2, 0.4, 0.6, 0.8, 1.0):
        fila = {}
        for etiqueta, g in (("con_gasto_publico", p.gasto_publico_por_evento_usd),
                            ("solo_privado", 0.0)):
            b_ = beneficio_catalogo(p, phi=phi, gasto=g)
            fila[etiqueta] = valorar(p, capex_t, opex1, cal, beneficio_30=b_["total"])["bc_desc"]
        sens_phi[f"{phi:.1f}"] = fila
    sens_capex = {f"capex{round(f * 100)}": valorar(p, capex_t * f, opex1, cal,
                                                  beneficio_30=ben["total"])["bc_desc"]
                  for f in (1.0, 1.15, 1.3, 1.5)}
    sens_gasto = {f"{int(g / 1e6)}M": valorar(
        p, capex_t, opex1, cal,
        beneficio_30=beneficio_catalogo(p, gasto=g)["total"])["bc_desc"]
        for g in (0.0, 10e6, 25e6, 50e6)}

    # Detección y red
    det_an = deteccion_analitica()
    det_mc = deteccion_mc(rng_det, n_mc)
    det_an_total = sum(f["ahorro_esperado_musd"] for f in det_an)
    p_up = disponibilidad_nodo()
    p3_an = red_analitica(p, p_up)
    p3_mc = red_mc(rng_red, n_mc, p, p_up)

    arbol = [dict(nombre=n, mw=mw, peso=peso, esperado=int(exp),
                  **_dec_dict(evaluar_evento(ev, peso)))
             for n, mw, ev, peso, exp in CASOS_ARBOL]
    gate = [dict(etiqueta=et, peso=peso, esperado=int(exp),
                 **_dec_dict(evaluar_evento(ev, peso)))
            for et, ev, peso, exp in CASOS_GATE]

    res = dict(
        schema=SCHEMA, version=VERSION, inventor=INVENTOR,
        fecha_divulgacion=FECHA_DIVULGACION, semilla=seed,
        modo_principal=principal["modo"],
        parametros=asdict(p),
        despliegue=dict(dias_pozo=dias_pozo, dias_nodo=dias_nodo, meses_red=meses_red,
                        n_equipos=p.n_equipos, masa_ferrita_kg=ver["geometria"]["masa_ferrita_kg"]),
        potencia_media_W=principal["potencia_media_W"],
        enlace_principal=principal, enlace_lineal=enlace_lin, enlace_saturado=enlace_sat,
        arbol=arbol, gate_canal=gate,
        deteccion=dict(por_escenario=det_an, ahorro_esperado_musd=det_an_total, mc=det_mc),
        costos=dict(capex_subtotal=sub, contingencia=cont, capex=capex_t,
                    capex_partidas=dict(CAPEX_BASE), opex_partidas=dict(OPEX_ANUAL),
                    vida_util=dict(VIDA_UTIL), opex_anual=opex1, **val,
                    beneficio_privado_30=ben["privado"], beneficio_publico_30=ben["publico"],
                    promedio_dano_privado=ben["promedio_dano_privado"],
                    calendario=[dict(anio=a, partida=n, usd=m) for a, n, m in cal],
                    cobertura_reemplazos=dict(
                        partidas_con_reposicion=len(VIDA_UTIL), partidas_capex=len(CAPEX_BASE),
                        escenario_ti_ampliado=dict(
                            reemplazos=val_amp["reemplazos"], van=val_amp["van"],
                            bc_desc=val_amp["bc_desc"])),
                    caso_prudente=dict(phi=PHI_PRUDENTE, gasto=GASTO_PUBLICO_PRUDENTE,
                                       beneficio_30=ben_pr["total"], van=val_pr["van"],
                                       bc_desc=val_pr["bc_desc"]),
                    equilibrio=dict(phi_total=phi_eq_total, phi_solo_privado=phi_eq_priv,
                                    factor_beneficio=val["factor_equilibrio"])),
        sensibilidad=dict(tasa_descuento=sens_r, opex_bc_desc=sens_opex, capex_bc_desc=sens_capex,
                          phi_bc_desc=sens_phi, gasto_publico_bc_desc=sens_gasto),
        red=dict(disp_nodo=p_up, p_min3_analitica=p3_an, p_min3_mc=p3_mc),
        latencia=dict(cable_s=T_CABLE_S, ulf_s=T_ULF_S, fa_anual=FA_ANUAL,
                      nota="Supuestos de diseño [H], no calculados por este modelo"),
        verificaciones=ver, comparacion_disenos=comparacion,
        margenes_tiempo=dict(presupuesto=presup, sismicidad=sismos, replicas=replicas),
        sensibilidad_estres=sens_estres,
    )
    res["hallazgos"] = construir_hallazgos(p, res)
    res["supuestos"] = SUPUESTOS
    return res


def _dec_dict(d: Decision) -> dict:
    return dict(fase=int(d.fase), fase_nombre=d.fase.name, codigo=d.codigo,
                texto=d.texto, degradada=d.degradada)


SUPUESTOS = [
    dict(id="H01", tag="H", tema="Rechazo de ruido Pc1 = 30 dB (referencia remota)",
         impacto="A 10 dB el SNR típico cae por debajo del umbral de 20 dB"),
    dict(id="H02", tag="H", tema="Ganancia de integración 10·log10(f·T) usa la frecuencia de portadora como ancho de banda de ruido",
         impacto="Aporta 17.8 dB del SNR procesado"),
    dict(id="H03", tag="H", tema="μ_r del material = 2000 y μ_eff de diseño = 200; el modelo usa el menor entre 200 y el teórico de la geometría del núcleo (156 con Ø185 mm × 4 m); núcleo ensamblado por segmentos",
         impacto="A mayor diámetro, menor μ_eff máximo; las juntas lo reducen aún más"),
    dict(id="H04", tag="H", tema="B_sat de la ferrita = 0.40 T a temperatura de pozo (verificar con hoja de datos)",
         impacto="Define la corriente máxima útil (I_sat) y el tope del momento dipolar"),
    dict(id="H05", tag="H", tema="Pd, horas de aviso, fracción reducible y eficacia 0.7 no están validadas con datos",
         impacto="Determina el beneficio por daños evitados"),
    dict(id="H06", tag="H", tema="Daños de cada escenario sísmico (USD)", impacto="Beneficio privado"),
    dict(id="H07", tag="H", tema="Gasto público evitado = USD 25 M por evento detectado, independiente de la magnitud y sin reducción",
         impacto="≈ 25 % del beneficio base; posible doble conteo con los daños"),
    dict(id="H08", tag="H", tema="Catálogo de 5 sismos (3 ya ocurridos) tratado como portafolio de 30 años (φ = 100 %)",
         impacto="El B/C escala linealmente con φ"),
    dict(id="H09", tag="H", tema="OPEX anual USD 398 k; montos del código v6.x, rótulos provisionales asignados en v7.1",
         impacto="≈ 75 % del costo a 30 años"),
    dict(id="H10", tag="H", tema="Vidas útiles: Rb-87 7.5 a, sondas 15 a, DAS/SQUID/telecom 10 a",
         impacto="Fondo de reemplazos (5 de 14 partidas)"),
    dict(id="H11", tag="H", tema="Tasa de descuento 6 %, inflación 3.5 %", impacto="Confirmar tasa social oficial con MIDEPLAN"),
    dict(id="H12", tag="H", tema="Modos de falla de nodo y régimen correlacionado 8 % / 0.55", impacto="Disponibilidad de red"),
    dict(id="H13", tag="H", tema="P(cizalla): k=1.937, M0=7.581; calibración no documentada", impacto="P(ULF necesario)"),
    dict(id="H14", tag="H", tema="Latencias 5.7/7.3 s y falsas alarmas 0.05/año son constantes, no cálculos", impacto="KPIs de servicio"),
    dict(id="H15", tag="H", tema="Pesos de canal 1.00 / 0.70 / 0.40 / 0.35 (política de decisión)", impacto="Compuerta ROJA→pre-alerta"),
    dict(id="H16", tag="H", tema="σ basalto húmedo 1.2e-4 S/m a 25 °C; las demás litologías según la tabla", impacto="Atenuación de unos 2 a 3 dB en el peor caso (arcilla ácida)"),
    dict(id="H17", tag="H", tema="Pared de sonda 6 mm y holgura radial mínima bobina–pared 5 mm", impacto="Diámetro mínimo de la sonda"),
    dict(id="H18", tag="H", tema="Utilización máxima recomendada de B_sat = 80 % y margen mínimo de SNR de 1 dB para llamar «cerrado» a un enlace", impacto="Corriente de diseño y lectura del estrés"),
    dict(id="H19", tag="H", tema="Holgura radial mínima sonda–pozo = 10 mm", impacto="Diámetro mínimo del pozo; sin entubado considerado"),
    dict(id="H20", tag="H", tema="CAPEX, ROP (45 m/día) y días de completación provienen de la geometría v6.x (pozo Ø200 mm, núcleo Ø100 mm)", impacto="Costo y plazo de la geometría vigente sin recalcular"),
    dict(id="F01", tag="F", tema="Sismicidad de fondo: 13 495 sismos localizados en 2024 (38 por día) y 36 de Mw ≥ 5.0 (OVSICORI vía Diario Extra); 14 481 en 2025", impacto="Tasa y magnitud de completitud (Mc = 2.43 con b = 1)"),
    dict(id="H21", tag="H", tema="Detectabilidad: Mw mínima a r km = 1.0 + 1.7·log10(r); sensores = 1 + 2.5 por unidad de Mw sobre el umbral; epicentros uniformes en 8.0–11.2 N y 86.0–82.5 O", impacto="Cuántos sismos de fondo llegan a cada compuerta"),
    dict(id="H22", tag="H", tema="Posterior bayesiano del fondo: prior de 6.3e-4 por ventana de 96 h (2 eventos Mw ≥ 7.5 en 35 años) y razón de verosimilitud log-normal con σ = 0.5", impacto="Tasa de ROJA de fondo; se muestra el criterio de aceptación"),
    dict(id="H23", tag="H", tema="Fracciones de tiempo por condición geomagnética: 40 / 45 / 14.5 / 0.5 %", impacto="Tiempo en que el mensaje completo no cabe en T_max"),
    dict(id="H24", tag="H", tema="Mensaje ULF de 3 bits (001 / 010 / 111) con el bit más significativo primero; Cell Broadcast de 2 s", impacto="El primer bit basta para reconocer 111"),
    dict(id="H25", tag="H", tema="Coeficiente térmico de la conductividad α = 2 %/°C (electrolito en poros), integrado a lo largo del pozo; no sustituye un modelo de Archie calibrado", impacto="Atenuación en rocas conductivas; efecto menor que 0.4 dB en el SNR"),
    dict(id="H26", tag="H", tema="Réplicas: Omori-Utsu con p = 1 y c = 0.05 d, magnitud máxima = Mw − 1.2 (Båth), Gutenberg-Richter con la Mc del catálogo, disco de 80 km alrededor del nodo, mismo prior y σ_LR que el fondo", impacto="Carga del canal ULF con el cable cortado"),
    dict(id="H27", tag="H", tema="Preempción de 111 en el límite de cada repetición de 30 s (propuesta, no implementada en el protocolo)", impacto="Latencia de la alerta roja con el ULF ocupado"),
    dict(id="V01", tag="V", tema="Profundidad pelicular, campo de dipolo, μ_eff de varilla, momento con área de núcleo, ceil() en reposiciones, valor presente",
         impacto="Fórmulas estándar"),
]


def construir_hallazgos(p: Params, r: dict) -> list[dict]:
    v = r["verificaciones"]
    sa, ao, ge, mu = v["saturacion"], v["a_objetivo"], v["geometria"], v["mu"]
    c = r["costos"]
    e = r["enlace_principal"]
    pr, eq = c["caso_prudente"], c["equilibrio"]
    h: list[dict] = []

    # F1 — saturación / margen
    sev = "ALTO" if sa["excede"] else ("MEDIO" if sa["sin_margen"] else "BAJO")
    b35 = sa["barrido_bsat"]["0.35"]
    c35 = (f"con B_sat = 0.35 T la utilización sería {b35['utilizacion'] * 100:.0f} %"
           + (f" y se perderían {b35['perdida_dB']:.1f} dB" if b35["perdida_dB"] > 0
              else ", aún sin saturar"))
    h.append(dict(
        id="F1", severidad=sev,
        titulo=(f"Núcleo operando al {sa['utilizacion'] * 100:.0f} % de B_sat "
                f"(objetivo ≤ {sa['objetivo'] * 100:.0f} %)"),
        detalle=(f"I = {p.i_a:.1f} A frente a I_sat = {sa['corriente_saturacion_A']:.1f} A "
                 f"(B_sat = {sa['b_sat_T']:.2f} T supuesto, H04); {c35}. A la utilización objetivo "
                 f"(I = {ao['i_a']:.1f} A): SNR típico {ao['snr_tipico_dB']:.1f} dB, estrés "
                 f"{ao['snr_estres_dB']:.1f} dB, potencia {ao['potencia_W']:.1f} W."),
        accion="Confirmar B_sat con el fabricante; si es < 0.40 T, reducir I a la corriente con margen."))

    # F2 — enlace bajo estrés
    est, tor = e["estres"], e["tormenta"]
    margen = est["snr_dB"] - SNR_OBJETIVO_DB
    cierra, holgado = margen >= 0, margen >= MARGEN_SNR_MIN_DB
    tormenta_ok = tor["t_tx_s"] <= T_MAX_ULF_S and e["kp"][-1]["alcanzado"]
    if not cierra:
        titulo2 = "El enlace ULF no cierra con rechazo degradado" + ("" if tormenta_ok else " ni en tormenta")
    elif not holgado:
        titulo2 = ("El enlace ULF cierra con rechazo degradado solo con margen mínimo"
                   + ("" if tormenta_ok else "; en tormenta queda degradado"))
    else:
        titulo2 = "El enlace ULF cierra con rechazo degradado" + ("" if tormenta_ok else "; en tormenta queda degradado")
    if not e["kp"][-1]["alcanzado"]:
        parte_t = (f"En tormenta (Kp ≥ 7) no se alcanzan {SNR_OBJETIVO_DB:.0f} dB ni con {MAX_BITS} "
                   f"repeticiones: el canal queda con peso {tor['peso_canal']:.2f}.")
    else:
        parte_t = (f"En tormenta (Kp ≥ 7) se requieren {tor['nbit']} repeticiones = {tor['t_tx_s']:.0f} s, "
                   + ("dentro de" if tor["t_tx_s"] <= T_MAX_ULF_S else "por encima de")
                   + f" T_max = {T_MAX_ULF_S} s: el canal queda con peso {tor['peso_canal']:.2f}"
                   + ("." if tor["t_tx_s"] <= T_MAX_ULF_S
                      else " y no autoriza la ROJA por sí solo salvo consenso fuerte."))
    parte_r = (f"Con rechazo de {est['rej_db']:.0f} dB el SNR diurno es {est['snr_dB']:.1f} dB ("
               + (f"faltan {-margen:.1f} dB para {SNR_OBJETIVO_DB:.0f}" if not cierra
                  else f"margen de {margen:.1f} dB sobre {SNR_OBJETIVO_DB:.0f}")
               + f"); con rechazo mitigado de {est['rej_mitigado_db']:.0f} dB es "
               f"{est['snr_mitigado_dB']:.1f} dB. ")
    if not tormenta_ok:
        accion2 = "Documentar que en tormenta el ULF solo respalda; mejorar rechazo o momento si se exige cobertura."
    elif not holgado:
        accion2 = f"Medir el rechazo en el banco de pruebas: el margen es menor que {MARGEN_SNR_MIN_DB:.0f} dB."
    else:
        accion2 = "Verificar el rechazo de ruido en campo."
    h.append(dict(id="F2", severidad="BAJO" if (holgado and tormenta_ok) else "MEDIO",
                  titulo=titulo2, detalle=parte_r + parte_t, accion=accion2))

    # F3 — geometría y μ
    problemas = []
    if not ge["ajuste_ok"]:
        problemas.append(f"holgura radial bobina–sonda {ge['holgura_radial_mm']:.1f} mm "
                         f"(< {ge['holgura_min_mm']:.0f} mm; Ø exterior bobina {ge['d_ext_bobina_mm']:.1f} mm, "
                         f"interior útil {ge['d_int_sonda_mm']:.0f} mm con pared de {p.espesor_pared_sonde_mm:.0f} mm [H]; "
                         f"sonda mínima Ø{ge['d_sonde_min_mm']:.0f} mm)")
    if not ge["pozo_ok"]:
        problemas.append(f"holgura sonda–pozo {ge['holgura_pozo_sonda_mm']:.1f} mm "
                         f"(< {ge['holgura_pozo_min_mm']:.0f} mm [H]; pozo mínimo Ø{ge['d_pozo_min_mm']:.0f} mm)")
    if not ge["nucleo_cabe_en_sonda"]:
        problemas.append(f"el núcleo de {p.l_core:.1f} m no cabe en la sonda de {p.l_sonde_m:.1f} m")
    if not ge["una_capa_ok"]:
        problemas.append(f"una capa admite {ge['vueltas_por_capa']} vueltas < {p.n_turns}")
    if mu["limitado"]:
        problemas.append(f"μ_eff de diseño {mu['diseno']:.0f} supera el máximo físico {mu['teorica']:.0f} del "
                         f"núcleo (L/D = {mu['l_sobre_d']:.0f}); el modelo usa {mu['utilizable']:.0f}")
    elif mu["margen_dB"] < 3.0:
        problemas.append(f"μ_eff de diseño {mu['diseno']:.0f} vs teórico {mu['teorica']:.0f} "
                         f"(margen {mu['margen_dB']:.1f} dB)")
    h.append(dict(
        id="F3", severidad="MEDIO" if problemas else "BAJO",
        titulo="Geometría de la sonda y margen de μ_eff",
        detalle=("; ".join(problemas) if problemas else "Sin observaciones geométricas")
        + f". Masa: ferrita {ge['masa_ferrita_kg']:.0f} kg, cobre {ge['masa_cobre_kg']:.0f} kg. "
          "Un núcleo de 4 m se arma con segmentos y las juntas reducen μ_eff.",
        accion="Validar en diseño mecánico y banco de pruebas con núcleo a escala."))

    # F4 — beneficios
    h.append(dict(
        id="F4", severidad="ALTO",
        titulo="El B/C descansa en el catálogo completo y en un gasto público sin base",
        detalle=(f"Se suman 5 sismos (3 ya ocurridos) como si todos ocurrieran en {p.years} años "
                 f"(φ = {p.fraccion_eventos_horizonte * 100:.0f} %) y se añaden "
                 f"USD {p.gasto_publico_por_evento_usd / 1e6:.0f} M por evento detectado sin "
                 f"reducción ni relación con la magnitud (posible doble conteo con los daños). "
                 f"B/C base {c['bc_desc']:.1f}:1; caso prudente (φ = {pr['phi'] * 100:.0f} %, sin gasto "
                 f"público) {pr['bc_desc']:.1f}:1; equilibrio con φ = {eq['phi_solo_privado'] * 100:.0f} % "
                 f"(solo daños privados)."),
        accion="Sustituir el catálogo por tasas de recurrencia por zona y fundamentar el gasto público con la CNE."))

    # F5 — detección
    h.append(dict(
        id="F5", severidad="ALTO", titulo="La eficacia de detección no está validada",
        detalle="Pd, horas de aviso y fracción reducible (H05) son heurísticas. Ningún método de "
                "precursores tiene hoy eficacia demostrada de predicción a corto plazo.",
        accion="Presentar como hipótesis a validar con red piloto y métricas de aceptación."))

    # F6 — reemplazos
    ta = c["cobertura_reemplazos"]["escenario_ti_ampliado"]
    h.append(dict(
        id="F6", severidad="MEDIO", titulo="Fondo de reemplazos parcial",
        detalle=(f"Repone {c['cobertura_reemplazos']['partidas_con_reposicion']} de "
                 f"{c['cobertura_reemplazos']['partidas_capex']} partidas. Con refresco de cómputo y "
                 f"gateway cada 7 años (H): reemplazos USD {ta['reemplazos']:,.0f}, B/C {ta['bc_desc']:.1f}:1."),
        accion="Confirmar si el OPEX ya incluye el refresco de TI."))

    # F7 — OPEX
    h.append(dict(
        id="F7", severidad="MEDIO", titulo="Rótulos del OPEX provisionales",
        detalle=(f"USD {c['opex_anual']:,.0f}/año en 7 partidas cuyos montos vienen del código v6.x "
                 "sin nombre; los rótulos se asignaron en v7.1 sin respaldo documental."),
        accion="Confirmar cada partida contra el presupuesto real antes de entregarlo a Hacienda/MIDEPLAN."))

    # F8 — constantes presentadas como resultados
    h.append(dict(
        id="F8", severidad="MEDIO", titulo="Latencia y falsas alarmas son constantes",
        detalle="5.7 s / 7.3 s y 0.05 FA/año se presentaban como resultados; son supuestos (H14).",
        accion="Sustituir por presupuesto de latencia medido y tasa de FA de la red piloto."))

    # F9 — CAPEX y plazos no recalculados para la geometría
    base_core = GEOM_BASE_CAPEX["d_core"]
    masa_base = p.rho_fer * math.pi * (base_core / 2) ** 2 * p.l_core
    razon_masa = ge["masa_ferrita_kg"] / masa_base
    scap = r["sensibilidad"]["capex_bc_desc"]
    cambia = p.d_hole_mm > GEOM_BASE_CAPEX["d_hole_mm"] + 1e-9 or p.d_core > base_core + 1e-9
    bc_peor = min(scap.values())
    if cambia:
        det9 = (f"El CAPEX (USD {c['capex']:,.0f}), el ROP de {p.rop_m_dia:.0f} m/día y los días de "
                f"completación provienen de la geometría v6.x (pozo Ø{GEOM_BASE_CAPEX['d_hole_mm']:.0f} mm, "
                f"núcleo Ø{base_core * 1000:.0f} mm, {masa_base:.0f} kg de ferrita). El diseño vigente usa "
                f"pozo Ø{p.d_hole_mm:.0f} mm y núcleo Ø{p.d_core * 1000:.0f} mm ({ge['masa_ferrita_kg']:.0f} kg, "
                f"×{razon_masa:.1f} por nodo; {ge['masa_ferrita_kg'] * p.n_nodos / 1000:.1f} t en la red) sin "
                f"recalcular costos. B/C descontado con CAPEX +15 %/+30 %/+50 %: "
                f"{scap['capex115']:.1f} / {scap['capex130']:.1f} / {scap['capex150']:.1f}.")
    else:
        det9 = "La geometría vigente coincide con la que sustenta el CAPEX y el ROP."
    h.append(dict(
        id="F9", severidad=("ALTO" if bc_peor < 1 else "MEDIO") if cambia else "BAJO",
        titulo="CAPEX y plazos no recalculados para la geometría vigente",
        detalle=det9,
        accion="Cotizar perforación, entubado, ferrita y sonda para la geometría vigente y actualizar CAPEX y ROP."))

    # F10-F12 — márgenes de tiempo
    mt = r["margenes_tiempo"]
    pr_t, ss_ = mt["presupuesto"], mt["sismicidad"]
    peor = pr_t["filas"][-1]
    aviso_min = min(a["aviso_h"] for a in pr_t["aviso"])
    h.append(dict(
        id="F10", severidad="BAJO" if pr_t["lat_ulf_consistente"] else "MEDIO",
        titulo=("La latencia del canal ULF es coherente con 30 s por bit" if pr_t["lat_ulf_consistente"]
                else "La latencia ULF de 7.3 s es incompatible con 30 s por bit"),
        detalle=(f"Un bit tarda {p.t_bit:.0f} s; con la decisión ({CFG_ARBOL.lat_bayes_s} s) y el Cell Broadcast "
                 f"({LAT_CB_S:.0f} s) la latencia mínima por ULF es {pr_t['lat_ulf_min_s']:.1f} s "
                 f"({pr_t['lat_ulf_peor_s']:.1f} s en tormenta), frente a {pr_t['lat_ulf_supuesta_s']:.1f} s supuestos. "
                 f"La del cable ({pr_t['lat_cable_s']:.1f} s) no cambia. Frente al aviso mínimo de {aviso_min:.0f} h "
                 f"el peor caso consume {100 * pr_t['lat_ulf_peor_s'] / 3600 / aviso_min:.1f} %."),
        accion="Sustituir la constante por el presupuesto calculado; el objetivo de 5–10 s aplica solo al cable."))
    cabe = peor["ok_mensaje"]
    h.append(dict(
        id="F11", severidad="BAJO" if pr_t["frac_tiempo_mensaje_no_cabe"] == 0 else "MEDIO",
        titulo=("El mensaje completo de 3 bits cabe en T_max en todas las condiciones" if cabe
                else "En tormenta el mensaje completo de 3 bits no cabe en T_max; el primer bit sí" if peor["ok_primer_bit"]
                else "En tormenta ni siquiera el primer bit cabe en T_max"),
        detalle=(f"En tormenta el mensaje completo tarda {peor['t_mensaje_s']:.0f} s frente a T_max = {T_MAX_ULF_S} s "
                 f"(margen {peor['margen_mensaje_s']:+.0f} s). El primer bit, que basta para reconocer 111 porque 001 y 010 "
                 f"empiezan en 0, tarda {peor['t_primer_bit_s']:.0f} s (margen {peor['margen_primer_bit_s']:+.0f} s). "
                 f"El mensaje completo no cabe durante el {100 * pr_t['frac_tiempo_mensaje_no_cabe']:.1f} % del tiempo [H]."),
        accion="Documentar que en tormenta el ULF confirma 111 y retrasa 001 y 010; definir prioridad y preempción de mensajes."))
    h.append(dict(
        id="F12", severidad="MEDIO",
        titulo="La tasa de falsas alarmas de fondo depende de la cola de la razón de verosimilitud",
        detalle=(f"Con la sismicidad de fondo de OVSICORI ({ss_['eventos_dia_esperado']:.0f} sismos por día) pasan las compuertas "
                 f"de sensores y nodos {ss_['pasan_compuertas_anio']:.2f} eventos por año. Con σ_LR = {ss_['sigma_lr']:.1f} se "
                 f"obtienen {ss_['roja_anio']:.3f} ROJA por año (IC95 % hasta {ss_['roja_ic95_anio'][1]:.2f}). La meta de "
                 f"{FA_ANUAL:.2f} por año se cumple mientras σ_LR ≤ "
                 f"{'sin límite' if math.isinf(ss_['sigma_critico']) else format(ss_['sigma_critico'], '.2f')}: "
                 f"el posterior no debe asignar una razón de verosimilitud ≥ 10^{xi_umbral(1.0):.1f} a eventos ordinarios."),
        accion="Calibrar el procesador bayesiano con el catálogo de OVSICORI y fijar esa cola como criterio de aceptación."))

    # F13-F14 — réplicas y sensibilidades del estrés
    rp = mt["replicas"]
    tor = rp["colas"][-1]
    nor = rp["colas"][0]
    se = r["sensibilidad_estres"]
    rompe = tor["p_espera_mayor_tmax"] > 0.5
    h.append(dict(
        id="F13", severidad="MEDIO" if rompe else "BAJO",
        titulo=("Con el cable cortado y tormenta severa el canal ULF no da abasto con las réplicas" if rompe
                else "El canal ULF absorbe las réplicas con el cable cortado"),
        detalle=(f"Tras un Mw {rp['m_main']:.1f} se esperan unas {rp['sismos_24h']:.0f} réplicas en 24 h dentro de {rp['radio_km']:.0f} km "
                 f"y {rp['mensajes_24h']:.0f} mensajes naranja o más del nodo de {rp['nodo']}. En condición normal (servicio de {nor['servicio_s']:.0f} s) "
                 f"la espera máxima media es de {nor['espera_max_media_s']:.0f} s y tras la última réplica la cola tarda {nor['drenaje_medio_s']:.0f} s en vaciarse. "
                 f"En tormenta (servicio de {tor['servicio_s']:.0f} s) {100 * tor['p_espera_mayor_tmax']:.0f} % de los mensajes espera más que T_max, "
                 f"la espera máxima media es de {tor['espera_max_media_s'] / 3600:.1f} h, la cola tarda {tor['drenaje_medio_s'] / 3600:.1f} h en vaciarse y todavía hay mensajes sin atender a las 24 h en {100 * tor['cola_no_vacia_24h']:.0f} % de las secuencias."
                 f" Con prioridad para 111 y preempción en el límite de cada repetición, la latencia de la alerta roja sería de {tor['latencia_111_con_preempcion_s']:.0f} s."),
        accion="En tormenta, transmitir por ULF solo 111 y suprimir 001 y 010; definir prioridad con preempción por repetición."))
    h.append(dict(
        id="F14", severidad="MEDIO",
        titulo=f"El estrés solo cierra si el rechazo real de ruido es de al menos {se['rechazo_minimo_db']:.2f} dB",
        detalle=(f"El SNR es lineal en el rechazo: para 20 dB hace falta {se['rechazo_minimo_db']:.2f} dB y para {MARGEN_SNR_MIN_DB:.0f} dB de margen "
                 f"{se['rechazo_minimo_con_margen_db']:.2f} dB (nominal {se['rechazo_nominal_db']:.0f} dB). El coeficiente térmico de la conductividad mueve la peor litología "
                 f"de {se['alphas'][0]['snr_peor_lito_dB']:.2f} dB (sin efecto térmico) a {se['alphas'][-1]['snr_peor_lito_dB']:.2f} dB (5 % por °C): menos de "
                 f"{abs(se['alphas'][0]['snr_peor_lito_dB'] - se['alphas'][-1]['snr_peor_lito_dB']):.1f} dB, menor que el margen del rechazo."),
        accion="Medir el rechazo de ruido en campo; la conductividad importa menos que el rechazo."))
    return h


# ══════════════════════════════════════════════════════════════════════════
#  8. SALIDA
# ══════════════════════════════════════════════════════════════════════════
def guardar_json(res: dict, ruta: Path) -> Path:
    """Escritura atómica; los errores se propagan."""
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=ruta.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2, ensure_ascii=False, default=_json_default)
        os.replace(tmp, ruta)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return ruta


def _json_default(o):
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, IntEnum):
        return int(o)
    raise TypeError(f"No serializable: {type(o)}")


def _est(snr: float) -> str:
    return "✓" if snr >= 20 else ("⚠" if snr >= 10 else "⛔")


def imprimir_margenes(res: dict) -> None:
    R = "─" * ANCHO
    mt = res["margenes_tiempo"]
    pr, ss_ = mt["presupuesto"], mt["sismicidad"]
    print(f"\n{R}\n[J] MÁRGENES DE TIEMPO Y SISMICIDAD DE FONDO\n")
    print(f"  [J1] Presupuesto de tiempo del enlace ULF · T_max = {pr['t_max_s']} s · mensaje de {pr['n_bits_mensaje']} bits\n")
    print(f"    {'Condición':<10} {'Tiempo %':>8} {'Rep.':>5} {'1er bit':>8} {'Mensaje':>8} {'Margen msg':>11} {'Lat. 1er bit':>13}")
    for f in pr["filas"]:
        print(f"    {f['nombre']:<10} {100 * f['p_tiempo']:>7.1f}% {f['nbit']:>5d} {f['t_primer_bit_s']:>7.0f}s "
              f"{f['t_mensaje_s']:>7.0f}s {f['margen_mensaje_s']:>+10.0f}s {f['lat_ulf_primer_bit_s']:>12.1f}s "
              f"{'✓' if f['ok_mensaje'] else '✗ no cabe'}")
    print(f"    Latencia cable {pr['lat_cable_s']:.1f} s · ULF mínima {pr['lat_ulf_min_s']:.1f} s · ULF peor {pr['lat_ulf_peor_s']:.1f} s "
          f"· ULF supuesta {pr['lat_ulf_supuesta_s']:.1f} s ({'coherente' if pr['lat_ulf_consistente'] else 'INCOHERENTE'})")
    print(f"    El mensaje completo no cabe durante {100 * pr['frac_tiempo_mensaje_no_cabe']:.1f} % del tiempo [H]; "
          f"el primer bit no cabe durante {100 * pr['frac_tiempo_primer_bit_no_cabe']:.1f} %")
    print("    Margen frente a las horas de aviso (latencia ULF del peor caso):")
    print("    " + " · ".join(f"Mw {a['mw']:.1f}: {a['aviso_h']} h → margen {a['margen_h']:.2f} h ({100 * a['fraccion_consumida']:.1f} %)"
                              for a in pr["aviso"]))
    print(f"\n  [J2] Sismicidad de fondo diaria · {ss_['n_dias']:,} días ({ss_['anios']:.0f} años) · {ss_['eventos']:,} sismos")
    print(f"    Fuente: {ss_['fuente']}")
    print(f"    Gutenberg-Richter b = {ss_['b']:.1f}, Mc = {ss_['mc']:.2f} (derivada del catálogo) · "
          f"un sismo cada {ss_['espaciado_medio_min']:.0f} min en promedio")
    pd_ = ss_["por_dia"]
    print(f"    Sismos por día: media {pd_['media']:.1f} · P50 {pd_['p50']:.0f} · P95 {pd_['p95']:.0f} · P99 {pd_['p99']:.0f} · máximo {pd_['maximo']}")
    print(f"    {'Fase alcanzada':<12} {'Por día':>9} {'%':>7}")
    for k, x in ss_["fases"].items():
        print(f"    {k:<12} {x['por_dia']:>9.3f} {x['porcentaje']:>6.2f}%")
    print(f"    Detectados por algún nodo: {ss_['detectados_por_dia']:.2f} por día · mensajes ≥ naranja: {ss_['mensajes_por_dia']:.2f} por día · "
          f"pasan compuertas de sensores y nodos: {ss_['pasan_compuertas_anio']:.1f} por año")
    so = ss_["solapamiento"]
    print(f"    Solapamiento de ventanas de {so['ventana_s']:.0f} s: {100 * so['simulado']:.2f} % de los sismos "
          f"(analítico {100 * so['analitico']:.2f} %); entre los detectados {100 * so['simulado_detectados']:.3f} % "
          f"(analítico {100 * so['analitico_detectados']:.3f} %)")
    print("    Cola del canal ULF si el cable estuviera caído (un servidor por nodo, FIFO):")
    print(f"    {'Condición':<10} {'Servicio':>9} {'Mensajes':>9} {'ρ':>8} {'Espera media':>13} {'Espera máx.':>12} {'P(espera>T_max)':>16}")
    for c in ss_["cola_ulf"]:
        print(f"    {c['nombre']:<10} {c['servicio_s']:>8.0f}s {c['mensajes']:>9,} {c['rho']:>8.4f} {c['espera_media_s']:>12.1f}s "
              f"{c['espera_max_s']:>11.0f}s {100 * c['p_espera_mayor_tmax']:>15.2f}%")
    print(f"    ROJA de fondo con σ_LR = {ss_['sigma_lr']:.1f}: {ss_['roja_anio']:.3f} por año (IC95 % {ss_['roja_ic95_anio'][0]:.2f}–{ss_['roja_ic95_anio'][1]:.2f}); "
          f"meta {FA_ANUAL:.2f} por año")
    print(f"    {'σ_LR':>6} {'ROJA/año (simulada)':>20} {'IC95 %':>16} {'Analítica':>10}")
    for x in ss_["sensibilidad_sigma"]:
        marca = "  ← excede la meta" if x["roja_anio"] > FA_ANUAL else ""
        print(f"    {x['sigma']:>6.1f} {x['roja_anio']:>20.3f} {x['ic_lo']:>7.2f}–{x['ic_hi']:<7.2f} {x['analitico_anio']:>10.3f}{marca}")
    sc = ss_["sigma_critico"]
    print(f"    σ_LR crítico para cumplir {FA_ANUAL:.2f} por año: {'sin límite' if math.isinf(sc) else format(sc, '.2f')} "
          f"(razón de verosimilitud ≥ 10^{xi_umbral(1.0):.2f} a menos de {phi_cola_normal(xi_umbral(sc)) if not math.isinf(sc) else 0:.1e} de los eventos)")
    print(f"    Con la tasa de 2025 ({ss_['sensibilidad_sismicidad']['tasa_2025_por_dia']:.1f} por día) las cargas suben "
          f"{100 * (ss_['sensibilidad_sismicidad']['factor'] - 1):.0f} %")


def imprimir(res: dict, p: Params) -> None:
    L, R = "═" * ANCHO, "─" * ANCHO
    e = res["enlace_principal"]
    c, d, v = res["costos"], res["despliegue"], res["verificaciones"]
    sa, mg, ge, mu = v["saturacion"], v["a_objetivo"], v["geometria"], v["mu"]
    print(L)
    print(f" GEO-PROBE CR — v{VERSION}")
    print(f" {INVENTOR} · semilla {res['semilla']} · KPI principal: {e['modo']}")
    print(L)

    print("\n[A] DESPLIEGUE — PERFORACIÓN CONVENCIONAL\n")
    print(f"  Pozo Ø{p.d_hole_mm:.0f} mm × {p.depth_m:.0f} m · Sonde Ø{p.d_sonde_mm:.0f} mm × {p.l_sonde_m} m")
    print(f"  ROP {p.rop_m_dia:.0f} m/día · {d['dias_nodo']:.1f} d/nodo · {p.n_nodos} nodos con "
          f"{p.n_equipos} equipos: {d['meses_red']:.1f} meses · Reactor ELIMINADO")

    print(f"\n{R}\n[B] ENLACE ULF — μ diseño={p.mu_eff_design:.0f} (utilizable {mu['utilizable']:.0f}) · I={p.i_a:.1f} A · núcleo Ø{p.d_core * 1000:.0f} mm\n")
    print(f"  μ_th={e['mu_teorica']:.0f} · Nd={e['nd']:.5f} · masa ferrita={ge['masa_ferrita_kg']:.0f} kg · "
          f"m={e['m_ref']:.3e} A·m² · B={e['b_ref_pT']:.1f} pT")
    print(f"  Margen de fábrica: {e['margen_fabrica_dB']:.1f} dB · Potencia media: {e['potencia_media_W']:.1f} W")

    print(f"\n  [B1] SNR vs Pc1 (rechazo {p.rej_db:.0f} dB)")
    for cond, pc1 in PC1_RUIDO.items():
        s_ = e["snr_por_pc1"][cond]
        print(f"    {cond:<26} {pc1:>6.0f} pT  SNR={s_:5.1f} dB {_est(s_)}")

    print("\n  [B2] Protocolo Kp adaptativo")
    for k in e["kp"]:
        print(f"    Kp {k['kp']:<4} {k['nombre']:<10} bits={k['bits']:>2}  "
              f"T_tx={k['t_tx_s']:>5.0f}s  SNReff={k['snr_eff_dB']:5.1f} dB")

    t = e["tormenta"]
    print(f"\n  [B3] Correcciones de canal · T_max ULF={T_MAX_ULF_S / 60:.0f} min")
    print(f"    Tormenta: nbit={t['nbit']} T_tx={t['t_tx_s']:.0f}s · "
          f"mayoría 2-de-3 {'✓' if t['majority_ok'] else '✗ (excede T_max)'} · "
          f"resuelve a peso_canal={t['peso_canal']:.2f}")
    print(f"    Pesos de referencia: cable={PESO_CABLE:.2f} | ULF a tiempo={PESO_ULF_OK:.2f} | "
          f"ULF degradado={PESO_ULF_DEGRADADO:.2f} | rechazo degradado={PESO_ULF_RECHAZO_DEGRADADO:.2f}")

    es = e["estres"]
    print("\n  [B4] Estrés")
    print(f"    Rechazo {p.rej_db:.0f}→{es['rej_db']:.0f} dB: SNR diurno={es['snr_dB']:.1f} dB {_est(es['snr_dB'])} · "
          f"peso_canal={es['peso_canal']:.2f} → ROJA bloqueada")
    print(f"    Gradiente {es['grad']:.0f}°C/km: T_fondo={es['t_fondo']:.0f}°C · μ_T={es['mu_T']:.0f} · "
          f"SNR={es['snr_geo_dB']:.1f} dB {_est(es['snr_geo_dB'])}")

    print("\n  [B5] Litologías (Pc1 típico)")
    for x in e["litologias"]:
        print(f"    {x['nombre']:<22} σ25={x['sigma_25']:.1e} σef={x['sigma']:.1e}  atenuación={x['atenuacion_dB']:.2f} dB  SNR={x['snr_dB']:5.1f} dB")
    print(f"\n  [B6] T@{p.depth_m:.0f}m={e['t_pozo']:.0f}°C · μ_T={e['mu_T']:.0f} · SNR@T={e['snr_Tpozo_dB']:.1f} dB")

    print(f"\n  [B7] P(cizalla) k={SHEAR_K} M0={SHEAR_M0}")
    for mw, ps in e["shear"]["por_mw"].items():
        modo = "cable OK" if ps < 0.15 else ("mixto" if ps <= 0.35 else "ULF probable")
        print(f"    Mw {mw:.1f}  P={ps * 100:5.1f}%  {modo}")
    print(f"  → P(ULF necesario): {e['shear']['p_ulf_necesario'] * 100:.0f}%")

    print("\n  [B8] Perfil térmico (SCADA)")
    print(f"  {'Grad °C/km':>12} {'T_fondo':>9} {'μ_T':>7} {'SNR dB':>8}  perfil (20–45 dB)")
    for x in e["termico"]:
        n = max(0, min(30, int((x["snr_dB"] - 20) / 25 * 30)))
        print(f"  {x['grad']:>12} {x['t_fondo']:>9.1f} {x['mu_T']:>7.1f} {x['snr_dB']:>8.1f}  "
              f"{'█' * n}{'░' * (30 - n)}")

    print("\n  [B9] VERIFICACIONES DE DISEÑO\n")
    print(f"    Saturación: B núcleo={sa['b_nucleo_T']:.3f} T · B_sat={sa['b_sat_T']:.2f} T · "
          f"utilización {sa['utilizacion'] * 100:.1f} % (objetivo ≤ {sa['objetivo'] * 100:.0f} %) · "
          f"{'EXCEDE' if sa['excede'] else ('SIN MARGEN' if sa['sin_margen'] else 'con margen')}")
    print(f"    I_sat={sa['corriente_saturacion_A']:.2f} A · I con margen={sa['i_con_margen_A']:.2f} A · "
          f"pérdida por saturación={sa['perdida_dB']:.1f} dB")
    print(f"    {'Indicador':<30} {'Diseño':>9} {'A util. obj.':>12}   (I = {p.i_a:.1f} A vs {mg['i_a']:.1f} A)")
    for et, a_, b_ in (("SNR típico (dB)", e["snr_tipico_dB"], mg["snr_tipico_dB"]),
                       ("SNR rechazo 10 dB (dB)", e["estres"]["snr_dB"], mg["snr_estres_dB"]),
                       ("Potencia media (W)", e["potencia_media_W"], mg["potencia_W"])):
        print(f"    {et:<30} {a_:>9.1f} {b_:>12.1f}")
    rep_m = f"{mg['tormenta_bits']}" if mg["tormenta_alcanzado"] else f">{MAX_BITS} (no alcanza)"
    print(f"    {'Repeticiones en tormenta':<30} {t['nbit']:>9d} {rep_m:>12}")
    print("    Sensibilidad a B_sat: " + " · ".join(
        f"{k} T → util {x['utilizacion'] * 100:.0f} %, pérdida {x['perdida_dB']:.1f} dB, "
        f"SNR {x['snr_tipico_dB']:.1f}" for k, x in sa["barrido_bsat"].items()))
    print(f"    Geometría: Ø exterior bobina {ge['d_ext_bobina_mm']:.1f} mm vs interior útil "
          f"{ge['d_int_sonda_mm']:.0f} mm → holgura radial {ge['holgura_radial_mm']:.1f} mm "
          f"({'OK' if ge['ajuste_ok'] else 'AJUSTADA, mínimo ' + format(ge['holgura_min_mm'], '.0f') + ' mm'})")
    print(f"    Devanado: hilo Ø{ge['d_hilo_mm']:.2f} mm · {ge['vueltas_por_capa']} vueltas/capa "
          f"({'una capa alcanza' if ge['una_capa_ok'] else 'requiere varias capas'}) · cobre {ge['masa_cobre_kg']:.0f} kg")
    print(f"    Holgura sonda–pozo: {ge['holgura_pozo_sonda_mm']:.1f} mm (mínimo {ge['holgura_pozo_min_mm']:.0f} mm "
          f"[H]) · pozo mínimo Ø{ge['d_pozo_min_mm']:.0f} mm · "
          f"{'OK' if ge['pozo_ok'] else 'AJUSTADO'}")
    print(f"    μ_eff: teórico {mu['teorica']:.0f} vs diseño {mu['diseno']:.0f} → margen {mu['margen_dB']:.1f} dB · "
          f"utilizable {mu['utilizable']:.0f}{' (limitado por la geometría)' if mu['limitado'] else ''}")

    cmpd = res["comparacion_disenos"]
    print("\n  [B10] COMPARACIÓN DE DISEÑOS (misma física, distinto punto)\n")
    columnas = [("v75_como_se_recibio", "v7.5 recibida"), ("v75_con_mu_fisico", "v7.5, μ físico"),
                ("vigente", "Vigente")]
    if cmpd.get("alternativa_nucleo_200"):
        columnas.append(("alternativa_nucleo_200", "Alt. núcleo Ø200"))
    print(f"    {'':<26}" + "".join(f"{nombre:>17}" for _, nombre in columnas))
    for et, k, fmt in (("I (A)", "i_a", "{:.1f}"), ("μ_eff utilizable", "mu_utilizable", "{:.0f}"),
                       ("Utilización B_sat (%)", "utilizacion", "{:.0f}"), ("SNR típico (dB)", "snr_tipico_dB", "{:.1f}"),
                       ("SNR estrés 10 dB (dB)", "snr_estres_dB", "{:.1f}"),
                       ("Repeticiones tormenta", "tormenta_bits", "{:.0f}"), ("Holgura bobina (mm)", "holgura_bobina_mm", "{:.1f}"),
                       ("Holgura sonda–pozo (mm)", "holgura_pozo_mm", "{:.1f}"), ("Pozo mínimo Ø (mm)", "d_pozo_min_mm", "{:.0f}"),
                       ("Masa de ferrita (kg)", "masa_ferrita_kg", "{:.0f}"), ("Potencia media (W)", "potencia_W", "{:.1f}")):
        vals = [fmt.format(cmpd[col][k] * (100 if k == "utilizacion" else 1)) for col, _ in columnas]
        print(f"    {et:<26}" + "".join(f"{x:>17}" for x in vals))

    print(f"\n{R}\n[C] ÁRBOL DE DECISIÓN (fases 1-4; ROJA = código 111)\n")
    for x in res["arbol"]:
        ic = "🔴" if x["codigo"] == "111" else ("🟠" if x["codigo"] == "010" else "🟡")
        print(f"  {x['nombre']:<24} M{x['mw']:.1f}  {x['fase_nombre']:<9} {x['codigo']} {ic} {x['texto']}")
    print("\n  [C2] Gate de canal — mismo evento, distinto canal\n")
    for x in res["gate_canal"]:
        print(f"    peso={x['peso']:.2f}  {x['etiqueta']:<52} → {x['codigo']}  {x['texto']}")

    dt = res["deteccion"]
    print(f"\n{R}\n[D] DETECCIÓN Y DAÑOS EVITADOS (supuestos H05/H06, no validados)\n")
    print(f"  {'Escenario':<14} {'Tipo':<11} {'Mw':>4} {'Pd':>5} {'Aviso':>6} {'Ahorro esp.':>12}")
    for f in dt["por_escenario"]:
        yr = f["anio"] if f["anio"] else "—"
        print(f"  {f['nombre'] + ' ' + str(yr):<14} {f['tipo']:<11} {f['mw']:>4.1f} {f['pd']:>5.2f} "
              f"{f['aviso_h']:>5}h ${f['ahorro_esperado_musd']:>9.1f}M")
    m = dt["mc"]
    print(f"  Analítico: ${dt['ahorro_esperado_musd']:.1f}M · MC({m['n']:,}): ${m['ahorro_medio_musd']:.1f}M "
          f"± {m['ahorro_se_musd']:.2f} (P5–P95: {m['ahorro_p5_musd']:.0f}–{m['ahorro_p95_musd']:.0f}) · "
          f"FN medio {m['fn_medio']:.2f}/{m['n_eventos']}")

    print(f"\n{R}\n[E] COSTOS\n")
    print(f"  CAPEX ${c['capex']:,} (subtotal ${c['capex_subtotal']:,} + contingencia "
          f"{p.contingencia_pct * 100:.0f}% ${c['contingencia']:,})")
    print(f"  OPEX/año ${c['opex_anual']:,} · OPEX 30a ${c['opex_30']:,.0f}")
    print(f"  Reemplazos derivados [V]: ${c['reemplazos']:,.0f} "
          f"({c['cobertura_reemplazos']['partidas_con_reposicion']}/{c['cobertura_reemplazos']['partidas_capex']} partidas)")
    print(f"  Total 30a ${c['total_30']:,.0f}")

    pr, eq = c["caso_prudente"], c["equilibrio"]
    print(f"\n[F] VALORACIÓN MATERIAL (r={p.r_disc * 100:.0f}%, {p.years} años, sin VSL)\n")
    print(f"  Beneficio privado 30a ${c['beneficio_privado_30'] / 1e6:.1f}M + público "
          f"${c['beneficio_publico_30'] / 1e6:.1f}M (${p.gasto_publico_por_evento_usd / 1e6:.0f}M/evento × ΣPd) "
          f"× φ={p.fraccion_eventos_horizonte:.2f} = ${c['benef_total_30'] / 1e6:.1f}M")
    print(f"  B/C descontado {c['bc_desc']:.2f}:1 · VAN ${c['van'] / 1e6:.1f}M · B/C simple {c['bc_simple']:.2f}:1")
    print(f"  Contraste (reposiciones en su año): VAN ${c['van_cal'] / 1e6:.1f}M · B/C {c['bc_desc_cal']:.2f}:1")
    print(f"  Caso prudente (φ={pr['phi']:.2f}, sin gasto público): B/C {pr['bc_desc']:.2f}:1 · VAN ${pr['van'] / 1e6:.1f}M")
    print(f"  Equilibrio: el costo se cubre con {eq['factor_beneficio'] * 100:.1f} % del beneficio modelado · "
          f"φ* = {eq['phi_solo_privado'] * 100:.1f} % del catálogo (solo daños privados)")
    sr = res["sensibilidad"]["tasa_descuento"]
    print("  Tasa de descuento: " + " · ".join(f"{float(k) * 100:.0f}% → VAN ${x['van'] / 1e6:.1f}M, "
                                               f"B/C {x['bc_desc']:.2f}" for k, x in sr.items()))
    print("  OPEX: " + " · ".join(f"{k} → {x:.2f}" for k, x in res["sensibilidad"]["opex_bc_desc"].items()))
    print("  CAPEX: " + " · ".join(f"{'nominal' if k == 'capex100' else '+' + str(int(k[5:]) - 100) + ' %'} → {x:.2f}" for k, x in res["sensibilidad"]["capex_bc_desc"].items()))
    print("  Gasto público/evento: " + " · ".join(f"{k} → {x:.2f}" for k, x in res["sensibilidad"]["gasto_publico_bc_desc"].items()))
    print(f"  {'φ (catálogo en 30 a)':<22}" + "".join(f"{k:>8}" for k in res["sensibilidad"]["phi_bc_desc"]))
    for etiqueta, nombre in (("con_gasto_publico", "con gasto público"), ("solo_privado", "solo privado")):
        print(f"  {'B/C ' + nombre:<22}" + "".join(
            f"{x[etiqueta]:>8.2f}" for x in res["sensibilidad"]["phi_bc_desc"].values()))

    rd = res["red"]
    print(f"\n[G] RED · disponibilidad de nodo {rd['disp_nodo'] * 100:.1f}% · P(≥3 nodos) "
          f"analítica {rd['p_min3_analitica'] * 100:.1f}% · MC {rd['p_min3_mc']['p_min_k'] * 100:.1f}% "
          f"± {rd['p_min3_mc']['se'] * 100:.2f}")
    lt = res["latencia"]
    print(f"[H] SERVICIO (supuestos) · latencia {lt['cable_s']:.1f} s cable / {lt['ulf_s']:.1f} s ULF · "
          f"FA {lt['fa_anual']:.2f}/año")

    imprimir_margenes(res)
    print(f"\n{R}\n[I] HALLAZGOS DE AUDITORÍA\n")
    for h in res["hallazgos"]:
        print(f"  [{h['id']}] {h['severidad']:<6} {h['titulo']}")
        print(f"        {h['detalle']}")
        print(f"        → {h['accion']}")

    print(f"\n{L}\n DIAGNÓSTICO — GEO-PROBE CR v{VERSION}\n")
    filas = [
        ("Pozo", f"Ø{p.d_hole_mm:.0f} mm × {p.depth_m:.0f} m · {d['dias_nodo']:.0f} d/nodo", "✓"),
        ("Enlace típico", f"{e['snr_tipico_dB']:.1f} dB · @T {e['snr_Tpozo_dB']:.1f} · peor lito {e['snr_peor_lito_dB']:.1f}",
         _est(e["snr_tipico_dB"])),
        ("Enlace estrés 10 dB", f"{es['snr_dB']:.1f} dB (umbral {SNR_OBJETIVO_DB:.0f})",
         "⛔ ABIERTO" if es["snr_dB"] < SNR_OBJETIVO_DB
         else ("⚠ MARGEN MÍNIMO" if es["snr_dB"] < SNR_OBJETIVO_DB + MARGEN_SNR_MIN_DB else "✓")),
        ("Saturación ferrita", f"utilización {sa['utilizacion'] * 100:.0f} % de B_sat",
         "⚠ SIN MARGEN" if sa["sin_margen"] else "✓"),
        ("μ_eff utilizable", f"{mu['utilizable']:.0f} (teórico {mu['teorica']:.0f}, diseño {mu['diseno']:.0f})",
         "⚠ LIMITADO" if mu["limitado"] else "✓"),
        ("Geometría sonda", f"holgura bobina {ge['holgura_radial_mm']:.1f} mm · sonda–pozo {ge['holgura_pozo_sonda_mm']:.1f} mm",
         "✓" if (ge["ajuste_ok"] and ge["pozo_ok"]) else "⚠ AJUSTADA"),
        ("P(ULF necesario)", f"{e['shear']['p_ulf_necesario'] * 100:.0f}%", "✓"),
        ("Árbol de decisión", "gate de canal activo (ROJA→pre-alerta si peso<0.5)", "✓"),
        ("CAPEX", f"${c['capex']:,}", "✓"),
        ("B/C desc. / VAN", f"{c['bc_desc']:.1f}:1 / ${c['van'] / 1e6:.0f}M (base)", "✓"),
        ("B/C prudente", f"{pr['bc_desc']:.1f}:1 (φ={pr['phi']:.1f}, sin gasto público)", "✓"),
        ("P(≥3 nodos)", f"{rd['p_min3_analitica'] * 100:.1f}%", "✓"),
        ("Supuestos [H]", f"{sum(1 for s in SUPUESTOS if s['tag'] == 'H')} registrados", "⚠ VALIDAR"),
    ]
    for a, b, c_ in filas:
        print(f"  [{a:<20}] {b:<56} {c_}")
    print(L)


# ══════════════════════════════════════════════════════════════════════════
#  9. AUTOPRUEBAS
# ══════════════════════════════════════════════════════════════════════════
def _barrido_aleatorio(n: int = 60, seed: int = 7) -> list[str]:
    """Barrido de parámetros aleatorios: sin excepciones, sin NaN e invariantes."""
    rnd = random.Random(seed)
    rangos = {"depth_m": (100, 1500), "i_a": (0.05, 30), "d_core": (0.05, 0.15),
              "r_bobina_m": (0.04, 0.09), "mu_eff_design": (1.5, 400), "n_turns": (100, 3000),
              "l_core": (1, 6), "b_sat_ferrita_t": (0.1, 0.6), "f_ulf": (0.5, 10),
              "t_bit": (5, 60), "rej_db": (0, 50), "util_bsat_objetivo": (0.1, 1.0),
              "fraccion_eventos_horizonte": (0.01, 1.0), "gasto_publico_por_evento_usd": (0, 1e8),
              "r_disc": (0.0, 0.2), "inflacion": (0, 0.1), "duty": (0.01, 1.0),
              "a_cond_mm2": (1, 30), "years": (5, 50)}
    fallos: list[str] = []
    validos = 0
    for _ in range(n):
        kw: dict[str, Any] = {}
        for k, (lo, hi) in rangos.items():
            if rnd.random() < 0.5:
                v = rnd.uniform(lo, hi)
                kw[k] = int(v) if k in ("n_turns", "years") else v
        try:
            p = Params(**kw)
        except ValueError:
            continue
        validos += 1
        try:
            r = simular(p, n_mc=500, n_dias=DIAS_PRUEBA, n_rep=5)
            lin, sat = r["enlace_lineal"], r["enlace_saturado"]
            c = r["costos"]
            if not _sin_no_finitos(r):
                fallos.append(f"valor no finito: {kw}")
            if sat["m_ref"] > lin["m_ref"] * (1 + 1e-9):
                fallos.append(f"m saturado > lineal: {kw}")
            if sat["snr_tipico_dB"] > lin["snr_tipico_dB"] + 1e-9:
                fallos.append(f"SNR saturado > lineal: {kw}")
            if r["verificaciones"]["saturacion"]["perdida_dB"] < 0:
                fallos.append(f"pérdida negativa: {kw}")
            if r["verificaciones"]["con_margen"]["i_a"] > p.i_a + 1e-12:
                fallos.append(f"corriente con margen > diseño: {kw}")
            if (c["van"] > 0) != (c["bc_desc"] > 1):
                fallos.append(f"VAN y B/C incoherentes: {kw}")
            if abs(c["equilibrio"]["factor_beneficio"] * c["bc_desc"] - 1) > 1e-9:
                fallos.append(f"factor de equilibrio incoherente: {kw}")
            with contextlib.redirect_stdout(io.StringIO()):
                imprimir(r, p)
        except Exception as exc:  # noqa: BLE001 — el barrido debe reportar cualquier fallo
            fallos.append(f"{type(exc).__name__}: {exc} · {kw}")
    if validos < n // 3:
        fallos.append(f"solo {validos}/{n} casos válidos")
    return fallos


def _lanza(f) -> bool:
    try:
        f()
    except ValueError:
        return True
    return False


def selftest() -> int:
    fallos: list[str] = []

    def check(nombre: str, cond: bool, detalle: str = "") -> None:
        print(f"  {'✓' if cond else '✗'} {nombre}{(' — ' + detalle) if detalle else ''}")
        if not cond:
            fallos.append(nombre)

    def cerca(a: float, b: float, tol: float) -> bool:
        return abs(a - b) <= tol

    print("AUTOPRUEBAS GEO-PROBE CR v" + VERSION)
    r = simular()
    e, c, v = r["enlace_principal"], r["costos"], r["verificaciones"]
    v6 = calcular_enlace(PARAMS_V6, False)

    print("\n Regresión v6.3/v6.4 (PARAMS_V6: I=20 A, Ø0.10 m, m = μ·N·I·π·r²)")
    check("SNR típico 43.0 dB", cerca(v6["snr_tipico_dB"], 43.0, 0.05), f"{v6['snr_tipico_dB']:.2f}")
    check("SNR @T 42.3 dB", cerca(v6["snr_Tpozo_dB"], 42.3, 0.05), f"{v6['snr_Tpozo_dB']:.2f}")
    check("SNR peor litología 41.1 dB", cerca(v6["snr_peor_lito_dB"], 41.1, 0.05))
    check("Estrés rechazo 10 dB = 23.0 dB", cerca(v6["estres"]["snr_dB"], 23.0, 0.05))
    check("Geotermia 55 °C/km = 41.8 dB (el PDF v6.3 dice 41.7)", cerca(v6["estres"]["snr_geo_dB"], 41.8, 0.05))
    check("Tormenta v6: nbit=13, peso 0.70, mayoría ✗",
          v6["tormenta"]["nbit"] == 13 and v6["tormenta"]["peso_canal"] == 0.70
          and not v6["tormenta"]["majority_ok"])
    check("Potencia media v6 ≈ 39 W", cerca(v6["potencia_media_W"], 39.5, 0.6), f"{v6['potencia_media_W']:.1f}")
    check("P(ULF necesario) ≈ 36 %", round(e["shear"]["p_ulf_necesario"] * 100) == 36)
    check("CAPEX = 3 587 200", c["capex"] == 3_587_200, f"{c['capex']:,}")
    check("Reemplazos = 3 090 000", round(c["reemplazos"]) == 3_090_000)
    check("OPEX anual = 398 000", c["opex_anual"] == 398_000)

    print("\n Cifras de referencia v7.6 (I = 6.5 A, núcleo Ø185 mm, pozo Ø240 mm)")
    check("SNR típico 40.083 dB", cerca(e["snr_tipico_dB"], 40.083, 0.003), f"{e['snr_tipico_dB']:.3f}")
    check("SNR estrés 10 dB = 20.083 dB", cerca(e["estres"]["snr_dB"], 20.083, 0.003), f"{e['estres']['snr_dB']:.3f}")
    check("SNR estrés mitigado 15 dB = 25.083 dB", cerca(e["estres"]["snr_mitigado_dB"], 25.083, 0.003))
    check("Tormenta: 25 repeticiones, 750 s, peso 0.70",
          e["tormenta"]["nbit"] == 25 and e["tormenta"]["t_tx_s"] == 750 and e["tormenta"]["peso_canal"] == 0.70)
    check("μ teórico = 155.9 y μ utilizable = teórico", cerca(e["mu_teorica"], 155.87, 0.05)
          and cerca(e["mu_utilizable"], e["mu_teorica"], 1e-9) and v["mu"]["limitado"])
    check("Potencia media ≈ 7.3 W", cerca(e["potencia_media_W"], 7.32, 0.05))
    check("SNR a temperatura de pozo 39.434 dB, geotermia 55 °C/km 38.844 dB, peor litología 38.010 dB",
          cerca(e["snr_Tpozo_dB"], 39.4345, 0.003) and cerca(e["estres"]["snr_geo_dB"], 38.8439, 0.003)
          and cerca(e["snr_peor_lito_dB"], 38.0098, 0.003))
    lito_ = e["litologias"]
    check("Coherencia de σ(T): «Basalto húmedo CR» da el mismo SNR que el caso típico",
          cerca(lito_[1]["snr_dB"], e["snr_tipico_dB"], 1e-9) and lito_[1]["nombre"].startswith("Basalto húmedo"))
    check("Atenuación por litología: arcilla ácida 2.25 dB (máximo) y basalto seco 0.11 dB",
          cerca(lito_[-1]["atenuacion_dB"], 2.247, 0.005) and cerca(e["atenuacion_max_dB"], lito_[-1]["atenuacion_dB"], 1e-12)
          and cerca(lito_[0]["atenuacion_dB"], 0.112, 0.002))
    e_fija = calcular_enlace(replace(P0, sigma_termico=False), True)
    check("sigma_termico=no reproduce la v7.7 (40.097 / 39.448 / 38.868 / 38.186 dB; 2.07 dB)",
          cerca(e_fija["snr_tipico_dB"], 40.0969, 0.001) and cerca(e_fija["snr_Tpozo_dB"], 39.4482, 0.001)
          and cerca(e_fija["estres"]["snr_geo_dB"], 38.868, 0.001) and cerca(e_fija["snr_peor_lito_dB"], 38.1863, 0.001)
          and cerca(e_fija["atenuacion_max_dB"], 2.071, 0.002))
    check("Con σ(T) la geotermia extrema pierde más SNR que con σ fija",
          e["estres"]["snr_geo_dB"] < e_fija["estres"]["snr_geo_dB"] and e["snr_peor_lito_dB"] < e_fija["snr_peor_lito_dB"])
    sig_num = sum(sigma_at_T(0.02, P0.t_surf + 30.0 * (z + 0.5) / 20000 * P0.depth_m / 1000, P0.alpha_sigma) ** 0.5
                  for z in range(20000)) / 20000
    check("σ efectiva: la forma cerrada coincide con la integración numérica (1e-6)",
          cerca(sigma_trayecto(0.02, 30.0, P0) ** 0.5, sig_num, 1e-6 * sig_num))
    check("σ efectiva: sin gradiente, sin α o con la bandera apagada devuelve σ a 25 °C; crece con el gradiente",
          cerca(sigma_trayecto(0.02, 0.0, P0), 0.02, 1e-15)
          and cerca(sigma_trayecto(0.02, 30.0, replace(P0, alpha_sigma=0.0)), 0.02, 1e-15)
          and sigma_trayecto(0.02, 30.0, replace(P0, sigma_termico=False)) == 0.02
          and sigma_trayecto(0.02, 20.0, P0) < sigma_trayecto(0.02, 30.0, P0) < sigma_trayecto(0.02, 55.0, P0))
    check("Tabla térmica: la fila de 30 °C/km = SNR a temperatura de pozo y la de 55 °C/km = geotermia extrema",
          cerca(next(x for x in e["termico"] if x["grad"] == 30)["snr_dB"], e["snr_Tpozo_dB"], 1e-9)
          and cerca(next(x for x in e["termico"] if x["grad"] == 55)["snr_dB"], e["estres"]["snr_geo_dB"], 1e-9)
          and cerca(e["termico"][0]["snr_dB"], 39.6606, 0.003))
    check("Campo en superficie a 600 m: 24.731 pT con σ(T) y 24.770 pT con σ fija",
          cerca(e["b_ref_pT"], 24.7306, 0.001) and cerca(e_fija["b_ref_pT"], 24.7696, 0.001))
    check("σ local: 25 °C = σ25; +18 °C con α = 2 %/°C = ×1.36",
          cerca(sigma_at_T(0.02, 25.0), 0.02, 1e-15) and cerca(sigma_at_T(0.02, 43.0), 0.0272, 1e-12))
    check("Margen de μ_eff en dB de amplitud: −2.17 (v7.6) y +1.46 (v7.3)",
          cerca(v["mu"]["margen_dB"], -2.17, 0.01)
          and cerca(verificaciones(PARAMS_V73)["mu"]["margen_dB"], 1.46, 0.01))
    chk_i = verificaciones(replace(P0, i_a=9.0))["saturacion"]["i_con_margen_A"]
    chk_j = verificaciones(replace(P0, i_a=4.0))["saturacion"]["i_con_margen_A"]
    check("Corriente con margen = mín(I de diseño, I a utilización objetivo)",
          cerca(chk_i, v["saturacion"]["i_utilizacion_objetivo_A"], 1e-9) and chk_j == 4.0
          and v["saturacion"]["i_con_margen_A"] == P0.i_a)
    check("Utilización de B_sat = 79.1 %", cerca(v["saturacion"]["utilizacion"], 0.7906, 0.001),
          f"{v['saturacion']['utilizacion']:.4f}")
    check("I_sat = 8.22 A e I a utilización objetivo = 6.58 A",
          cerca(v["saturacion"]["corriente_saturacion_A"], 8.22, 0.01)
          and cerca(v["saturacion"]["i_utilizacion_objetivo_A"], 6.577, 0.005))
    check("Masa de ferrita 516 kg", cerca(v["geometria"]["masa_ferrita_kg"], 516.1, 0.2))
    check("B/C base descontado = 14.07", cerca(c["bc_desc"], 14.07, 0.01), f"{c['bc_desc']:.3f}")
    check("VAN base = 171.8 M", cerca(c["van"] / 1e6, 171.8, 0.1))
    check("Caso prudente B/C = 4.21", cerca(c["caso_prudente"]["bc_desc"], 4.21, 0.01))
    check("Hallazgos esperados (severidades v7.6)",
          [(h["id"], h["severidad"]) for h in r["hallazgos"]] ==
          [("F1", "BAJO"), ("F2", "MEDIO"), ("F3", "MEDIO"), ("F4", "ALTO"), ("F5", "ALTO"),
           ("F6", "MEDIO"), ("F7", "MEDIO"), ("F8", "MEDIO"), ("F9", "MEDIO"), ("F10", "MEDIO"),
           ("F11", "MEDIO"), ("F12", "MEDIO"), ("F13", "MEDIO"), ("F14", "MEDIO")])

    print("\n Regresión de diseños anteriores (v7.3 y v7.5)")
    e73 = calcular_enlace(PARAMS_V73, True)
    check("v7.3: SNR 37.15 dB, estrés 17.15 dB, 49 repeticiones (1470 s, peso 0.40)",
          cerca(e73["snr_tipico_dB"], 37.15, 0.01) and cerca(e73["estres"]["snr_dB"], 17.15, 0.01)
          and e73["tormenta"]["nbit"] == 49 and e73["tormenta"]["peso_canal"] == 0.40)
    check("v7.3: μ_eff 200 (teórico 236 no lo limita) y utilización 98.5 %",
          cerca(e73["mu_utilizable"], 200.0, 1e-9)
          and cerca(verificaciones(PARAMS_V73)["saturacion"]["utilizacion"], 0.9847, 0.001))
    e75 = calcular_enlace(PARAMS_V75, True)
    check("v7.5 recibida (μ sin tope): 40.65 / 20.65 / 25.65 dB, 22 repeticiones, utilización 84.4 %",
          cerca(e75["snr_tipico_dB"], 40.651, 0.01) and cerca(e75["estres"]["snr_dB"], 20.651, 0.01)
          and cerca(e75["estres"]["snr_mitigado_dB"], 25.651, 0.01) and e75["tormenta"]["nbit"] == 22
          and cerca(verificaciones(PARAMS_V75)["saturacion"]["utilizacion"], 0.844, 0.001))
    p75f = replace(PARAMS_V75, mu_limitado_por_geometria=True)
    e75f = calcular_enlace(p75f, True)
    check("v7.5 con μ físico: estrés 18.49 dB (no cierra), 36 repeticiones, peso 0.40",
          cerca(e75f["estres"]["snr_dB"], 18.486, 0.01) and e75f["tormenta"]["nbit"] == 36
          and e75f["tormenta"]["peso_canal"] == 0.40 and e75f["estres"]["snr_dB"] < SNR_OBJETIVO_DB)
    check("El tope de μ_eff nunca sube el SNR",
          e75f["snr_tipico_dB"] < e75["snr_tipico_dB"] and mu_efectivo(P0) < P0.mu_eff_design
          and mu_efectivo(PARAMS_V75) == PARAMS_V75.mu_eff_design and mu_efectivo(PARAMS_V6) == PARAMS_V6.mu_eff_design)
    cmpd = r["comparacion_disenos"]
    alt = cmpd["alternativa_nucleo_200"]
    check("Alternativa de núcleo Ø200: estrés 21.54 dB, pozo mínimo Ø253.6 mm, 603 kg",
          alt is not None and cerca(alt["snr_estres_dB"], 21.539, 0.003) and cerca(alt["d_pozo_min_mm"], 253.57, 0.05)
          and cerca(alt["masa_ferrita_kg"], 603.2, 0.3))
    p_corto = replace(P0, l_core=0.95)            # válido, pero la alternativa (Ø200) exigiría l_core ≥ 1.0 m
    r_corto = simular(p_corto, n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)
    buf_corto = io.StringIO()
    with contextlib.redirect_stdout(buf_corto):
        imprimir(r_corto, p_corto)
    check("Sin alternativa viable: se omite sin fallar y el informe se imprime",
          r_corto["comparacion_disenos"]["alternativa_nucleo_200"] is None and "Alt. núcleo" not in buf_corto.getvalue())
    check("Comparación de diseños coherente con los cálculos directos",
          cerca(cmpd["v75_como_se_recibio"]["snr_estres_dB"], e75["estres"]["snr_dB"], 1e-9)
          and cerca(cmpd["v75_con_mu_fisico"]["snr_estres_dB"], e75f["estres"]["snr_dB"], 1e-9)
          and cerca(cmpd["vigente"]["snr_estres_dB"], e["estres"]["snr_dB"], 1e-9))

    print("\n Lógica del árbol y del gate de canal")
    for x in r["arbol"] + r["gate_canal"]:
        check(x.get("nombre") or x["etiqueta"], x["fase"] == x["esperado"], x["codigo"])

    print("\n Invariantes físicos y económicos")
    check("ceil() corrige vida que no divide el horizonte",
          ciclos_reemplazo(8, 30) == 3 and int(30 / 8) - 1 == 2)
    check("ceil() coincide con vidas 7.5/10/15", [ciclos_reemplazo(x) for x in (7.5, 10, 15)] == [3, 2, 1])
    check("Calendario suma = fondo", cerca(sum(m for *_, m in calendario_reemplazos(VIDA_UTIL, 30)),
                                           c["reemplazos"], 1e-6))
    check("P(cizalla) monótona", all(p_shear(a) < p_shear(b) for a, b in ((6, 7), (7, 8))))
    check("Pd ≤ 0.95", all(prob_deteccion(m, k) <= 0.95 for m in (5, 6, 7, 8) for k in FACTOR_PRECURSOR))
    check("Pérdida por saturación nunca negativa",
          v["saturacion"]["perdida_dB"] >= 0
          and all(x["perdida_dB"] >= 0 for x in v["saturacion"]["barrido_bsat"].values()))
    pv = verificaciones(replace(PARAMS_V6, area_efectiva=True))["saturacion"]
    check("Con I=20 A (diseño v6) el núcleo satura: pérdida ≈ 9.8 dB",
          pv["excede"] and cerca(pv["perdida_dB"], 9.8, 0.3), f"{pv['perdida_dB']:.2f} dB")
    check("Momento operativo ≤ momento lineal y ≤ saturado",
          momento_operativo(200, P0, True) <= min(momento_lineal(200, P0), momento_saturado(P0)) + 1e-9)
    check("Con margen: utilización ≤ objetivo",
          utilizacion_bsat(mu_efectivo(P0), replace(P0, i_a=v["con_margen"]["i_a"]))
          <= P0.util_bsat_objetivo + 1e-9)
    check("Beneficio escala linealmente con φ",
          cerca(beneficio_catalogo(P0, phi=0.5)["total"], 0.5 * beneficio_catalogo(P0, phi=1.0)["total"], 1e-3))
    ben1 = beneficio_catalogo(P0, phi=1.0, gasto=0.0)["total"]
    cal = calendario_reemplazos(VIDA_UTIL, 30)
    eq = valorar(P0, c["capex"], c["opex_anual"], cal,
                 beneficio_30=ben1 * c["equilibrio"]["phi_solo_privado"])
    check("φ de equilibrio → B/C = 1", cerca(eq["bc_desc"], 1.0, 1e-9), f"{eq['bc_desc']:.6f}")
    check("Beneficio privado = ahorro analítico del catálogo",
          cerca(c["beneficio_privado_30"] / 1e6, r["deteccion"]["ahorro_esperado_musd"], 1e-6))
    mc, an = r["deteccion"]["mc"], r["deteccion"]["ahorro_esperado_musd"]
    check("MC de ahorro ≈ analítico (4 SE)", abs(mc["ahorro_medio_musd"] - an) <= 4 * mc["ahorro_se_musd"])
    rm = r["red"]["p_min3_mc"]
    check("MC de red ≈ analítico (4 SE)", abs(rm["p_min_k"] - r["red"]["p_min3_analitica"]) <= 4 * rm["se"])
    check("Determinismo (misma semilla → mismo JSON)",
          json.dumps(simular(), default=_json_default, sort_keys=True)
          == json.dumps(r, default=_json_default, sort_keys=True))
    check("KPI principal por defecto = saturado", r["modo_principal"] == "con_saturacion")
    check("Hallazgos: ninguno recomienda I mayor que I_sat",
          all("I≈7" not in (h["accion"] + h["detalle"]) for h in r["hallazgos"]))

    print("\n Fronteras del árbol de decisión")
    check("energía = umbral → ARCHIVADO", evaluar_evento(Evento(1.5, 1.5, 5, 4, 0.99)).fase == Fase.ARCHIVADO)
    check("energía < umbral → ARCHIVADO", evaluar_evento(Evento(1.0, 1.5, 5, 4, 0.99)).fase == Fase.ARCHIVADO)
    check("2 sensores → AMARILLA; 3 sensores avanza",
          evaluar_evento(Evento(3, 1.5, 2, 4, 0.99)).fase == Fase.AMARILLA
          and evaluar_evento(Evento(3, 1.5, 3, 0, 0.99)).fase == Fase.NARANJA)
    check("1 nodo → NARANJA; 2 nodos avanza",
          evaluar_evento(Evento(3, 1.5, 5, 1, 0.99)).fase == Fase.NARANJA
          and evaluar_evento(Evento(3, 1.5, 5, 2, 0.5)).fase == Fase.PREALERTA)
    check("P = 0.85 → PREALERTA; P = 0.851 → ROJA",
          evaluar_evento(Evento(3, 1.5, 5, 2, 0.85)).fase == Fase.PREALERTA
          and evaluar_evento(Evento(3, 1.5, 5, 2, 0.851)).fase == Fase.ROJA)
    d_ok = evaluar_evento(Evento(3, 1.5, 5, 2, 0.9), 0.50)
    d_bajo = evaluar_evento(Evento(3, 1.5, 5, 2, 0.9), 0.499)
    check("peso = 0.50 no degrada; 0.499 sí", d_ok.fase == Fase.ROJA and not d_ok.degradada
          and d_bajo.fase == Fase.PREALERTA and d_bajo.degradada)
    check("override exige P > 0.95 y ≥ 3 nodos",
          evaluar_evento(Evento(3, 1.5, 5, 4, 0.95), 0.4).fase == Fase.PREALERTA
          and evaluar_evento(Evento(3, 1.5, 5, 3, 0.951), 0.4).fase == Fase.ROJA
          and evaluar_evento(Evento(3, 1.5, 5, 2, 0.97), 0.4).fase == Fase.PREALERTA)
    check("Entradas inválidas del árbol rechazadas",
          _lanza(lambda: evaluar_evento(Evento(3, 1.5, 5, 2, float("nan"))))
          and _lanza(lambda: evaluar_evento(Evento(3, 1.5, 5, 2, 0.9), 1.5))
          and _lanza(lambda: Evento(3, 1.5, -1, 2, 0.9)))

    print("\n Saturación activa y funciones auxiliares")
    p20 = replace(P0, i_a=20.0)
    e20s, e20l = calcular_enlace(p20, True), calcular_enlace(p20, False)
    v20 = verificaciones(p20)["saturacion"]
    check("Con 20 A: momento operativo = saturado < lineal",
          cerca(momento_operativo(mu_efectivo(p20), p20, True), momento_saturado(p20), 1e-9)
          and momento_saturado(p20) < momento_lineal(mu_efectivo(p20), p20))
    check("Sin tope, el modo lineal ignora la saturación",
          cerca(momento_operativo(mu_efectivo(p20), p20, False), momento_lineal(mu_efectivo(p20), p20), 1e-9))
    check("Caída de SNR por saturación = pérdida en dB",
          cerca(e20l["snr_tipico_dB"] - e20s["snr_tipico_dB"], v20["perdida_dB"], 1e-6),
          f"{v20['perdida_dB']:.2f} dB")
    check("Hallazgo F1: ALTO si satura, BAJO con 4 A",
          simular(p20, n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][0]["severidad"] == "ALTO"
          and simular(replace(P0, i_a=4.0), n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][0]["severidad"] == "BAJO")
    check("peso_canal_ulf: frontera en T_max",
          peso_canal_ulf(T_MAX_ULF_S) == PESO_ULF_OK
          and peso_canal_ulf(T_MAX_ULF_S + 30) == PESO_ULF_DEGRADADO)
    check("bits_requeridos: fronteras, NaN y SNR extremo",
          bits_requeridos(20.0) == (1, True) and bits_requeridos(19.99) == (2, True)
          and bits_requeridos(float("nan")) == (MAX_BITS, False)
          and bits_requeridos(-1e5) == (MAX_BITS, False)
          and bits_requeridos(float("-inf")) == (MAX_BITS, False))
    check("corriente_saturacion_a rechaza μ_eff ≤ 1", _lanza(lambda: corriente_saturacion_a(1.0, P0)))
    g0 = v["geometria"]
    check("Holgura bobina–pared = (Ø interior − Ø bobina)/2 = 5.72 mm y cumple",
          cerca(g0["holgura_radial_mm"], (g0["d_int_sonda_mm"] - g0["d_ext_bobina_mm"]) / 2, 1e-9)
          and cerca(g0["holgura_radial_mm"], 5.72, 0.01) and g0["ajuste_ok"], f"{g0['holgura_radial_mm']:.2f} mm")
    check("Holgura sonda–pozo = (Ø pozo − Ø sonda)/2 = 10 mm y cumple",
          cerca(g0["holgura_pozo_sonda_mm"], (P0.d_hole_mm - P0.d_sonde_mm) / 2, 1e-9) and g0["pozo_ok"])
    check("Sonda y pozo mínimos: Ø218.6 y Ø238.6 mm",
          cerca(g0["d_sonde_min_mm"], 218.57, 0.01) and cerca(g0["d_pozo_min_mm"], 238.57, 0.01))
    g_chica = verificaciones(replace(P0, d_sonde_mm=210.0))["geometria"]
    g_ok = verificaciones(replace(P0, d_sonde_mm=g_chica["d_sonde_min_mm"] + 0.01, d_hole_mm=260.0))["geometria"]
    check("Sonda chica → holgura insuficiente; con la sonda mínima cumple",
          not g_chica["ajuste_ok"] and g_ok["ajuste_ok"] and g_chica["sonde_min_cabe_en_pozo"])
    check("Pozo ajustado se reporta en F3",
          not verificaciones(replace(P0, d_hole_mm=235.0))["geometria"]["pozo_ok"]
          and "sonda–pozo" in simular(replace(P0, d_hole_mm=235.0), n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][2]["detalle"])
    check("holgura_min_mm es un parámetro editable",
          not verificaciones(replace(P0, holgura_min_mm=8.0))["geometria"]["ajuste_ok"])
    check("Núcleo más largo que la sonda se reporta en F3",
          "no cabe en la sonda" in simular(replace(P0, l_core=8.0), n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][2]["detalle"])
    s_det, s_red = np.random.SeedSequence(SEED).spawn(2)
    rm_ref = red_mc(np.random.default_rng(s_red), 100_000, P0, r["red"]["disp_nodo"])
    check("Flujos aleatorios independientes y fijados por semilla",
          rm_ref["p_min_k"] == r["red"]["p_min3_mc"]["p_min_k"]
          and np.random.default_rng(s_det).random() != np.random.default_rng(s_red).random())
    sub_c = sum(CAPEX_BASE.values())
    cont_c = simular(replace(P0, contingencia_pct=0.123456789), n_mc=10, n_dias=DIAS_PRUEBA, n_rep=5)["costos"]["contingencia"]
    check("Contingencia redondeada, no truncada",
          cont_c == round(sub_c * 0.123456789) and cont_c != int(sub_c * 0.123456789), f"{cont_c:,}")
    barrido = _barrido_aleatorio()
    check("Barrido de parámetros aleatorios sin fallos", not barrido, barrido[0] if barrido else "60 casos")

    print("\n Hallazgos F2 y F9 y sensibilidad al CAPEX")
    f2_75 = simular(PARAMS_V75, n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][1]
    f2_73 = simular(PARAMS_V73, n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][1]
    f2_76 = r["hallazgos"][1]
    check("F2 (v7.5): 660 s dentro de T_max, sin decir «por encima»",
          "dentro de" in f2_75["detalle"] and "por encima" not in f2_75["detalle"])
    check("F2 (v7.3): 1470 s por encima de T_max y la ROJA no se autoriza sola",
          "por encima de" in f2_73["detalle"] and "no autoriza" in f2_73["detalle"] and f2_73["severidad"] == "MEDIO")
    check("F2 (v7.6): «margen mínimo» y severidad MEDIO", "margen mínimo" in f2_76["titulo"] and f2_76["severidad"] == "MEDIO")
    p_holg = replace(P0, d_core=0.20, r_bobina_m=0.104, i_a=7.4, d_sonde_mm=236.0, d_hole_mm=256.0)
    f2_h = simular(p_holg, n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][1]
    check("F2 con margen ≥ 1 dB y tormenta a tiempo: BAJO", f2_h["severidad"] == "BAJO" and "margen de" in f2_h["detalle"],
          f2_h["titulo"])
    f9_base = simular(PARAMS_V6, n_mc=50, n_dias=DIAS_PRUEBA, n_rep=5)["hallazgos"][8]
    check("F9: BAJO si la geometría coincide con la del CAPEX; MEDIO si no",
          f9_base["severidad"] == "BAJO" and r["hallazgos"][8]["severidad"] == "MEDIO")
    sc = r["sensibilidad"]["capex_bc_desc"]
    check("Sensibilidad al CAPEX: nominal = base y decreciente",
          cerca(sc["capex100"], c["bc_desc"], 1e-12) and sc["capex100"] > sc["capex115"] > sc["capex130"] > sc["capex150"])

    print("\n Márgenes de tiempo y sismicidad de fondo")
    mt = r["margenes_tiempo"]
    prt, sis = mt["presupuesto"], mt["sismicidad"]
    filas_t = prt["filas"]
    check("Mc derivada del catálogo OVSICORI 2024 = 2.43", cerca(mc_desde_catalogo(13_495, 36), 2.426, 0.005))
    mm = mag_gr_truncada(np.random.default_rng(5), 200_000, 2.4, 1.0, 6.5)
    check("Magnitudes Gutenberg-Richter: dentro de [Mc, Mmax] y b ≈ 1",
          mm.min() >= 2.4 and mm.max() <= 6.5 and cerca(math.log10(math.e) / (mm.mean() - 2.4), 1.0, 0.02))
    check("Presupuesto: primer bit 30/30/30/750 s y mensaje 90/90/90/2250 s",
          [f["t_primer_bit_s"] for f in filas_t] == [30.0, 30.0, 30.0, 750.0]
          and [f["t_mensaje_s"] for f in filas_t] == [90.0, 90.0, 90.0, 2250.0])
    check("Tormenta: el mensaje no cabe (−1350 s) pero el primer bit sí (+150 s)",
          filas_t[-1]["margen_mensaje_s"] == -1350 and filas_t[-1]["margen_primer_bit_s"] == 150
          and filas_t[-1]["ok_primer_bit"] and not filas_t[-1]["ok_mensaje"]
          and all(f["ok_mensaje"] for f in filas_t[:-1]))
    check("Latencia ULF mínima 33.8 s, peor 753.8 s; el supuesto de 7.3 s es incoherente",
          cerca(prt["lat_ulf_min_s"], 33.8, 1e-9) and cerca(prt["lat_ulf_peor_s"], 753.8, 1e-9)
          and not prt["lat_ulf_consistente"])
    check("Fracción de tiempo sin margen: mensaje 0.5 %, primer bit 0 %; las fracciones suman 1",
          cerca(prt["frac_tiempo_mensaje_no_cabe"], 0.005, 1e-12) and prt["frac_tiempo_primer_bit_no_cabe"] == 0
          and cerca(sum(KP_TIEMPO.values()), 1.0, 1e-12))
    a75 = next(a for a in prt["aviso"] if a["mw"] == 7.5)
    check("Margen de aviso Mw 7.5: 96 h menos 0.209 h", a75["aviso_h"] == 96 and cerca(a75["margen_h"], 96 - 753.8 / 3600, 1e-9))
    check("Sismos por día: media = tasa de OVSICORI (4 error estándar)",
          abs(sis["por_dia"]["media"] - 13_495 / 365) <= 4 * math.sqrt(13_495 / 365 / sis["n_dias"]),
          f"{sis['por_dia']['media']:.2f}")
    check("Fases de fondo suman el total y ARCHIVADO domina",
          sum(x["n"] for x in sis["fases"].values()) == sis["eventos"]
          and sis["fases"]["ARCHIVADO"]["porcentaje"] > 90)
    check("Cifras de referencia de la simulación de fondo (determinista)",
          sis["eventos"] == 1_349_666 and sis["fases"]["NARANJA"]["n"] == 6066
          and sis["fases"]["PREALERTA"]["n"] == 4848 and sis["fases"]["AMARILLA"]["n"] == 46_322
          and sis["fases"]["ROJA"]["n"] == 0 and sis["cola_ulf"][0]["mensajes"] == 10_914,
          f"{sis['eventos']:,} sismos")
    check("Pasan las compuertas 48.5 por año; σ_LR crítico 1.28",
          cerca(sis["pasan_compuertas_anio"], 48.5, 0.1) and cerca(sis["sigma_critico"], 1.284, 0.005))
    so = sis["solapamiento"]
    p1, n1_ = so["analitico"], sis["eventos"]
    check("Solapamiento de ventanas simulado ≈ analítico (4 error estándar)",
          abs(so["simulado"] - p1) <= 4 * math.sqrt(p1 * (1 - p1) / n1_)
          and abs(so["simulado_detectados"] - so["analitico_detectados"])
          <= 4 * math.sqrt(so["analitico_detectados"] / (sis["detectados_por_dia"] * sis["n_dias"])),
          f"{100 * so['simulado']:.2f} %")
    rnd_t = random.Random(11)
    ok_vec = True
    for peso_t in (1.0, 0.4, 0.3):
        dl = np.array([rnd_t.uniform(-1, 3) + 0.0 for _ in range(3000)])
        dl[np.abs(dl) < 1e-6] = 0.5
        sn = np.array([rnd_t.randint(0, 8) for _ in range(3000)])
        nd = np.array([rnd_t.randint(0, 5) for _ in range(3000)])
        pb = np.array([rnd_t.choice([0.85, 0.95, 0.9500001, 0.851, rnd_t.random()]) for _ in range(3000)])
        vec = fases_vectorizado(dl, sn, nd, pb, peso_t)
        esc = [int(evaluar_evento(Evento(1.5 * 10 ** float(a), 1.5, int(b_), int(c_), float(d_)), peso_t).fase)
               for a, b_, c_, d_ in zip(dl, sn, nd, pb, strict=True)]
        ok_vec = ok_vec and list(vec) == esc
    check("Cascada vectorizada = evaluar_evento (3 pesos de canal, fronteras incluidas)", ok_vec)
    check("Cola FIFO determinista: llegadas 0/10/20 con servicio 30 s → esperas 0/20/40 s",
          list(cola_fifo(np.array([0.0, 10.0, 20.0]), 30.0)) == [0.0, 20.0, 40.0])
    rq = np.random.default_rng(3)
    llq = np.cumsum(rq.exponential(1 / 0.005, 200_000))
    wq = cola_fifo(llq, 100.0)
    check("Cola M/D/1 con ρ = 0.5: espera media ≈ ρ·D/(2(1−ρ)) = 50 s (6 %)",
          cerca(wq.mean(), 50.0, 3.0), f"{wq.mean():.1f} s")
    lo10, hi10 = poisson_ic95(10)
    check("IC95 % de Poisson: k = 10 → 4.8–18.4 y k = 0 → hasta 3",
          cerca(lo10, 4.80, 0.05) and cerca(hi10, 18.39, 0.05) and poisson_ic95(0) == (0.0, 3.0))
    sc_t = sigma_critico(sis["pasan_compuertas_anio"])
    check("σ crítico: la tasa de ROJA en σ crítico = meta; sin límite si ya cumple",
          cerca(sis["pasan_compuertas_anio"] * phi_cola_normal(xi_umbral(sc_t)), FA_ANUAL, 1e-7)
          and math.isinf(sigma_critico(0.01)))
    s2 = next(x for x in sis["sensibilidad_sigma"] if x["sigma"] == 2.0)
    check("ROJA de fondo simulada ≈ analítica (σ = 2, 4 desviaciones de Poisson)",
          abs(s2["roja_anio"] - s2["analitico_anio"]) * sis["anios"] <= 4 * math.sqrt(s2["analitico_anio"] * sis["anios"]))
    check("ROJA de fondo con σ base cumple la meta y la sensibilidad crece con σ",
          sis["roja_anio"] <= FA_ANUAL and sis["sigma_lr"] < sis["sigma_critico"]
          and [x["roja_anio"] for x in sis["sensibilidad_sigma"]] == sorted(x["roja_anio"] for x in sis["sensibilidad_sigma"]))
    hid = {h["id"]: h for h in r["hallazgos"]}
    check("Hallazgos F10 a F12 con el contenido esperado",
          "incompatible" in hid["F10"]["titulo"] and "no cabe" in hid["F11"]["titulo"]
          and "razón de verosimilitud" in hid["F12"]["titulo"] and "σ_LR ≤ 1.28" in hid["F12"]["detalle"])
    check("m_detectable: piso de 1 km (r < 1 km no baja la magnitud)",
          cerca(float(m_detectable(np.array([0.5]))[0]), 1.0, 1e-12)
          and cerca(float(m_detectable(np.array([1.5]))[0]), 1.0 + 1.7 * math.log10(1.5), 1e-12))
    check("Cascada vectorizada: delta = 0 → ARCHIVADO; delta > 0 avanza",
          list(fases_vectorizado(np.array([0.0, 1e-9, -1e-9]), np.array([5, 5, 5]), np.array([3, 3, 3]),
                                 np.array([0.99, 0.99, 0.99])))
          == [int(Fase.ARCHIVADO), int(Fase.ROJA), int(Fase.ARCHIVADO)])
    check("cabe_en_tmax: frontera en T_max y enlace que no alcanza el SNR",
          cabe_en_tmax(T_MAX_ULF_S) and not cabe_en_tmax(T_MAX_ULF_S + 0.1) and not cabe_en_tmax(10.0, False))
    check("Espaciado medio = 1440/λ y ocupación de la cola = mensajes·servicio/(T·nodos)",
          cerca(sis["espaciado_medio_min"], 1440 / (13_495 / 365), 1e-9)
          and all(cerca(c_["rho"], c_["mensajes"] * c_["servicio_s"] / (sis["n_dias"] * 86400 * len(NODOS_ILUSTRATIVOS)), 1e-12)
                  for c_ in sis["cola_ulf"]))
    print("\n Réplicas con el cable cortado y sensibilidades del estrés")
    rpl, se = mt["replicas"], r["sensibilidad_estres"]
    colas_r = rpl["colas"]
    check("Omori: fracción en 24 h = 0.3422 y réplicas totales = 9416 (Båth, b = 1, Mc 2.43)",
          cerca(rpl["fraccion_primeras_horas"], 0.34224, 1e-4) and cerca(rpl["replicas_total_esperadas"], 9416.1, 0.2))
    check("fraccion_omori: crece con las horas y vale 1 en todo el catálogo",
          fraccion_omori(6, 0.05, 365) < fraccion_omori(24, 0.05, 365) < fraccion_omori(48, 0.05, 365)
          and cerca(fraccion_omori(365 * 24, 0.05, 365), 1.0, 1e-12))
    t_om = tiempos_omori(np.random.default_rng(3), 200_000, 24.0, 0.05)
    check("Omori: tiempos ordenados en [0, 24 h] y mediana = analítica (4.30 h)",
          bool(np.all(np.diff(t_om) >= 0)) and t_om[0] >= 0 and t_om[-1] <= 86400
          and cerca(float(np.median(t_om)) / 3600, (0.05 * (1.05 / 0.05) ** 0.5 - 0.05) * 24, 0.05))
    check("Réplicas en 24 h: 3225 sismos, 36.8 mensajes y 0 alertas rojas por secuencia (determinista)",
          rpl["nodo"] == "Osa" and cerca(rpl["sismos_24h"], 3225.435, 0.01)
          and cerca(rpl["mensajes_24h"], 36.845, 0.01) and rpl["mensajes_roja_24h"] == 0)
    check("Réplicas por fase en 24 h (nodo de Osa): 161 amarillas, 26 naranjas, 10.8 pre-alertas, 0 rojas; suman los sismos más cercanos al nodo",
          cerca(rpl["fases_24h"]["AMARILLA"], 160.96, 0.05) and cerca(rpl["fases_24h"]["NARANJA"], 26.01, 0.05)
          and cerca(rpl["fases_24h"]["PREALERTA"], 10.835, 0.05) and rpl["fases_24h"]["ROJA"] == 0
          and cerca(rpl["fases_24h"]["NARANJA"] + rpl["fases_24h"]["PREALERTA"] + rpl["fases_24h"]["ROJA"], rpl["mensajes_24h"], 1e-9))
    check("Cola con servicio de 90 s: espera máxima media 68 s, drenaje 90 s, ninguna espera > T_max, igual en las tres condiciones",
          all(cerca(q["espera_max_media_s"], 67.97, 0.05) and cerca(q["drenaje_medio_s"], 90.44, 0.05)
              and q["p_espera_mayor_tmax"] == 0 and q["cola_no_vacia_24h"] == 0 for q in colas_r[:3]))
    check("Cola en tormenta: ρ = 0.96, 93 % espera más que T_max, espera máxima media 8.6 h, 37 % con mensajes sin atender a las 24 h",
          cerca(colas_r[3]["rho_24h"], 0.9595, 0.001) and cerca(colas_r[3]["p_espera_mayor_tmax"], 0.9349, 0.002)
          and cerca(colas_r[3]["espera_max_media_s"] / 3600, 8.566, 0.02) and cerca(colas_r[3]["cola_no_vacia_24h"], 0.37, 0.001)
          and cerca(colas_r[3]["drenaje_medio_s"], 9425.5, 1.0))
    check("ρ de la cola = mensajes medios × servicio / 24 h",
          all(cerca(q["rho_24h"], rpl["mensajes_24h"] * q["servicio_s"] / 86400, 1e-9) for q in colas_r))
    check("Latencia de 111 con preempción: 63.8 s normal y 783.8 s en tormenta",
          cerca(colas_r[0]["latencia_111_con_preempcion_s"], 63.8, 1e-9) and cerca(colas_r[3]["latencia_111_con_preempcion_s"], 783.8, 1e-9))
    rp_gam = replicas_cable_cortado(np.random.default_rng(1), prt, 5, nodo=1)
    check("Réplicas: otro nodo y validación de n_rep",
          rp_gam["nodo"] == "Gran Área Metropolitana" and rp_gam["n_rep"] == 5
          and cerca(rp_gam["mensajes_24h"], 30.8, 0.01) and cerca(rp_gam["sismos_24h"], 3242.0, 0.01)
          and _lanza(lambda: replicas_cable_cortado(np.random.default_rng(1), prt, 1)))
    check("Rechazo mínimo 9.917 dB (20 dB) y 10.917 dB (1 dB de margen); a ese rechazo el SNR da 20 dB",
          cerca(se["rechazo_minimo_db"], 9.917, 0.003) and cerca(se["rechazo_minimo_con_margen_db"], 10.917, 0.003)
          and cerca(snr_db(e["m_ref"], 60.0, P0, rej_db=se["rechazo_minimo_db"])[1], 20.0, 1e-9))
    check("Barrido de rechazo: 1 dB de SNR por dB de rechazo y 30 dB = SNR típico",
          cerca(se["rechazos"][-1]["snr_dB"], e["snr_tipico_dB"], 1e-9)
          and all(cerca(a["snr_dB"] - b["snr_dB"], a["rej_db"] - b["rej_db"], 1e-9) for a, b in zip(se["rechazos"][1:], se["rechazos"][:-1], strict=True))
          and cerca(next(x for x in se["rechazos"] if x["rej_db"] == 10.0)["snr_dB"], e["estres"]["snr_dB"], 1e-9))
    check("Barrido de α: α = 0 → 38.186 dB (sin efecto térmico), 5 % → 37.774 dB, decrece con α",
          cerca(se["alphas"][0]["snr_peor_lito_dB"], 38.1863, 0.003) and cerca(se["alphas"][-1]["snr_peor_lito_dB"], 37.774, 0.003)
          and cerca(se["alphas"][2]["snr_peor_lito_dB"], e["snr_peor_lito_dB"], 1e-9)
          and all(a["snr_peor_lito_dB"] > b["snr_peor_lito_dB"] for a, b in zip(se["alphas"][:-1], se["alphas"][1:], strict=True)))
    check("Hallazgos F13 y F14 con el contenido esperado",
          "no da abasto" in hid["F13"]["titulo"] and "93 %" in hid["F13"]["detalle"]
          and "9.92 dB" in hid["F14"]["titulo"] and "10.92 dB" in hid["F14"]["detalle"])
    check("sismicidad_fondo rechaza menos de 30 días",
          _lanza(lambda: sismicidad_fondo(np.random.default_rng(1), 10, prt)))

    print("\n Validación y CLI")
    for nombre, kw in (("depth_m<0", {"depth_m": -1}), ("φ>1", {"fraccion_eventos_horizonte": 1.5}),
                       ("sonda≥pozo", {"d_sonde_mm": 250}), ("bobina<núcleo", {"r_bobina_m": 0.01}),
                       ("i_a = NaN", {"i_a": float("nan")}), ("depth_m = inf", {"depth_m": float("inf")}),
                       ("μ_eff = 1", {"mu_eff_design": 1.0}), ("μ_eff > μ_r", {"mu_eff_design": 5000.0}),
                       ("contingencia < 0", {"contingencia_pct": -1.0}), ("inflación = −2", {"inflacion": -2.0}),
                       ("días de completación < 0", {"dias_compl": -5.0}), ("rechazo = NaN", {"rej_db": float("nan")}),
                       ("tasa de descuento ≥ 1", {"r_disc": 1.5}), ("α de conductividad < 0", {"alpha_sigma": -0.01}), ("α de conductividad > 0.1", {"alpha_sigma": 0.5}), ("pared ≥ sonda", {"espesor_pared_sonde_mm": 110.0}),
                       ("núcleo corto (L/D < 5)", {"l_core": 0.5}), ("holgura mínima ≤ 0", {"holgura_min_mm": 0.0})):
        try:
            Params(**kw)
            check(f"Rechaza {nombre}", False)
        except ValueError:
            check(f"Rechaza {nombre}", True)
    check("Escenario o precursor inválido rechazado",
          _lanza(lambda: Escenario("x", None, 7.0, "xx", 1e6, "escenario"))
          and _lanza(lambda: Escenario("x", None, float("nan"), "posible", 1e6, "escenario"))
          and _lanza(lambda: prob_deteccion(6.0, "xx")))
    check("simular rechaza n_mc < 2", _lanza(lambda: simular(P0, n_mc=1, n_dias=DIAS_PRUEBA, n_rep=5)))
    check("Validaciones restantes (rechazo > 120 dB, tipo, daño, energía NaN, vida ≤ 0)",
          _lanza(lambda: Params(rej_db=200.0))
          and _lanza(lambda: Escenario("x", None, 7.0, "posible", 1e6, "otro"))
          and _lanza(lambda: Escenario("x", None, 7.0, "posible", -1.0, "escenario"))
          and _lanza(lambda: Evento(float("nan"), 1.5, 5, 2, 0.9))
          and _lanza(lambda: ciclos_reemplazo(0.0)))
    with tempfile.TemporaryDirectory() as td:
        ruta = Path(td) / "t.json"

        def cli(*args: str) -> int:
            with contextlib.redirect_stderr(io.StringIO()):
                return main(["--quiet", "--out", str(ruta), *args])

        check("CLI: valor no numérico → código 2", cli("--set", "i_a=abc") == 2)
        check("CLI: parámetro desconocido → código 2", cli("--set", "foo=1") == 2)
        check("CLI: --set sin '=' → código 2", cli("--set", "i_a") == 2)
        check("CLI: entero con decimales → código 2", cli("--set", "n_nodos=5.5") == 2)
        check("CLI: bool inválido → código 2", cli("--set", "area_efectiva=quizá") == 2)
        check("CLI: parámetro fuera de rango → código 2", cli("--set", "i_a=-1") == 2)
        check("CLI: --n-mc < 2 → código 2", cli("--n-mc", "1") == 2)
        check("CLI: --dias < 30 → código 2; --dias 60 → código 0", cli("--dias", "5") == 2 and cli("--dias", "60") == 0)
        check("CLI: --n-rep < 2 → código 2; --n-rep 5 → código 0", cli("--n-rep", "1") == 2 and cli("--n-rep", "5") == 0)
        check("CLI: --n-mc 500 y --set múltiples → código 0",
              cli("--n-mc", "500", "--set", "area_efectiva=no", "--set", "n_turns=800") == 0
              and json.loads(ruta.read_text(encoding="utf-8"))["parametros"]["n_turns"] == 800)
        archivo = Path(td) / "archivo"
        archivo.write_text("x", encoding="utf-8")
        with contextlib.redirect_stderr(io.StringIO()):
            rc_io = main(["--quiet", "--out", str(archivo / "x.json")])
        check("CLI: ruta no escribible → código 1", rc_io == 1)
        try:
            guardar_json({"x": object()}, Path(td) / "mal.json")     # falla tras crear el temporal
            serializa_mal = False
        except TypeError:
            serializa_mal = True
        check("Fallo al serializar no deja temporales ni archivo parcial",
              serializa_mal and not list(Path(td).glob("*.tmp")) and not (Path(td) / "mal.json").exists())
        rc = main(["--quiet", "--out", str(ruta), "--set", "i_a=5.1"])
        d = json.loads(ruta.read_text(encoding="utf-8"))
        check("CLI --set i_a=5.1 aplica y termina en 0", rc == 0 and cerca(d["parametros"]["i_a"], 5.1, 1e-9))
        check("CLI deja el JSON sin NaN/inf", _sin_no_finitos(d))
        main(["--quiet", "--out", str(ruta), "--lineal"])
        check("CLI --lineal cambia el KPI principal",
              json.loads(ruta.read_text(encoding="utf-8"))["modo_principal"] == "lineal")

    print(f"\n{'TODAS LAS PRUEBAS PASAN' if not fallos else 'FALLARON: ' + ', '.join(fallos)}")
    return 0 if not fallos else 1


def _sin_no_finitos(x) -> bool:
    if isinstance(x, float):
        return math.isfinite(x)
    if isinstance(x, dict):
        return all(_sin_no_finitos(v) for v in x.values())
    if isinstance(x, list):
        return all(_sin_no_finitos(v) for v in x)
    return True


# ══════════════════════════════════════════════════════════════════════════
#  10. CLI
# ══════════════════════════════════════════════════════════════════════════
def _convertir(k: str, v: str, tipo: str) -> Any:
    if "bool" in tipo:
        t = v.strip().lower()
        if t in ("1", "true", "si", "sí", "yes"):
            return True
        if t in ("0", "false", "no"):
            return False
        raise ValueError(f"valor inválido para {k}: '{v}' (se esperaba verdadero/falso)")
    try:
        x = float(v)
    except ValueError:
        raise ValueError(f"valor inválido para {k}: '{v}' (se esperaba un número)") from None
    if tipo == "int":
        if not x.is_integer():
            raise ValueError(f"valor inválido para {k}: '{v}' (se esperaba un entero)")
        return int(x)
    return x


def _aplicar_sets(p: Params, sets: list[str]) -> Params:
    """Aplica --set clave=valor; lanza ValueError con mensaje claro si algo no es válido."""
    tipos = {f.name: str(f.type) for f in fields(Params)}
    cambios: dict[str, Any] = {}
    for s in sets:
        if "=" not in s:
            raise ValueError(f"--set espera clave=valor, recibió '{s}'")
        k, v = s.split("=", 1)
        if k not in tipos:
            raise ValueError(f"parámetro desconocido '{k}'. Válidos: {', '.join(tipos)}")
        cambios[k] = _convertir(k, v, tipos[k])
    return replace(p, **cambios)


def main(argv: list[str] | None = None) -> int:
    """Códigos de salida: 0 correcto · 1 error de escritura · 2 error de uso o parámetros."""
    ap = argparse.ArgumentParser(description=f"GEO-PROBE CR v{VERSION}")
    ap.add_argument("--out", default="GEO_PROBE_CR_v7_3_resultados.json", help="ruta del JSON")
    ap.add_argument("--seed", type=int, default=SEED)
    ap.add_argument("--n-mc", type=int, default=100_000, help="iteraciones Monte Carlo (≥ 2)")
    ap.add_argument("--dias", type=int, default=DIAS_SIM, help="días de sismicidad de fondo a simular (≥ 30)")
    ap.add_argument("--n-rep", type=int, default=N_REP_DEFECTO, help="secuencias de réplicas a simular (≥ 2)")
    ap.add_argument("--lineal", action="store_true",
                    help="KPI principal sin tope de saturación (default: con tope)")
    ap.add_argument("--set", action="append", default=[], metavar="CLAVE=VALOR",
                    help="sobrescribe un parámetro (repetible)")
    ap.add_argument("--selftest", action="store_true", help="ejecutar pruebas y salir")
    ap.add_argument("--quiet", action="store_true", help="no imprimir el informe")
    a = ap.parse_args(argv)

    if a.selftest:
        return selftest()
    try:
        p = _aplicar_sets(P0, a.set)
        res = simular(p, seed=a.seed, saturacion=not a.lineal, n_mc=a.n_mc, n_dias=a.dias, n_rep=a.n_rep)
    except ValueError as exc:
        print(f"Error de parámetros: {exc}", file=sys.stderr)
        return 2
    if not a.quiet:
        imprimir(res, p)
    try:
        ruta = guardar_json(res, Path(a.out))
    except OSError as exc:
        print(f"Error al escribir '{a.out}': {exc}", file=sys.stderr)
        return 1
    if not a.quiet:
        print(f"\n  JSON → {ruta}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
