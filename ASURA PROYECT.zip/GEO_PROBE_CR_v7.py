#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GEO-PROBE CR — v7.0 CANÓNICA
Red Nacional de Precursores Sísmicos · Costa Rica
Inventor: Jason Manuel Sarmiento Salazar · OTPR CR / PCT WIPO
Divulgación técnica: 12 de septiembre de 2026

Unifica en un solo archivo la línea v3 → v6.4 (borehole 600 m, sin reactor,
cable primario + ULF de respaldo, decisión bayesiana multi-fase).

USO
    python GEO_PROBE_CR_v7.py                       # informe completo + JSON
    python GEO_PROBE_CR_v7.py --out resultados.json # ruta de salida del JSON
    python GEO_PROBE_CR_v7.py --saturacion          # KPIs con tope de saturación
    python GEO_PROBE_CR_v7.py --selftest            # pruebas de regresión
    python GEO_PROBE_CR_v7.py --quiet               # solo JSON, sin informe

REPRODUCIBILIDAD
    Determinista: cada bloque estocástico usa su propio flujo derivado de la
    semilla (SeedSequence.spawn), de modo que agregar o quitar una impresión
    ya no altera los demás resultados. Sin dependencias fuera de numpy.

TRAZABILIDAD DE PARÁMETROS
    [V] fórmula física estándar o derivado analíticamente de otros parámetros
    [H] hipótesis de diseño sin fuente citada dentro del proyecto
    El registro completo está en SUPUESTOS y se exporta al JSON.

CAMBIOS RESPECTO A v6.4 (los valores sellados NO se modifican)
    1. Estructura: cálculo puro (simular) separado de la presentación.
    2. Parámetros en dataclass inmutable; validación de entradas.
    3. ArbolIA sin estado, con Enum de fases (antes: fase "111" mezclada con
       índices 0-3) y rótulo corregido (1.8 s es latencia bayesiana).
    4. Factor "/2" oculto en meses de perforación → N_EQUIPOS explícito.
    5. Salida JSON única y atómica, ruta configurable (antes: dos rutas
       fijas y `except: pass` silencioso).
    6. Monte Carlo vectorizado (100 000 iteraciones) con error estándar y
       verificación analítica; se elimina el sorteo único por evento, que
       parecía un resultado retrospectivo y era solo una muestra aleatoria.
    7. Escenario "GAM 2025 proy." (fecha ya vencida) reetiquetado "escenario".
    8. Valoración: B/C y VAN descontados como cifra principal, calendario
       real de reposiciones como contraste, vidas de equilibrio y
       sensibilidades (tasa, VSL×OPEX, vidas, reposición ampliada).
    9. Verificaciones nuevas (no alteran el modelo sellado): saturación de la
       ferrita, área efectiva del núcleo, cobertura del fondo de reemplazos.
   10. Autopruebas de regresión contra las cifras de v6.3/v6.4.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import tempfile
import warnings
from dataclasses import asdict, dataclass, replace
from enum import IntEnum
from math import ceil, comb
from pathlib import Path

import numpy as np

warnings.filterwarnings("ignore")

VERSION = "7.0 CANÓNICA"
SCHEMA = "7.0"
SEED = 2026
ANCHO = 74
MU0 = 4.0e-7 * math.pi
INVENTOR = "Jason Manuel Sarmiento Salazar"
FECHA_DIVULGACION = "2026-09-12"


# ══════════════════════════════════════════════════════════════════════════
#  1. PARÁMETROS
# ══════════════════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class Params:
    # — Sitio y perforación —
    depth_m: float = 600.0
    n_nodos: int = 5
    d_hole_mm: float = 200.0
    d_sonde_mm: float = 168.0
    l_sonde_m: float = 6.0
    rop_m_dia: float = 45.0
    dias_compl: float = 6.0
    n_equipos: int = 2                 # antes: factor "/2" implícito en el print

    # — Enlace ULF —
    f_ulf: float = 2.0
    t_bit: float = 30.0
    mu_r: float = 2000.0
    l_core: float = 4.0
    d_core: float = 0.10
    mu_eff_design: float = 200.0
    rho_fer: float = 4800.0
    rho_cu: float = 1.68e-8
    n_turns: int = 1000
    i_a: float = 20.0
    a_cond_mm2: float = 10.0
    r_bobina_m: float = 0.055          # RADIO de la bobina (antes: "R_COIL")
    duty: float = 0.17
    rej_db: float = 30.0
    b_sat_ferrita_t: float = 0.40      # [H] MnZn a temperatura de pozo; verificar

    # — Térmico —
    t_surf: float = 25.0
    grad_termico: float = 30.0
    derate_pct_per_c: float = 0.004
    mu_min: float = 80.0

    # — Economía —
    contingencia_pct: float = 0.18
    r_disc: float = 0.06
    inflacion: float = 0.035
    years: int = 30
    vsl_usd: float = 1_200_000.0
    vidas_oficial: float = 290.0       # [H] fuente pendiente de citar

    def __post_init__(self) -> None:
        positivos = ("depth_m", "rop_m_dia", "f_ulf", "t_bit", "l_core",
                     "d_core", "mu_eff_design", "i_a", "a_cond_mm2",
                     "r_bobina_m", "vsl_usd", "years", "n_nodos", "n_equipos")
        for nombre in positivos:
            if getattr(self, nombre) <= 0:
                raise ValueError(f"Parámetro '{nombre}' debe ser > 0")
        if not 0 < self.duty <= 1:
            raise ValueError("duty debe estar en (0, 1]")
        if self.r_bobina_m < self.d_core / 2:
            raise ValueError("La bobina no puede ser menor que el núcleo")
        if self.d_sonde_mm >= self.d_hole_mm:
            raise ValueError("La sonda debe caber en el pozo")


P0 = Params()

# Constantes de modelo (no varían en sensibilidades de Params)
SIGMA_REF = 1.2e-4                     # [H] basalto húmedo CR, S/m
PC1_RUIDO = {                          # [H] pT, amplitud Pc1 tras referencia
    "Tranquilo (noche, Kp≤2)": 20.0,
    "Típico diurno": 60.0,
    "Activo (Kp 4–5)": 300.0,
    "Tormenta CME (Kp≥7)": 3000.0,
}
KP_BANDAS = ((0, 2, "Tranquilo", 20.0), (3, 4, "Moderado", 60.0),
             (5, 6, "Activo", 300.0), (7, 9, "Tormenta", 3000.0))
LITOLOGIAS = (("Basalto seco", 5e-5), ("Basalto húmedo CR", 1.2e-4),
              ("Andesita", 3e-4), ("Sedimento", 1e-3),
              ("Falla fluidos", 5e-3), ("Arcilla ácida", 2e-2))
SNR_OBJETIVO_DB = 20.0
MAX_BITS = 64
T_MAX_ULF_S = 15 * 60
REJ_ESTRES_DB = 10.0
GRAD_ESTRES = 55.0

PESO_CABLE = 1.00                      # [H] política de confianza por canal
PESO_ULF_OK = 0.70
PESO_ULF_DEGRADADO = 0.40
PESO_ULF_RECHAZO_DEGRADADO = 0.35      # [H] antes: literal 0.35 sin nombre

SHEAR_K, SHEAR_M0 = 1.937, 7.581       # [H] calibración no documentada
MW_EVENTOS_MAYORES = (6.5, 7.0, 7.5, 7.8)

EFICACIA_REDUCCION = 0.7               # [H] antes: literal 0.7 en dos sitios
FACTOR_PRECURSOR = {"documentado": 1.15, "posible": 1.02, "ninguno": 0.82}

# [H] Latencia y FA son supuestos de diseño, NO resultados calculados.
T_CABLE_S, T_ULF_S, FA_ANUAL = 5.70, 7.30, 0.05

# [H] Modos de falla de nodo: (prob. del evento, eficacia de mitigación).
# Rótulos pendientes: el código heredado no los nombraba.
MODOS_FALLA = (("Modo 1", 0.30, 0.95), ("Modo 2", 0.45, 0.85),
               ("Modo 3", 0.35, 0.92), ("Modo 4", 0.12, 0.98),
               ("Modo 5", 0.20, 0.99))
P_REGIMEN_CORRELACIONADO = 0.08        # [H] fallos correlacionados post-sismo
P_UP_CORRELACIONADO = 0.55             # [H]

CAPEX_BASE = {                         # USD
    "Perforación 5×600m": 550_000,
    "Entubado/cementado": 180_000,
    "DAS (5)": 750_000,
    "SQUID superficie (5)": 350_000,
    "Rb-87 pozo (10)": 200_000,
    "Cable armado (5) PRIMARIO": 60_000,
    "Bobina ULF (5) RESPALDO": 85_000,
    "Radón (5)": 60_000,
    "Presión poros (10)": 60_000,
    "Sondes Ti/PTFE (5)": 140_000,
    "Telecom ICE+LEO": 75_000,
    "Cómputo OVSICORI": 150_000,
    "Gateway CB CNE": 180_000,
    "Ingeniería/comisionado": 200_000,
}
# [H] Desglose sin rótulo en la versión heredada; suma USD 398 000 / año.
OPEX_ANUAL = {"Partida A (rótulo pendiente)": 125_000,
              "Partida B (rótulo pendiente)": 18_000,
              "Partida C (rótulo pendiente)": 18_000,
              "Partida D (rótulo pendiente)": 182_000,
              "Partida E (rótulo pendiente)": 10_000,
              "Partida F (rótulo pendiente)": 25_000,
              "Partida G (rótulo pendiente)": 20_000}
# [H] Vida útil por partida de CAPEX con reposición (años).
VIDA_UTIL = {"DAS (5)": 10.0, "SQUID superficie (5)": 10.0,
             "Rb-87 pozo (10)": 7.5, "Sondes Ti/PTFE (5)": 15.0,
             "Telecom ICE+LEO": 10.0}
# [H] Escenario de contraste: refresco de TI que el modelo sellado omite.
VIDA_UTIL_TI_AMPLIADO = {"Cómputo OVSICORI": 7.0, "Gateway CB CNE": 7.0}


@dataclass(frozen=True)
class Escenario:
    nombre: str
    anio: int | None
    mw: float
    precursor: str
    dano_usd: float
    tipo: str          # "histórico" | "proyección" | "escenario"


ESCENARIOS = (
    Escenario("Limón", 1991, 7.6, "posible", 92e6, "histórico"),
    Escenario("Cinchona", 2009, 6.2, "ninguno", 100e6, "histórico"),
    Escenario("Nicoya", 2012, 7.6, "documentado", 45e6, "histórico"),
    Escenario("GAM", None, 6.5, "posible", 150e6, "escenario"),
    Escenario("Osa", 2035, 7.8, "documentado", 300e6, "proyección"),
)


# ══════════════════════════════════════════════════════════════════════════
#  2. FÍSICA DEL ENLACE ULF
# ══════════════════════════════════════════════════════════════════════════
def skin_depth_m(sigma: float, f_hz: float) -> float:
    """[V] Profundidad pelicular δ = √(2/(ωμ0σ))."""
    return math.sqrt(2.0 / (2.0 * math.pi * f_hz * MU0 * sigma))


def mu_eff_teorica(l_m: float, d_m: float, mu_r: float) -> tuple[float, float]:
    """[V] Permeabilidad efectiva de varilla (factor desmagnetizante de elipsoide)."""
    ld = l_m / d_m
    nd = (math.log(2 * ld) - 1) / ld ** 2
    return mu_r / (1 + nd * (mu_r - 1)), nd


def momento_lineal(mu_eff: float, p: Params) -> float:
    """[V] Momento dipolar en régimen lineal, m = μ_eff·N·I·πr² (A·m²)."""
    return mu_eff * p.n_turns * p.i_a * math.pi * p.r_bobina_m ** 2


def momento_saturado(p: Params) -> float:
    """[V] Tope físico: devanado en aire + núcleo magnetizado a B_sat."""
    v_core = math.pi * (p.d_core / 2) ** 2 * p.l_core
    m_nucleo = (p.b_sat_ferrita_t / MU0) * v_core
    m_devanado = p.n_turns * p.i_a * math.pi * p.r_bobina_m ** 2
    return m_nucleo + m_devanado


def momento_operativo(mu_eff: float, p: Params, sat: bool) -> float:
    m = momento_lineal(mu_eff, p)
    return min(m, momento_saturado(p)) if sat else m


def campo_pT(m: float, p: Params, d: float | None = None,
             sigma: float = SIGMA_REF) -> float:
    """[V] Campo axial de dipolo con atenuación pelicular, en pT."""
    d = p.depth_m if d is None else d
    return (MU0 * m / (2 * math.pi * d ** 3)
            * math.exp(-d / skin_depth_m(sigma, p.f_ulf)) * 1e12)


def snr_db(m: float, pc1_pT: float, p: Params, rej_db: float | None = None,
           d: float | None = None, sigma: float = SIGMA_REF) -> tuple[float, float]:
    """(SNR crudo, SNR procesado) en dB. [H] rechazo Pc1 y ganancia f·T."""
    rej = p.rej_db if rej_db is None else rej_db
    b = campo_pT(m, p, d, sigma)
    eff = pc1_pT / 10 ** (rej / 20)
    raw = 20 * math.log10(b / eff)
    return raw, raw + 10 * math.log10(p.f_ulf * p.t_bit)


def bits_requeridos(snr_proc: float, objetivo: float = SNR_OBJETIVO_DB,
                    max_bits: int = MAX_BITS) -> tuple[int, bool]:
    """Repeticiones de bit para alcanzar el SNR objetivo (forma cerrada)."""
    if snr_proc >= objetivo:
        return 1, True
    n = ceil(10 ** ((objetivo - snr_proc) / 10))
    return (n, True) if n <= max_bits else (max_bits, False)


def temperatura_fondo(grad_c_km: float, p: Params) -> float:
    return p.t_surf + grad_c_km * p.depth_m / 1000.0


def mu_termico(t_c: float, p: Params) -> float:
    """[H] Deriva lineal de μ con la temperatura."""
    return max(p.mu_min, p.mu_eff_design * (1 - p.derate_pct_per_c * max(0.0, t_c - 25.0)))


def potencia_media_w(p: Params) -> float:
    lw = p.n_turns * 2 * math.pi * p.r_bobina_m
    rc = p.rho_cu * lw / (p.a_cond_mm2 * 1e-6)
    return p.i_a ** 2 * rc * p.duty


def p_shear(mw: float) -> float:
    """[H] Probabilidad de cizalla del cable de pozo por magnitud."""
    return 1.0 / (1.0 + math.exp(-SHEAR_K * (mw - SHEAR_M0)))


# ══════════════════════════════════════════════════════════════════════════
#  3. ÁRBOL DE DECISIÓN (sin estado)
# ══════════════════════════════════════════════════════════════════════════
class Fase(IntEnum):
    ARCHIVADO = 0
    AMARILLA = 1
    NARANJA = 2
    PREALERTA = 3
    ROJA = 4


CODIGO_3BIT = {Fase.ARCHIVADO: "001", Fase.AMARILLA: "001", Fase.NARANJA: "010",
               Fase.PREALERTA: "010", Fase.ROJA: "111"}


@dataclass(frozen=True)
class Evento:
    energia: float
    umbral: float
    sensores: int
    nodos_adj: int
    p_bayes: float


@dataclass(frozen=True)
class ConfigArbol:
    p_fase3: float = 0.85
    lat_bayes_s: float = 1.8
    peso_minimo_roja: float = 0.50
    p_override: float = 0.95
    nodos_override: int = 3


@dataclass(frozen=True)
class Decision:
    fase: Fase
    codigo: str
    texto: str
    degradada: bool = False


def evaluar_evento(e: Evento, peso_canal: float = PESO_CABLE,
                   cfg: ConfigArbol = ConfigArbol()) -> Decision:
    """Cascada 0→ROJA. Una ROJA sostenida solo por un canal débil
    (peso < peso_minimo) baja a PREALERTA, salvo consenso fuerte
    (P > p_override y nodos_adj ≥ nodos_override)."""
    if not 0.0 <= e.p_bayes <= 1.0:
        raise ValueError("p_bayes fuera de [0, 1]")
    if not 0.0 <= peso_canal <= 1.0:
        raise ValueError("peso_canal fuera de [0, 1]")

    def dec(f: Fase, txt: str, deg: bool = False) -> Decision:
        return Decision(f, CODIGO_3BIT[f], txt, deg)

    if e.energia <= e.umbral:
        return dec(Fase.ARCHIVADO, "Archivado — ruido local")
    if e.sensores < 3:
        return dec(Fase.AMARILLA, "Amarilla interna — 1-2 sensores")
    if e.nodos_adj < 2:
        return dec(Fase.NARANJA, "Naranja — informe OVSICORI/RSN")
    if e.p_bayes <= cfg.p_fase3:
        return dec(Fase.PREALERTA, f"Pre-alerta — P={e.p_bayes:.2f}")
    override = e.p_bayes > cfg.p_override and e.nodos_adj >= cfg.nodos_override
    if peso_canal < cfg.peso_minimo_roja and not override:
        return dec(Fase.PREALERTA,
                   f"ROJA→pre-alerta: peso_canal={peso_canal:.2f}<"
                   f"{cfg.peso_minimo_roja:.2f} sin consenso fuerte", True)
    return dec(Fase.ROJA,
               f"ROJA — Cell Broadcast (latencia bayesiana {cfg.lat_bayes_s} s)")


CASOS_ARBOL = (
    ("Radón aislado Arenal", 0.0, Evento(1.8, 1.5, 1, 0, 0.12), PESO_CABLE, Fase.AMARILLA),
    ("Anomalía GAM", 5.5, Evento(3.2, 1.5, 3, 1, 0.55), PESO_CABLE, Fase.NARANJA),
    ("Enjambre Osa", 6.2, Evento(5.1, 1.5, 5, 2, 0.78), PESO_CABLE, Fase.PREALERTA),
    ("Dilatancia GAM", 6.5, Evento(7.3, 1.5, 6, 3, 0.92), PESO_CABLE, Fase.ROJA),
    ("Megathrust Osa", 7.5, Evento(9.8, 1.5, 8, 4, 0.97), PESO_CABLE, Fase.ROJA),
)
_E_FUERTE = Evento(9.8, 1.5, 8, 4, 0.97)
_E_DEBIL = Evento(7.3, 1.5, 6, 2, 0.90)
CASOS_GATE = (
    ("Megathrust Osa, cable primario", _E_FUERTE, PESO_CABLE, Fase.ROJA),
    ("Megathrust Osa, solo ULF degradado, consenso fuerte", _E_FUERTE,
     PESO_ULF_DEGRADADO, Fase.ROJA),
    ("Evento menor, solo ULF degradado, sin consenso fuerte", _E_DEBIL,
     PESO_ULF_DEGRADADO, Fase.PREALERTA),
)


# ══════════════════════════════════════════════════════════════════════════
#  4. DETECCIÓN, DAÑOS Y RED
# ══════════════════════════════════════════════════════════════════════════
def prob_deteccion(mw: float, precursor: str) -> float:
    """[H] Pd heurística por magnitud y calidad del precursor."""
    base = (0.55 if mw < 6 else 0.60 if mw < 6.5 else 0.72 if mw < 7
            else 0.85 if mw < 7.5 else 0.92)
    return min(0.95, base * FACTOR_PRECURSOR[precursor])


def aviso_horas(mw: float) -> int:
    """[H] Horas de aviso por magnitud."""
    return 6 if mw < 6 else 18 if mw < 6.5 else 36 if mw < 7 else 60 if mw < 7.5 else 96


def fraccion_reducible(h: float) -> float:
    """[H] Fracción de daño evitable según horas de aviso."""
    return 0.20 if h <= 6 else 0.45 if h <= 24 else 0.70 if h <= 48 else 0.80


def deteccion_analitica(escenarios=ESCENARIOS) -> list[dict]:
    filas = []
    for s in escenarios:
        pd = prob_deteccion(s.mw, s.precursor)
        h = aviso_horas(s.mw)
        ahorro_si = s.dano_usd * fraccion_reducible(h) * EFICACIA_REDUCCION
        filas.append(dict(nombre=s.nombre, anio=s.anio, tipo=s.tipo, mw=s.mw,
                          precursor=s.precursor, pd=pd, aviso_h=h,
                          ahorro_si_detecta_musd=ahorro_si / 1e6,
                          ahorro_esperado_musd=pd * ahorro_si / 1e6))
    return filas


def deteccion_mc(rng: np.random.Generator, n: int, escenarios=ESCENARIOS) -> dict:
    pd = np.array([prob_deteccion(s.mw, s.precursor) for s in escenarios])
    ah = np.array([s.dano_usd * fraccion_reducible(aviso_horas(s.mw))
                   * EFICACIA_REDUCCION for s in escenarios]) / 1e6
    det = rng.random((n, len(escenarios))) < pd
    ahorro = (det * ah).sum(axis=1)
    fn = (~det).sum(axis=1)
    return dict(n=n, ahorro_medio_musd=float(ahorro.mean()),
                ahorro_se_musd=float(ahorro.std(ddof=1) / math.sqrt(n)),
                ahorro_p5_musd=float(np.percentile(ahorro, 5)),
                ahorro_p95_musd=float(np.percentile(ahorro, 95)),
                fn_medio=float(fn.mean()), n_eventos=len(escenarios))


def disponibilidad_nodo(modos=MODOS_FALLA) -> float:
    p_up = 1.0
    for _, p_ev, efic in modos:
        p_up *= 1 - p_ev * (1 - efic)
    return p_up


def p_min_k_analitica(n: int, k: int, q: float) -> float:
    return sum(comb(n, j) * q ** j * (1 - q) ** (n - j) for j in range(k, n + 1))


def red_analitica(p: Params, p_up: float, k: int = 3) -> float:
    return ((1 - P_REGIMEN_CORRELACIONADO) * p_min_k_analitica(p.n_nodos, k, p_up)
            + P_REGIMEN_CORRELACIONADO * p_min_k_analitica(p.n_nodos, k, P_UP_CORRELACIONADO))


def red_mc(rng: np.random.Generator, n: int, p: Params, p_up: float, k: int = 3) -> dict:
    q = np.where(rng.random(n) < P_REGIMEN_CORRELACIONADO, P_UP_CORRELACIONADO, p_up)
    activos = rng.binomial(p.n_nodos, q)
    frac = float((activos >= k).mean())
    return dict(n=n, p_min_k=frac, se=math.sqrt(frac * (1 - frac) / n))


# ══════════════════════════════════════════════════════════════════════════
#  5. ECONOMÍA
# ══════════════════════════════════════════════════════════════════════════
def ciclos_reemplazo(vida_anos: float, horizonte: int = 30) -> int:
    """[V] Compras de reposición dentro del horizonte (ceil, no int)."""
    if vida_anos <= 0:
        raise ValueError("vida_anos debe ser > 0")
    return max(0, ceil(horizonte / vida_anos) - 1)


def calendario_reemplazos(vidas: dict[str, float], horizonte: int) -> list[tuple[float, str, float]]:
    """[(año, partida, USD)] — reposiciones en su año real."""
    cal = []
    for partida, vida in vidas.items():
        for k in range(1, ciclos_reemplazo(vida, horizonte) + 1):
            cal.append((k * vida, partida, float(CAPEX_BASE[partida])))
    return sorted(cal)


def factor_anualidad(r: float, n: int) -> float:
    return sum(1 / (1 + r) ** t for t in range(1, n + 1))


def valorar(p: Params, capex_t: float, opex1: float, calendario: list,
            *, vsl: float | None = None, vidas: float | None = None,
            r: float | None = None, opex_factor: float = 1.0) -> dict:
    vsl = p.vsl_usd if vsl is None else vsl
    vidas = p.vidas_oficial if vidas is None else vidas
    r = p.r_disc if r is None else r
    n = p.years
    reemplazos = sum(m for _, _, m in calendario)
    opex_t = [opex1 * opex_factor * (1 + p.inflacion) ** (t - 1) for t in range(1, n + 1)]
    opex_30 = sum(opex_t)
    total_30 = capex_t + opex_30 + reemplazos
    benef_a = vidas * vsl / n
    af = factor_anualidad(r, n)
    pvb = benef_a * af
    # Convención sellada: reemplazos prorrateados en partes iguales
    pvc = capex_t + sum((opex_t[t - 1] + reemplazos / n) / (1 + r) ** t
                        for t in range(1, n + 1))
    # Contraste: cada reposición en su año real
    pvc_cal = (capex_t + sum(o / (1 + r) ** t for t, o in enumerate(opex_t, 1))
               + sum(m / (1 + r) ** a for a, _, m in calendario))
    return dict(opex_30=opex_30, reemplazos=reemplazos, total_30=total_30,
                benef_anual=benef_a, bc_simple=vidas * vsl / total_30,
                pvb=pvb, pvc=pvc, van=pvb - pvc, bc_desc=pvb / pvc,
                pvc_cal=pvc_cal, van_cal=pvb - pvc_cal, bc_desc_cal=pvb / pvc_cal,
                vidas_equilibrio_desc=pvc * n / (vsl * af),
                vidas_equilibrio_simple=total_30 / vsl)


# ══════════════════════════════════════════════════════════════════════════
#  6. CÁLCULO DE ENLACE (modo lineal o con saturación)
# ══════════════════════════════════════════════════════════════════════════
def calcular_enlace(p: Params, sat: bool) -> dict:
    mu_th, nd = mu_eff_teorica(p.l_core, p.d_core, p.mu_r)
    m_ref = momento_operativo(p.mu_eff_design, p, sat)
    b_ref = campo_pT(m_ref, p)
    snr_pc1 = {c: snr_db(m_ref, v, p)[1] for c, v in PC1_RUIDO.items()}
    snr_tip = snr_pc1["Típico diurno"]

    kp = []
    for k0, k1, nombre, pc1 in KP_BANDAS:
        proc = snr_db(m_ref, pc1, p)[1]
        nbit, ok = bits_requeridos(proc)
        kp.append(dict(kp=f"{k0}–{k1}", nombre=nombre, pc1_pT=pc1, snr_dB=proc,
                       bits=nbit, t_tx_s=nbit * p.t_bit, alcanzado=ok,
                       snr_eff_dB=proc + 10 * math.log10(nbit)))
    tormenta = kp[-1]
    t_storm = tormenta["t_tx_s"]
    peso_storm = PESO_ULF_OK if t_storm <= T_MAX_ULF_S else PESO_ULF_DEGRADADO

    snr_estres = snr_db(m_ref, 60.0, p, rej_db=REJ_ESTRES_DB)[1]
    t_an = temperatura_fondo(GRAD_ESTRES, p)
    mu_an = mu_termico(t_an, p)
    snr_an = snr_db(momento_operativo(mu_an, p, sat), 60.0, p)[1]

    t_pozo = temperatura_fondo(p.grad_termico, p)
    mu_T = mu_termico(t_pozo, p)
    snr_T = snr_db(momento_operativo(mu_T, p, sat), 60.0, p)[1]

    lito = [dict(nombre=n, sigma=s, snr_dB=snr_db(m_ref, 60.0, p, sigma=s)[1])
            for n, s in LITOLOGIAS]

    termico = []
    for g in range(20, 61, 5):
        tf = temperatura_fondo(g, p)
        mf = mu_termico(tf, p)
        termico.append(dict(grad=g, t_fondo=tf, mu_T=mf,
                            snr_dB=snr_db(momento_operativo(mf, p, sat), 60.0, p)[1]))

    majors = [p_shear(m) for m in MW_EVENTOS_MAYORES]
    return dict(
        modo="con_saturacion" if sat else "lineal",
        mu_teorica=mu_th, nd=nd, m_ref=m_ref, b_ref_pT=b_ref,
        margen_fabrica_dB=20 * math.log10(mu_th / p.mu_eff_design),
        snr_por_pc1=snr_pc1, snr_tipico_dB=snr_tip, kp=kp,
        tormenta=dict(nbit=tormenta["bits"], t_tx_s=t_storm,
                      majority_ok=3 * t_storm <= T_MAX_ULF_S, peso_canal=peso_storm),
        estres=dict(rej_db=REJ_ESTRES_DB, snr_dB=snr_estres,
                    peso_canal=PESO_ULF_RECHAZO_DEGRADADO,
                    grad=GRAD_ESTRES, t_fondo=t_an, mu_T=mu_an, snr_geo_dB=snr_an),
        t_pozo=t_pozo, mu_T=mu_T, snr_Tpozo_dB=snr_T,
        litologias=lito, snr_peor_lito_dB=min(x["snr_dB"] for x in lito),
        termico=termico,
        shear=dict(por_mw={m: p_shear(m) for m in (6.0, 6.5, 7.0, 7.5, 7.8, 8.0)},
                   p_ulf_necesario=float(np.mean(majors))),
    )


def verificaciones(p: Params) -> dict:
    """Comprobaciones NUEVAS que no alteran el modelo sellado."""
    mu_th, _ = mu_eff_teorica(p.l_core, p.d_core, p.mu_r)
    m_lin = momento_lineal(p.mu_eff_design, p)
    m_sat = momento_saturado(p)
    h_lin = p.n_turns * p.i_a / p.l_core                        # A/m
    b_lin = MU0 * p.mu_eff_design * h_lin                       # T en el núcleo
    ms = p.b_sat_ferrita_t / MU0
    i_sat = ms * p.l_core / ((p.mu_eff_design - 1) * p.n_turns)  # A
    a_core = math.pi * (p.d_core / 2) ** 2
    a_coil = math.pi * p.r_bobina_m ** 2
    m_area = p.n_turns * p.i_a * (a_coil + (p.mu_eff_design - 1) * a_core)
    barrido = {}
    for b in (0.35, 0.45, 0.55):
        pb = replace(p, b_sat_ferrita_t=b)
        barrido[f"{b:.2f}"] = dict(
            razon=m_lin / momento_saturado(pb),
            perdida_dB=20 * math.log10(m_lin / momento_saturado(pb)),
            snr_tipico_dB=snr_db(momento_saturado(pb), 60.0, p)[1])
    return dict(
        saturacion=dict(
            b_nucleo_lineal_T=b_lin, b_sat_T=p.b_sat_ferrita_t,
            excede=b_lin > p.b_sat_ferrita_t, m_lineal=m_lin, m_saturado=m_sat,
            razon=m_lin / m_sat, perdida_dB=20 * math.log10(m_lin / m_sat),
            corriente_saturacion_A=i_sat,
            potencia_a_i_sat_W=potencia_media_w(replace(p, i_a=i_sat)),
            barrido_bsat=barrido),
        area_nucleo=dict(m_corregido=m_area, razon=m_area / m_lin,
                         correccion_dB=20 * math.log10(m_area / m_lin)),
        mu_teorica_sobre_diseno=mu_th / p.mu_eff_design)


# ══════════════════════════════════════════════════════════════════════════
#  7. SIMULACIÓN COMPLETA (sin imprimir)
# ══════════════════════════════════════════════════════════════════════════
def simular(p: Params = P0, seed: int = SEED, saturacion: bool = False,
            n_mc: int = 100_000) -> dict:
    ss = np.random.SeedSequence(seed)
    rng_det, rng_red = (np.random.default_rng(s) for s in ss.spawn(2))

    dias_pozo = p.depth_m / p.rop_m_dia
    dias_nodo = dias_pozo + p.dias_compl
    meses_red = dias_nodo * p.n_nodos / p.n_equipos / 30
    m_fer = p.rho_fer * math.pi * (p.d_core / 2) ** 2 * p.l_core

    enlace_lin = calcular_enlace(p, False)
    enlace_sat = calcular_enlace(p, True)
    principal = enlace_sat if saturacion else enlace_lin

    # Costos
    sub = sum(CAPEX_BASE.values())
    cont = int(round(sub * p.contingencia_pct))
    capex_t = sub + cont
    opex1 = sum(OPEX_ANUAL.values())
    cal = calendario_reemplazos(VIDA_UTIL, p.years)
    cal_amp = calendario_reemplazos({**VIDA_UTIL, **VIDA_UTIL_TI_AMPLIADO}, p.years)
    val = valorar(p, capex_t, opex1, cal)
    val_amp = valorar(p, capex_t, opex1, cal_amp)

    sens_r = {f"{r:.2f}": {k: valorar(p, capex_t, opex1, cal, r=r)[k]
                           for k in ("van", "bc_desc")} for r in (0.03, 0.06, 0.08, 0.12)}
    sens_vsl_opex = {}
    for vsl in (800_000, 1_200_000, 1_800_000):
        for f in (0.8, 1.0, 1.4):
            sens_vsl_opex[f"vsl{vsl // 1000}k_opex{int(f * 100)}"] = \
                valorar(p, capex_t, opex1, cal, vsl=vsl, opex_factor=f)["bc_desc"]
    sens_vidas = {str(v): valorar(p, capex_t, opex1, cal, vidas=v)["bc_desc"]
                  for v in (25, 50, 100, 290)}

    # Detección y red
    det_an = deteccion_analitica()
    det_mc = deteccion_mc(rng_det, n_mc)
    det_an_total = sum(f["ahorro_esperado_musd"] for f in det_an)
    p_up = disponibilidad_nodo()
    p3_an = red_analitica(p, p_up)
    p3_mc = red_mc(rng_red, n_mc, p, p_up)

    arbol = [dict(nombre=n, mw=mw, peso=peso, esperado=int(exp),
                  **_dec_dict(evaluar_evento(ev, peso)))
             for n, mw, ev, peso, exp in CASOS_ARBOL]
    gate = [dict(etiqueta=et, peso=peso, esperado=int(exp),
                 **_dec_dict(evaluar_evento(ev, peso)))
            for et, ev, peso, exp in CASOS_GATE]

    ver = verificaciones(p)
    res = dict(
        schema=SCHEMA, version=VERSION, inventor=INVENTOR,
        fecha_divulgacion=FECHA_DIVULGACION, semilla=seed,
        modo_principal=principal["modo"],
        parametros=asdict(p),
        despliegue=dict(dias_pozo=dias_pozo, dias_nodo=dias_nodo,
                        meses_red=meses_red, n_equipos=p.n_equipos, masa_ferrita_kg=m_fer),
        potencia_media_W=potencia_media_w(p),
        enlace_principal=principal, enlace_lineal=enlace_lin, enlace_saturado=enlace_sat,
        arbol=arbol, gate_canal=gate,
        deteccion=dict(por_escenario=det_an, ahorro_esperado_musd=det_an_total, mc=det_mc),
        costos=dict(capex_subtotal=sub, contingencia=cont, capex=capex_t,
                    capex_partidas=dict(CAPEX_BASE), opex_partidas=dict(OPEX_ANUAL),
                    vida_util=dict(VIDA_UTIL), opex_anual=opex1, **val,
                    calendario=[dict(anio=a, partida=n, usd=m) for a, n, m in cal],
                    cobertura_reemplazos=dict(
                        partidas_con_reposicion=len(VIDA_UTIL),
                        partidas_capex=len(CAPEX_BASE),
                        escenario_ti_ampliado=dict(
                            reemplazos=val_amp["reemplazos"], van=val_amp["van"],
                            bc_desc=val_amp["bc_desc"]))),
        sensibilidad=dict(tasa_descuento=sens_r, vsl_x_opex_bc_desc=sens_vsl_opex,
                          vidas_bc_desc=sens_vidas),
        red=dict(disp_nodo=p_up, p_min3_analitica=p3_an, p_min3_mc=p3_mc),
        latencia=dict(cable_s=T_CABLE_S, ulf_s=T_ULF_S, fa_anual=FA_ANUAL,
                      nota="Supuestos de diseño [H], no calculados por este modelo"),
        verificaciones=ver,
    )
    res["hallazgos"] = construir_hallazgos(p, res)
    res["supuestos"] = SUPUESTOS
    return res


def _dec_dict(d: Decision) -> dict:
    return dict(fase=int(d.fase), fase_nombre=d.fase.name, codigo=d.codigo,
                texto=d.texto, degradada=d.degradada)


SUPUESTOS = [
    dict(id="H01", tag="H", tema="Rechazo de ruido Pc1 = 30 dB (referencia remota)",
         impacto="A 10 dB el SNR típico cae a ~23 dB"),
    dict(id="H02", tag="H", tema="Ganancia de integración 10·log10(f·T) usa la frecuencia de portadora como ancho de banda de ruido",
         impacto="Define 17.8 dB del SNR procesado"),
    dict(id="H03", tag="H", tema="μ_eff de diseño = 200 (teórico ≈ 383)",
         impacto="Borrador de patente usa μ_eff≈150"),
    dict(id="H04", tag="H", tema="B_sat de la ferrita = 0.40 T (verificar con hoja de datos)",
         impacto="Ver hallazgo de saturación"),
    dict(id="H05", tag="H", tema="Pd, horas de aviso, fracción reducible y eficacia 0.7 no están validadas con datos",
         impacto="Determina el ahorro por daños evitados"),
    dict(id="H06", tag="H", tema="Daños de cada escenario sísmico (USD)", impacto="Ahorro por daños"),
    dict(id="H07", tag="H", tema="Vidas evitadas en 30 años = 290 (fuente pendiente)",
         impacto="Único motor del B/C; ver vidas de equilibrio"),
    dict(id="H08", tag="H", tema="VSL = USD 1.2 M", impacto="B/C proporcional"),
    dict(id="H09", tag="H", tema="OPEX anual USD 398 k sin desglose rotulado", impacto="≈ 60 % del costo a 30 años"),
    dict(id="H10", tag="H", tema="Vidas útiles: Rb-87 7.5 a, sondas 15 a, DAS/SQUID/telecom 10 a",
         impacto="Fondo de reemplazos"),
    dict(id="H11", tag="H", tema="Tasa de descuento 6 %, inflación 3.5 %", impacto="Confirmar tasa social oficial"),
    dict(id="H12", tag="H", tema="Modos de falla de nodo y régimen correlacionado 8 % / 0.55", impacto="Disponibilidad de red"),
    dict(id="H13", tag="H", tema="P(cizalla): k=1.937, M0=7.581; calibración no documentada", impacto="P(ULF necesario)"),
    dict(id="H14", tag="H", tema="Latencias 5.7/7.3 s y falsas alarmas 0.05/año son constantes, no cálculos", impacto="KPIs de servicio"),
    dict(id="H15", tag="H", tema="Pesos de canal 1.00 / 0.70 / 0.40 / 0.35 (política de decisión)", impacto="Gate 111→010"),
    dict(id="H16", tag="H", tema="σ basalto húmedo 1.2e-4 S/m", impacto="Atenuación (≤ 2 dB en todo el rango)"),
    dict(id="V01", tag="V", tema="Profundidad pelicular, campo de dipolo, μ_eff de varilla, ceil() en reposiciones, valor presente",
         impacto="Fórmulas estándar"),
]


def construir_hallazgos(p: Params, r: dict) -> list[dict]:
    v = r["verificaciones"]
    s, a = v["saturacion"], v["area_nucleo"]
    c = r["costos"]
    lin, sat = r["enlace_lineal"], r["enlace_saturado"]
    return [
        dict(id="F1", severidad="ALTO", titulo="La ferrita satura por debajo de la corriente de diseño",
             detalle=(f"Con μ_eff={p.mu_eff_design:.0f}, N={p.n_turns}, I={p.i_a:.0f} A el núcleo "
                      f"necesitaría {s['b_nucleo_lineal_T']:.2f} T; la ferrita MnZn satura cerca de "
                      f"{s['b_sat_T']:.2f} T (H04). Momento tope {s['m_saturado']:.3e} vs "
                      f"{s['m_lineal']:.3e} A·m² lineal: −{s['perdida_dB']:.1f} dB. SNR típico "
                      f"{lin['snr_tipico_dB']:.1f}→{sat['snr_tipico_dB']:.1f} dB; con rechazo de 10 dB "
                      f"{lin['estres']['snr_dB']:.1f}→{sat['estres']['snr_dB']:.1f} dB. Por encima de "
                      f"~{s['corriente_saturacion_A']:.1f} A más corriente no aumenta el momento."),
             accion="Validar B_sat con el fabricante; rediseñar núcleo (volumen o material) o fijar I≈7 A."),
        dict(id="F2", severidad="ALTO", titulo="El B/C depende de un único supuesto exógeno",
             detalle=(f"El beneficio es vidas×VSL con vidas={p.vidas_oficial:.0f} (H07), sin relación con "
                      f"la detección modelada. Vidas de equilibrio: {c['vidas_equilibrio_desc']:.0f} "
                      f"(descontado) / {c['vidas_equilibrio_simple']:.0f} (sin descontar)."),
             accion="Citar la fuente de las 290 vidas y presentar el umbral de equilibrio."),
        dict(id="F3", severidad="ALTO", titulo="La eficacia de detección no está validada",
             detalle="Pd, horas de aviso y fracción reducible (H05) son heurísticas. Ningún método "
                     "de precursores tiene hoy eficacia demostrada de predicción a corto plazo.",
             accion="Presentar como hipótesis a validar con red piloto y métricas de aceptación."),
        dict(id="F4", severidad="MEDIO", titulo="Fondo de reemplazos parcial",
             detalle=(f"Repone {c['cobertura_reemplazos']['partidas_con_reposicion']} de "
                      f"{c['cobertura_reemplazos']['partidas_capex']} partidas de CAPEX. Con refresco de TI "
                      f"cada 7 años (H): reemplazos USD {c['cobertura_reemplazos']['escenario_ti_ampliado']['reemplazos']:,.0f}, "
                      f"B/C descontado {c['cobertura_reemplazos']['escenario_ti_ampliado']['bc_desc']:.1f}:1."),
             accion="Confirmar si el OPEX ya incluye el refresco de TI."),
        dict(id="F5", severidad="MEDIO", titulo="OPEX sin desglose rotulado",
             detalle=f"USD {c['opex_anual']:,.0f}/año en 7 partidas sin nombre (H09).",
             accion="Rotular las partidas antes de presentar a Hacienda/MIDEPLAN."),
        dict(id="F6", severidad="MEDIO", titulo="Latencia y falsas alarmas son constantes",
             detalle="5.7 s / 7.3 s y 0.05 FA/año se imprimían como resultados; son supuestos (H14).",
             accion="Sustituir por presupuesto de latencia medido y tasa de FA de la red piloto."),
        dict(id="F7", severidad="BAJO", titulo="Área del momento dipolar",
             detalle=(f"El modelo usa el área de la bobina para todo el momento; con el área real del "
                      f"núcleo el momento baja {abs(a['correccion_dB']):.1f} dB."),
             accion="Documentar; conservar el valor sellado hasta decidir."),
    ]


# ══════════════════════════════════════════════════════════════════════════
#  8. SALIDA
# ══════════════════════════════════════════════════════════════════════════
def guardar_json(res: dict, ruta: Path) -> Path:
    """Escritura atómica; los errores se propagan (no se silencian)."""
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=ruta.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(res, f, indent=2, ensure_ascii=False, default=_json_default)
        os.replace(tmp, ruta)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return ruta


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, IntEnum):
        return int(o)
    raise TypeError(f"No serializable: {type(o)}")


def _est(snr: float) -> str:
    return "✓" if snr >= 20 else ("⚠" if snr >= 10 else "⛔")


def imprimir(res: dict, p: Params) -> None:
    L = "═" * ANCHO
    R = "─" * ANCHO
    e = res["enlace_principal"]
    lin, sat = res["enlace_lineal"], res["enlace_saturado"]
    c, d, v = res["costos"], res["despliegue"], res["verificaciones"]
    print(L)
    print(f" GEO-PROBE CR — v{VERSION}")
    print(f" {INVENTOR} · semilla {res['semilla']} · modo: {e['modo']}")
    print(L)

    print(f"\n[A] DESPLIEGUE — PERFORACIÓN CONVENCIONAL\n")
    print(f"  Pozo Ø{p.d_hole_mm:.0f} mm × {p.depth_m:.0f} m · Sonde Ø{p.d_sonde_mm:.0f} mm × {p.l_sonde_m} m")
    print(f"  ROP {p.rop_m_dia:.0f} m/día · {d['dias_nodo']:.1f} d/nodo · {p.n_nodos} nodos con "
          f"{p.n_equipos} equipos: {d['meses_red']:.1f} meses · Reactor ELIMINADO")

    print(f"\n{R}\n[B] ENLACE ULF — μ diseño={p.mu_eff_design:.0f}\n")
    print(f"  μ_th={e['mu_teorica']:.0f} · Nd={e['nd']:.5f} · masa={d['masa_ferrita_kg']:.0f} kg · "
          f"m={e['m_ref']:.3e} A·m² · B={e['b_ref_pT']:.1f} pT")
    print(f"  Margen de fábrica: {e['margen_fabrica_dB']:.1f} dB · Potencia media: {res['potencia_media_W']:.0f} W")

    print(f"\n  [B1] SNR vs Pc1 (rechazo {p.rej_db:.0f} dB)")
    for cond, pc1 in PC1_RUIDO.items():
        s_ = e["snr_por_pc1"][cond]
        print(f"    {cond:<26} {pc1:>6.0f} pT  SNR={s_:5.1f} dB {_est(s_)}")

    print(f"\n  [B2] Protocolo Kp adaptativo")
    for k in e["kp"]:
        print(f"    Kp {k['kp']:<4} {k['nombre']:<10} bits={k['bits']:>2}  "
              f"T_tx={k['t_tx_s']:>5.0f}s  SNReff={k['snr_eff_dB']:5.1f} dB")

    t = e["tormenta"]
    print(f"\n  [B3] Correcciones de canal · T_max ULF={T_MAX_ULF_S / 60:.0f} min")
    print(f"    Tormenta: nbit={t['nbit']} T_tx={t['t_tx_s']:.0f}s · "
          f"mayoría 2-de-3 {'✓' if t['majority_ok'] else '✗ (excede T_max)'} · "
          f"resuelve a peso_canal={t['peso_canal']:.2f}")
    print(f"    Pesos de referencia: cable={PESO_CABLE:.2f} | ULF a tiempo={PESO_ULF_OK:.2f} | "
          f"ULF degradado={PESO_ULF_DEGRADADO:.2f} | rechazo degradado={PESO_ULF_RECHAZO_DEGRADADO:.2f}")

    es = e["estres"]
    print(f"\n  [B4] Estrés")
    print(f"    Rechazo {p.rej_db:.0f}→{es['rej_db']:.0f} dB: SNR diurno={es['snr_dB']:.1f} dB {_est(es['snr_dB'])} · "
          f"peso_canal={es['peso_canal']:.2f} → ROJA bloqueada")
    print(f"    Gradiente {es['grad']:.0f}°C/km: T_fondo={es['t_fondo']:.0f}°C · μ_T={es['mu_T']:.0f} · "
          f"SNR={es['snr_geo_dB']:.1f} dB {_est(es['snr_geo_dB'])}")

    print(f"\n  [B5] Litologías (Pc1 típico)")
    for x in e["litologias"]:
        print(f"    {x['nombre']:<22} σ={x['sigma']:.1e}  SNR={x['snr_dB']:5.1f} dB")
    print(f"\n  [B6] T@{p.depth_m:.0f}m={e['t_pozo']:.0f}°C · μ_T={e['mu_T']:.0f} · SNR@T={e['snr_Tpozo_dB']:.1f} dB")

    print(f"\n  [B7] P(cizalla) k={SHEAR_K} M0={SHEAR_M0}")
    for mw, ps in e["shear"]["por_mw"].items():
        modo = "cable OK" if ps < 0.15 else ("mixto" if ps <= 0.35 else "ULF probable")
        print(f"    Mw {mw:.1f}  P={ps * 100:5.1f}%  {modo}")
    print(f"  → P(ULF necesario): {e['shear']['p_ulf_necesario'] * 100:.0f}%")

    print(f"\n  [B8] Perfil térmico (SCADA)")
    print(f"  {'Grad °C/km':>12} {'T_fondo':>9} {'μ_T':>7} {'SNR dB':>8}  perfil (20–45 dB)")
    for x in e["termico"]:
        n = max(0, min(30, int((x["snr_dB"] - 20) / 25 * 30)))
        print(f"  {x['grad']:>12} {x['t_fondo']:>9.1f} {x['mu_T']:>7.1f} {x['snr_dB']:>8.1f}  "
              f"{'█' * n}{'░' * (30 - n)}")

    sa = v["saturacion"]
    print(f"\n  [B9] VERIFICACIÓN DE SATURACIÓN (nueva, no altera el modelo sellado)\n")
    print(f"    B en núcleo (lineal)={sa['b_nucleo_lineal_T']:.2f} T · B_sat={sa['b_sat_T']:.2f} T · "
          f"{'EXCEDE' if sa['excede'] else 'dentro de rango'}")
    print(f"    m lineal={sa['m_lineal']:.3e} · m saturado={sa['m_saturado']:.3e} A·m² "
          f"(−{sa['perdida_dB']:.1f} dB) · I de saturación ≈ {sa['corriente_saturacion_A']:.1f} A")
    print(f"    {'Indicador':<28} {'Lineal':>9} {'Saturado':>9}")
    for et, a_, b_ in (("SNR típico (dB)", lin["snr_tipico_dB"], sat["snr_tipico_dB"]),
                       ("SNR @T pozo (dB)", lin["snr_Tpozo_dB"], sat["snr_Tpozo_dB"]),
                       ("SNR peor litología (dB)", lin["snr_peor_lito_dB"], sat["snr_peor_lito_dB"]),
                       ("SNR rechazo 10 dB (dB)", lin["estres"]["snr_dB"], sat["estres"]["snr_dB"]),
                       ("SNR geotermia 55 °C/km (dB)", lin["estres"]["snr_geo_dB"], sat["estres"]["snr_geo_dB"])):
        print(f"    {et:<28} {a_:>9.1f} {b_:>9.1f}")
    print(f"    Sensibilidad a B_sat: " + " · ".join(
        f"{k} T → −{x['perdida_dB']:.1f} dB" for k, x in sa["barrido_bsat"].items()))

    print(f"\n{R}\n[C] ÁRBOL DE DECISIÓN (fases 1-4; ROJA = código 111)\n")
    for x in res["arbol"]:
        ic = "🔴" if x["codigo"] == "111" else ("🟠" if x["codigo"] == "010" else "🟡")
        print(f"  {x['nombre']:<24} M{x['mw']:.1f}  {x['fase_nombre']:<9} {x['codigo']} {ic} {x['texto']}")
    print(f"\n  [C2] Gate de canal — mismo evento, distinto canal\n")
    for x in res["gate_canal"]:
        print(f"    peso={x['peso']:.2f}  {x['etiqueta']:<52} → {x['codigo']}  {x['texto']}")

    dt = res["deteccion"]
    print(f"\n{R}\n[D] DETECCIÓN Y DAÑOS EVITADOS (supuestos H05/H06, no validados)\n")
    print(f"  {'Escenario':<14} {'Tipo':<11} {'Mw':>4} {'Pd':>5} {'Aviso':>6} {'Ahorro esp.':>12}")
    for f in dt["por_escenario"]:
        yr = f["anio"] if f["anio"] else "—"
        print(f"  {f['nombre'] + ' ' + str(yr):<14} {f['tipo']:<11} {f['mw']:>4.1f} {f['pd']:>5.2f} "
              f"{f['aviso_h']:>5}h ${f['ahorro_esperado_musd']:>9.1f}M")
    m = dt["mc"]
    print(f"  Analítico: ${dt['ahorro_esperado_musd']:.1f}M · MC({m['n']:,}): ${m['ahorro_medio_musd']:.1f}M "
          f"± {m['ahorro_se_musd']:.2f} (P5–P95: {m['ahorro_p5_musd']:.0f}–{m['ahorro_p95_musd']:.0f}) · "
          f"FN medio {m['fn_medio']:.2f}/{m['n_eventos']}")

    print(f"\n{R}\n[E] COSTOS\n")
    print(f"  CAPEX ${c['capex']:,} (subtotal ${c['capex_subtotal']:,} + contingencia "
          f"{p.contingencia_pct * 100:.0f}% ${c['contingencia']:,})")
    print(f"  OPEX/año ${c['opex_anual']:,} · OPEX 30a ${c['opex_30']:,.0f}")
    print(f"  Reemplazos derivados [V]: ${c['reemplazos']:,.0f} "
          f"({c['cobertura_reemplazos']['partidas_con_reposicion']}/{c['cobertura_reemplazos']['partidas_capex']} partidas)")
    print(f"  Total 30a ${c['total_30']:,.0f}")

    print(f"\n[F] VALORACIÓN (r={p.r_disc * 100:.0f}%, {p.years} años, {p.vidas_oficial:.0f} vidas × "
          f"VSL ${p.vsl_usd / 1e6:.1f}M)\n")
    print(f"  B/C descontado {c['bc_desc']:.1f}:1 · VAN ${c['van'] / 1e6:.0f}M · "
          f"B/C sin descontar {c['bc_simple']:.1f}:1")
    print(f"  Contraste (reposiciones en su año): VAN ${c['van_cal'] / 1e6:.0f}M · "
          f"B/C {c['bc_desc_cal']:.1f}:1")
    print(f"  Vidas de equilibrio (B/C=1): {c['vidas_equilibrio_desc']:.0f} descontado · "
          f"{c['vidas_equilibrio_simple']:.0f} sin descontar")
    sr = res["sensibilidad"]["tasa_descuento"]
    print("  Tasa de descuento: " + " · ".join(f"{float(k) * 100:.0f}% → VAN ${x['van'] / 1e6:.0f}M, "
                                               f"B/C {x['bc_desc']:.1f}" for k, x in sr.items()))
    sv = res["sensibilidad"]["vidas_bc_desc"]
    print("  Vidas evitadas: " + " · ".join(f"{k} → B/C {x:.1f}" for k, x in sv.items()))
    print(f"  {'VSL \\ OPEX':<12}" + "".join(f"{int(f * 100):>8}%" for f in (0.8, 1.0, 1.4)))
    for vsl in (800, 1200, 1800):
        fila = "".join(f"{res['sensibilidad']['vsl_x_opex_bc_desc'][f'vsl{vsl}k_opex{int(f * 100)}']:>9.1f}"
                       for f in (0.8, 1.0, 1.4))
        print(f"  ${vsl / 1000:.1f}M{'':<7}{fila}")

    rd = res["red"]
    print(f"\n[G] RED · disponibilidad de nodo {rd['disp_nodo'] * 100:.1f}% · P(≥3 nodos) "
          f"analítica {rd['p_min3_analitica'] * 100:.1f}% · MC {rd['p_min3_mc']['p_min_k'] * 100:.1f}% "
          f"± {rd['p_min3_mc']['se'] * 100:.2f}")
    lt = res["latencia"]
    print(f"[H] SERVICIO (supuestos) · latencia {lt['cable_s']:.1f} s cable / {lt['ulf_s']:.1f} s ULF · "
          f"FA {lt['fa_anual']:.2f}/año")

    print(f"\n{R}\n[I] HALLAZGOS DE AUDITORÍA\n")
    for h in res["hallazgos"]:
        print(f"  [{h['id']}] {h['severidad']:<8} {h['titulo']}")
        print(f"        {h['detalle']}")
        print(f"        → {h['accion']}")

    print(f"\n{L}\n DIAGNÓSTICO — GEO-PROBE CR v{VERSION}\n")
    filas = [
        ("Pozo", f"Ø{p.d_hole_mm:.0f} mm × {p.depth_m:.0f} m · {d['dias_nodo']:.0f} d/nodo", "✓"),
        ("Enlace ULF (lineal)", f"{lin['snr_tipico_dB']:.0f} dB típ · @T {lin['snr_Tpozo_dB']:.0f} · peor {lin['snr_peor_lito_dB']:.0f}", "✓"),
        ("Enlace ULF (saturado)", f"{sat['snr_tipico_dB']:.0f} dB típ · estrés10dB {sat['estres']['snr_dB']:.0f}",
         "✓" if sat["estres"]["snr_dB"] >= 20 else "⚠ ABIERTO"),
        ("Saturación ferrita", f"m lineal/sat = {sa['razon']:.1f}×", "⚠ ABIERTO" if sa["excede"] else "✓"),
        ("P(ULF necesario)", f"{e['shear']['p_ulf_necesario'] * 100:.0f}%", "✓"),
        ("Árbol de decisión", "gate de canal activo (ROJA→pre-alerta si peso<0.5)", "✓"),
        ("CAPEX", f"${c['capex']:,}", "✓"),
        ("Reemplazos", f"${c['reemplazos']:,.0f} derivado [V]", "✓"),
        ("B/C desc. / VAN", f"{c['bc_desc']:.1f}:1 / ${c['van'] / 1e6:.0f}M", "✓"),
        ("Vidas equilibrio", f"{c['vidas_equilibrio_desc']:.0f} (vs {p.vidas_oficial:.0f} supuestas)", "✓"),
        ("P(≥3 nodos)", f"{rd['p_min3_analitica'] * 100:.1f}%", "✓"),
        ("Supuestos [H]", f"{sum(1 for s in SUPUESTOS if s['tag'] == 'H')} registrados", "⚠ VALIDAR"),
    ]
    for a, b, c_ in filas:
        print(f"  [{a:<22}] {b:<52} {c_}")
    print(L)


# ══════════════════════════════════════════════════════════════════════════
#  9. AUTOPRUEBAS DE REGRESIÓN
# ══════════════════════════════════════════════════════════════════════════
def selftest() -> int:
    fallos: list[str] = []

    def check(nombre: str, cond: bool, detalle: str = "") -> None:
        print(f"  {'✓' if cond else '✗'} {nombre}{(' — ' + detalle) if detalle else ''}")
        if not cond:
            fallos.append(nombre)

    def cerca(a: float, b: float, tol: float) -> bool:
        return abs(a - b) <= tol

    print("AUTOPRUEBAS GEO-PROBE CR v" + VERSION)
    r = simular()
    lin, c = r["enlace_lineal"], r["costos"]

    print("\n Regresión contra cifras selladas v6.3/v6.4")
    check("SNR típico 43.0 dB", cerca(lin["snr_tipico_dB"], 43.0, 0.05), f"{lin['snr_tipico_dB']:.2f}")
    check("SNR @T 42.3 dB", cerca(lin["snr_Tpozo_dB"], 42.3, 0.05), f"{lin['snr_Tpozo_dB']:.2f}")
    check("SNR peor litología 41.1 dB", cerca(lin["snr_peor_lito_dB"], 41.1, 0.05))
    check("Estrés rechazo 10 dB = 23.0 dB", cerca(lin["estres"]["snr_dB"], 23.0, 0.05))
    check("Geotermia 55 °C/km = 41.8 dB (el PDF v6.3 dice 41.7)", cerca(lin["estres"]["snr_geo_dB"], 41.8, 0.05), f"{lin['estres']['snr_geo_dB']:.2f}")
    check("P(ULF necesario) ≈ 36 %", round(lin["shear"]["p_ulf_necesario"] * 100) == 36)
    check("CAPEX = 3 587 200", c["capex"] == 3_587_200, f"{c['capex']:,}")
    check("Reemplazos = 3 090 000", round(c["reemplazos"]) == 3_090_000)
    check("B/C sin descontar 12.8", cerca(c["bc_simple"], 12.8, 0.05))
    check("VAN@6 % ≈ 147 M", cerca(c["van"] / 1e6, 147, 1.0), f"{c['van'] / 1e6:.1f}")
    check("Tormenta: nbit=13, peso 0.70, mayoría ✗",
          lin["tormenta"]["nbit"] == 13 and lin["tormenta"]["peso_canal"] == 0.70
          and not lin["tormenta"]["majority_ok"])

    print("\n Lógica del árbol y del gate de canal")
    for x in r["arbol"] + r["gate_canal"]:
        check(x.get("nombre") or x["etiqueta"], x["fase"] == x["esperado"], x["codigo"])

    print("\n Invariantes")
    check("ceil() corrige vida que no divide el horizonte",
          ciclos_reemplazo(8, 30) == 3 and int(30 / 8) - 1 == 2)
    check("ceil() coincide con vidas 7.5/10/15",
          [ciclos_reemplazo(v) for v in (7.5, 10, 15)] == [3, 2, 1])
    check("calendario suma = fondo", cerca(sum(m for *_, m in calendario_reemplazos(VIDA_UTIL, 30)),
                                           c["reemplazos"], 1e-6))
    check("P(cizalla) monótona", all(p_shear(a) < p_shear(b) for a, b in ((6, 7), (7, 8))))
    check("Pd ≤ 0.95", all(prob_deteccion(m, k) <= 0.95 for m in (5, 6, 7, 8) for k in FACTOR_PRECURSOR))
    check("Vidas de equilibrio → B/C = 1",
          cerca(valorar(P0, c["capex"], c["opex_anual"], calendario_reemplazos(VIDA_UTIL, 30),
                        vidas=c["vidas_equilibrio_desc"])["bc_desc"], 1.0, 1e-9))
    mc, an = r["deteccion"]["mc"], r["deteccion"]["ahorro_esperado_musd"]
    check("MC de ahorro ≈ analítico (4 SE)", abs(mc["ahorro_medio_musd"] - an) <= 4 * mc["ahorro_se_musd"])
    rm = r["red"]["p_min3_mc"]
    check("MC de red ≈ analítico (4 SE)", abs(rm["p_min_k"] - r["red"]["p_min3_analitica"]) <= 4 * rm["se"])
    check("Determinismo (misma semilla → mismo JSON)",
          json.dumps(simular(), default=_json_default, sort_keys=True)
          == json.dumps(r, default=_json_default, sort_keys=True))
    check("Saturación reduce el momento", r["verificaciones"]["saturacion"]["razon"] > 1)
    try:
        Params(depth_m=-1)
        check("Validación de parámetros", False)
    except ValueError:
        check("Validación de parámetros", True)

    print(f"\n{'TODAS LAS PRUEBAS PASAN' if not fallos else 'FALLARON: ' + ', '.join(fallos)}")
    return 0 if not fallos else 1


# ══════════════════════════════════════════════════════════════════════════
#  10. CLI
# ══════════════════════════════════════════════════════════════════════════
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=f"GEO-PROBE CR v{VERSION}")
    ap.add_argument("--out", default="GEO_PROBE_CR_v7_resultados.json",
                    help="ruta del JSON de resultados")
    ap.add_argument("--seed", type=int, default=SEED)
    ap.add_argument("--saturacion", action="store_true",
                    help="usar el tope de saturación en los KPIs principales")
    ap.add_argument("--selftest", action="store_true", help="ejecutar pruebas y salir")
    ap.add_argument("--quiet", action="store_true", help="no imprimir el informe")
    a = ap.parse_args(argv)

    if a.selftest:
        return selftest()
    res = simular(P0, seed=a.seed, saturacion=a.saturacion)
    if not a.quiet:
        imprimir(res, P0)
    ruta = guardar_json(res, Path(a.out))
    if not a.quiet:
        print(f"\n  JSON → {ruta}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
